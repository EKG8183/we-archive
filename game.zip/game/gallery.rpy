# 画廊（CG 鉴赏）
# 收录剧本里所有背景/立绘图片，可点击全屏查看，支持左右方向键翻页

init python:
    GALLERY_ITEMS = [
    ("back1", "images/back1.jpg"),
    ("angery", "images/gate angury.jpg"),
    ("normal", "images/gate normal.jpg"),
    ("back2", "images/back2.jpg"),
    ("jd", "images/bg1025a.jpg"),
    ("p1", "images/piano1.jpg"),
    ("p2", "images/piano2.jpg"),
    ("bk5", "images/back5.jpg"),
    ("bk3", "images/back3.jpg"),
    ("bs1", "images/back2.jpg"),
    ("k1", "images/kids1.jpg"),
    ("k2", "images/kids2.jpg"),
    ("sf", "images/back4.jpg"),
    ("sf1", "images/sunflowour1.jpg"),
    ("sf2", "images/sunfiowour2.jpg"),
    ("zy", "images/bg1051c.jpg"),
    ("road", "images/bg1045b.jpg"),
    ("home", "images/bg1007c.jpg"),
    ("bk6", "images/back6.jpg"),
    ("fire1", "images/fire1.jpg"),
    ("fire2", "images/fire2.jpg"),
    ("fire3", "images/fire3.jpg"),
    ("bk7", "images/back7.jpg"),
    ("fire4", "images/fire4.jpg"),
    ("w3", "images/walk3.jpg"),
    ("w4", "images/walk4.jpg"),
    ("fd1", "images/food1.jpg"),
    ("fd2", "images/food2.jpg"),
    ("bk10", "images/back10.jpg"),
    ("ba", "images/ball1.jpg"),
    ("e", "images/back13.jpg"),
    ("ele", "images/ele.jpg"),
    ("bk16", "images/back16.jpg"),
    ("cp1", "images/computer1.jpg"),
    ("cp2", "images/computer2.jpg"),
    ("bk15", "images/back15.jpg"),
    ("fish", "images/fish.jpg"),
    ("sup", "images/supermarket1.jpg"),
    ("sup2", "images/sup2.jpg"),
    ("ls", "images/lakeside.jpg"),
    ("bt0", "images/bt0.jpg"),
    ("bt1", "images/bt1.jpg"),
    ("bt2", "images/bt2.jpg"),
    ("bt3", "images/bt3.jpg"),
    ("bt4", "images/bt3.jpg"),
    ("btcm1", "images/btcm1.jpg"),
    ("btcm2", "images/btcm2.jpg"),
    ("btcm3", "images/btcm3.jpg"),
    ("nb1", "images/nb1.jpg"),
    ("nb2", "images/nb2.jpg"),
    ("un", "images/un.jpg"),
    ("ud", "images/underground.jpg"),
    ("udcm1", "images/udcm1.jpg"),
    ("udcm0", "images/udcm0.jpg"),
    ("udcm2", "images/udcm2.jpg"),
    ("udcm3", "images/udcm3.jpg"),
    ("wc", "images/wc.jpg"),
    ("wccm", "images/wccm.jpg"),
    ("fcm", "images/fishcm.jpg"),
    ("mcm", "images/meetcm.jpg"),
    ("mb", "images/mb.jpg"),
    ("jd2", "images/bg1026a.jpg"),
    ("jdcm", "images/jdcm.jpg"),
    ("tt", "images/bg1016c.jpg"),
    ("lt", "images/bg1011d.jpg"),
    ("ld0", "images/bg1017c2.jpg"),
    ("ld1", "images/ld1.jpg"),
    ("ld2", "images/ld2.jpg"),
    ("ld3", "images/ld3.jpg"),
    ("tt1", "images/tt1.jpg"),
    ("tt2", "images/tt2.jpg"),
    ("ttcm", "images/ttcm.jpeg"),
    ("end", "images/end.jpg"),
    ("ed", "images/ed.jpg"),
    ("ed1", "images/ed1.jpg"),
    ("op", "images/op.jpg"),
    ("walk1", "images/walk1.jpg"),
    ("walk5", "images/walk5.jpg"),
    ("walk6", "images/walk6.jpg"),
    ]

    GALLERY_COUNT = len(GALLERY_ITEMS)

    # —— 画廊解锁记录 ——
    if persistent.gallery_seen is None:
        persistent.gallery_seen = set()

    def gallery_track_seen():
        # 每次交互后，把当前 master 层正在显示的图片（scene/show 的标签）标记为已见
        try:
            for tag in renpy.get_showing_tags(layer="master"):
                persistent.gallery_seen.add(tag)
        except Exception:
            pass

    config.interact_callbacks.append(gallery_track_seen)

    def gal_seen_count():
        return sum(1 for gname, _gpath in GALLERY_ITEMS if gname in persistent.gallery_seen)


screen gallery():
    tag menu

    add Solid("#0d0d12")

    ## 标题
    text "画 廊":
        xpos 70
        ypos 42
        size 46
        color "#3FA9F5"
        outlines [ (2, "#001428", 0, 0) ]

    text "已收集 [gal_seen_count()] / [GALLERY_COUNT] 张":
        xpos 70
        ypos 100
        size 22
        color "#8899aa"

    ## 关闭
    textbutton "返 回":
        xalign 0.965
        ypos 52
        text_size 26
        text_color "#3FA9F5"
        text_hover_color "#9BD8FF"
        action Return()

    ## 缩略图网格
    vpgrid:
        cols 4
        spacing 22
        xpos 60
        ypos 155
        xsize 1800
        ysize 870
        scrollbars "vertical"
        mousewheel True
        draggable True

        for gi, (gname, gpath) in enumerate(GALLERY_ITEMS):
            if gname in persistent.gallery_seen:
                button:
                    action Show("cg_viewer", idx=gi)

                    fixed:
                        xysize (430, 300)

                        add Transform(gpath, fit="contain", xysize=(430, 280)) xalign 0.5 yalign 0.0

                        frame:
                            background None
                            padding (0, 0)
                            yalign 1.0
                            text gname:
                                size 18
                                color "#8fa3b8"
                                xalign 0.5
            else:
                button:
                    action NullAction()

                    fixed:
                        xysize (430, 300)
                        add Solid("#14141d")
                        text "?":
                            xalign 0.5
                            yalign 0.35
                            size 60
                            color "#3a4352"
                        text "未解锁":
                            xalign 0.5
                            yalign 0.75
                            size 20
                            color "#566173"


## 全屏查看
screen cg_viewer(idx):
    modal True

    $ gname, gpath = GALLERY_ITEMS[idx]

    add Solid("#000")
    add Transform(gpath, fit="contain", xysize=(1920, 1080)) xalign 0.5 yalign 0.5

    ## 图片名 + 序号
    text "[gname]  ([idx + 1] / [GALLERY_COUNT])":
        xalign 0.5
        ypos 26
        size 26
        color "#ffffff"
        outlines [ (2, "#000000", 0, 0) ]

    ## 左右翻页
    textbutton "◀":
        xpos 30
        yalign 0.5
        text_size 60
        text_color "#3FA9F5"
        text_hover_color "#9BD8FF"
        action [Hide("cg_viewer"), Show("cg_viewer", idx=(idx - 1) % GALLERY_COUNT)]

    textbutton "▶":
        xalign 0.985
        yalign 0.5
        text_size 60
        text_color "#3FA9F5"
        text_hover_color "#9BD8FF"
        action [Hide("cg_viewer"), Show("cg_viewer", idx=(idx + 1) % GALLERY_COUNT)]

    ## 关闭
    textbutton "✕":
        xalign 0.985
        ypos 22
        text_size 40
        text_color "#ffffff"
        text_hover_color "#ff6666"
        action Hide("cg_viewer")

    key "game_menu" action Hide("cg_viewer")
    key "K_ESCAPE" action Hide("cg_viewer")
    key "K_LEFT" action [Hide("cg_viewer"), Show("cg_viewer", idx=(idx - 1) % GALLERY_COUNT)]
    key "K_RIGHT" action [Hide("cg_viewer"), Show("cg_viewer", idx=(idx + 1) % GALLERY_COUNT)]
