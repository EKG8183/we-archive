# 画廊（CG 鉴赏）
# 收录剧本里所有背景/立绘图片，可点击全屏查看，支持左右方向键翻页

init python:
    GALLERY_ITEMS = [
    ("walk5", "images/walk5.jpg"),
    ("walk6", "images/walk6.jpg"),
    ("op", "images/op.jpg"),
    ("back1", "images/back1.jpg"),
    ("jd", "images/bg1025a.jpg"),
    ("normal", "images/gate normal.jpg"),
    ("back2", "images/back2.jpg"),
    ("p1", "images/piano1.jpg"),
    ("p2", "images/piano2.jpg"),
    ("tanqin", "images/tanqin.jpg"),
    ("bk5", "images/back5.jpg"),
    ("bs1", "images/back2.jpg"),
    ("bk3", "images/back3.jpg"),
    ("k1", "images/kids1.jpg"),
    ("k2", "images/kids2.jpg"),
    ("sf", "images/back4.jpg"),
    ("sf1", "images/sunflowour1.jpg"),
    ("sf2", "images/sunfiowour2.jpg"),
    ("zy", "images/bg1051c.jpg"),
    ("home", "images/bg1007c.jpg"),
    ("bk6", "images/back6.jpg"),
    ("fire1", "images/fire1.jpg"),
    ("fire2", "images/fire2.jpg"),
    ("fire3", "images/fire3.jpg"),
    ("bk7", "images/back7.jpg"),
    ("fire4", "images/fire4.jpg"),
    ("walk1", "images/walk1.jpg"),
    ("w3", "images/walk3.jpg"),
    ("w4", "images/walk4.jpg"),
    ("fd1", "images/food1.jpg"),
    ("fd2", "images/food2.jpg"),
    ("bk10", "images/back10.jpg"),
    ("ball1", "images/ball1.jpg"),
    ("e", "images/back13.jpg"),
    ("ele", "images/ele.jpg"),
    ("bk16", "images/back16.jpg"),
    ("cp1", "images/computer1.jpg"),
    ("cp2", "images/computer2.jpg"),
    ("bk15", "images/back15.jpg"),
    ("fish", "images/fish.jpg"),
    ("sup", "images/supermarket1.jpg"),
    ("sup2", "images/sup2.jpg"),
    ("ls", "images/lakeside.jpg"),
    ("un", "images/un.jpg"),
    ("nb1", "images/nb1.jpg"),
    ("nb2", "images/nb2.jpg"),
    ("bt1", "images/bt1.jpg"),
    ("bt2", "images/bt2.jpg"),
    ("bt3", "images/bt3.jpg"),
    ("end", "images/end.jpg"),
    ("ed1", "images/ed1.jpg"),
    ("ud", "images/underground.jpg"),
    ("udcm0", "images/udcm0.jpg"),
    ("udcm3", "images/udcm3.jpg"),
    ("udcm1", "images/udcm1.jpg"),
    ("udcm2", "images/udcm2.jpg"),
    ("wc", "images/wc.jpg"),
    ("wccm", "images/wccm.jpg"),
    ("fcm", "images/fishcm.jpg"),
    ("mcm", "images/meetcm.jpg"),
    ("mb", "images/mb.jpg"),
    ("jgs", "images/jgs.jpg"),
    ("btcm1", "images/btcm1.jpg"),
    ("btcm3", "images/btcm3.jpg"),
    ("btcm2", "images/btcm2.jpg"),
    ("jd2", "images/bg1026a.jpg"),
    ("jdcm", "images/jdcm.jpg"),
    ("lt", "images/bg1011d.jpg"),
    ("ld0", "images/bg1017c2.jpg"),
    ("ld1", "images/ld1.jpg"),
    ("ld3", "images/ld3.jpg"),
    ("ld2", "images/ld2.jpg"),
    ("tt1", "images/tt1.jpg"),
    ("tt2", "images/tt2.jpg"),
    ("huo", "images/76D5EAB3ED4A7D3A6FD3E9F45389258032B9328C_w500_h67.jpg"),
    ("xs", "images/Picsart_26-11-08_02-12-49-839.png"),
    ("zs", "images/Picsart_26-11-08_02-26-16-062.png"),
    ("smoke", "images/98a0879ac20d73a33a76626e50dd0742.jpg"),
    ("yc", "images/bg1021c.jpg"),
    ("dm", "images/bg1020c.jpg"),
    ("gd", "images/bg1027b.jpg"),
    ("drop", "images/71f7bdbef71d4c6b.jpg"),
    ("earth", "images/Picsart_26-11-07_10-58-21-537.png"),
    ("dot", "images/PIA23645_1794025981241edit.jpg"),
    ("saturn", "images/Picsart_26-11-07_12-24-40-437.png"),
    ("red", "images/Picsart_26-11-07_13-22-21-927.jpg"),
    ("die", "images/Picsart_26-11-07_12-48-14-961.jpg"),
    ("ed", "images/ed.jpg"),
    ]

    GALLERY_COUNT = len(GALLERY_ITEMS)

    # —— 画廊解锁记录 ——
    if persistent.gallery_seen is None:
        persistent.gallery_seen = set()

    def gallery_track_seen():
        # 每次交互后，把当前 master 层正在显示的图片（scene/show 的标签）标记为已见
        try:
            for tag in renpy.get_showing_tags(layer="master"):
                persistent.gallery_seen.add(tag)
        except Exception:
            pass

    config.interact_callbacks.append(gallery_track_seen)

    def gal_nav(idx, step):
        """在查看器里翻页：只在已解锁的图之间循环，避免翻到未解锁的 CG。"""
        unlocked = [i for i, (n, _p) in enumerate(GALLERY_ITEMS)
                    if n in persistent.gallery_seen]
        if not unlocked:
            return idx
        if idx not in unlocked:
            unlocked.append(idx)
            unlocked.sort()
        pos = unlocked.index(idx)
        return unlocked[(pos + step) % len(unlocked)]

    def gal_seen_count():
        return sum(1 for gname, _gpath in GALLERY_ITEMS if gname in persistent.gallery_seen)


screen gallery():
    tag menu

    add Solid("#0d0d12")

    ## 标题
    text "画 廊":
        xpos 70
        ypos 42
        size 46
        color "#3FA9F5"
        outlines [ (2, "#001428", 0, 0) ]

    text "已收集 [gal_seen_count()] / [GALLERY_COUNT] 张":
        xpos 70
        ypos 100
        size 22
        color "#8899aa"

    ## 关闭
    textbutton "返 回":
        xalign 0.965
        ypos 52
        text_size 26
        text_color "#3FA9F5"
        text_hover_color "#9BD8FF"
        action Return()

    ## 缩略图网格
    vpgrid:
        cols 4
        spacing 22
        xpos 60
        ypos 155
        xsize 1800
        ysize 870
        scrollbars "vertical"
        mousewheel True
        draggable True

        for gi, (gname, gpath) in enumerate(GALLERY_ITEMS):
            if gname in persistent.gallery_seen:
                button:
                    action Show("cg_viewer", idx=gi)

                    fixed:
                        xysize (430, 300)

                        add Transform(gpath, fit="contain", xysize=(430, 280)) xalign 0.5 yalign 0.0

                        frame:
                            background None
                            padding (0, 0)
                            yalign 1.0
                            text _(gname):
                                size 18
                                color "#8fa3b8"
                                xalign 0.5
            else:
                button:
                    action NullAction()

                    fixed:
                        xysize (430, 300)
                        add Solid("#14141d")
                        text "?":
                            xalign 0.5
                            yalign 0.35
                            size 60
                            color "#3a4352"
                        text "未解锁":
                            xalign 0.5
                            yalign 0.75
                            size 20
                            color "#566173"


## 全屏查看
screen cg_viewer(idx):
    modal True

    $ gname, gpath = GALLERY_ITEMS[idx]

    add Solid("#000")
    add Transform(gpath, fit="contain", xysize=(1920, 1080)) xalign 0.5 yalign 0.5

    ## 顶部一条暗带：保证标题/提示在任何亮图上都看得清
    add Solid("#000000b0") xpos 0 ypos 0 xysize (1920, 104)
    add Solid("#00000080") xpos 0 ypos 1028 xysize (1920, 52)

    ## 图片名 + 序号
    text "[gname]  ([idx + 1] / [GALLERY_COUNT])":
        xalign 0.5
        ypos 26
        size 26
        color "#ffffff"
        outlines [ (2, "#000000", 0, 0) ]

    ## 左右翻页
    textbutton "←":
        xpos 30
        yalign 0.5
        text_size 60
        text_color "#3FA9F5"
        text_hover_color "#9BD8FF"
        action [Hide("cg_viewer"), Show("cg_viewer", idx=gal_nav(idx, -1))]

    textbutton "→":
        xalign 0.985
        yalign 0.5
        text_size 60
        text_color "#3FA9F5"
        text_hover_color "#9BD8FF"
        action [Hide("cg_viewer"), Show("cg_viewer", idx=gal_nav(idx, 1))]

    ## 操作提示
    text "← / → 翻页　　ESC 关闭":
        xalign 0.5
        ypos 64
        size 21
        color "#c8d6e8"

    ## 关闭
    textbutton "✕":
        xalign 0.985
        ypos 22
        text_size 40
        text_color "#ffffff"
        text_hover_color "#ff6666"
        action Hide("cg_viewer")

    key "game_menu" action Hide("cg_viewer")
    key "K_ESCAPE" action Hide("cg_viewer")
    key "K_LEFT" action [Hide("cg_viewer"), Show("cg_viewer", idx=gal_nav(idx, -1))]
    key "K_RIGHT" action [Hide("cg_viewer"), Show("cg_viewer", idx=gal_nav(idx, 1))]
