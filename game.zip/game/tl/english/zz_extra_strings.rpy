# 动态文本（Python / 屏幕拼接）的英译，由脚本生成

translate english strings:

    old "完美演绎"
    new "Perfect performance"

    old "相当出色"
    new "Quite outstanding"

    old "还算流畅"
    new "Fairly fluent"

    old "有点勉强"
    new "A bit reluctant"

    old "仍需练习"
    new "Still needs practice"

    old "遠く遥かな歌が"
    new "A song from far away"

    old "遥远的歌声"
    new "Distant Voices"

    old "たえまなく聞こえてくる"
    new "I can hear it constantly."

    old "阵阵的传来"
    new "It came in waves"

    old "微笑みを讃(たた)えるように"
    new "Smile みを讃(たた)えるように"

    old "像是装满了微笑"
    new "It seems to be filled with smiles"

    old "ときに優しく強く…"
    new "に に excellent く く strong く..."

    old "有时温柔有时坚强"
    new "Sometimes gentle, sometimes strong"

    old "（别害怕）"
    new "Don't be afraid."

    old "思い悩み傷つき"
    new "Worrying and getting hurt"

    old "思想烦恼受伤害"
    new "Mental distress and emotional harm"

    old "眠れない夜もあった"
    new "There were also sleepless nights."

    old "也有受挫的夜晚"
    new "There are also frustrating nights."

    old "信じ合い 肩を支えて"
    new "Trust each other and support each other."

    old "互相信赖　互相支持"
    new "Mutual trust and support"

    old "励ましあったあの日"
    new "The day we encouraged each other"

    old "互相勉励的那一天"
    new "The day we encouraged each other"

    old "（别担心 朋友）"
    new "(Don't worry, friend.)"

    old "終わりのない旅の途中で"
    new "On an endless journey"

    old "在这没有结束的旅途中"
    new "On this never-ending journey"

    old "振り向けば君がいる"
    new "When I turn around, you're there."

    old "我一回头总是看到你"
    new "I always see you when I turn around."

    old "人は皆ひとりきりじゃ"
    new "Everyone is alone."

    old "人总是无法"
    new "People are always unable to"

    old "生きてゆけないから…"
    new "Because I can't live..."

    old "自己一个人活下去"
    new "Survive on your own."

    old "広い大地の上に"
    new "{\" id \": 1313853,\" text \":\" hiro-tri daichi に."

    old "在广大的大地上"
    new "On the vast land"

    old "寝転んで見あげた空"
    new "see あげた empty"

    old "躺着看天空"
    new "Lie down and look at the sky"

    old "果てしない銀河の流れ"
    new "The result is て な な て galactic <s:1> flow れ"

    old "没有尽头的银河"
    new "The endless Milky Way"

    old "いつもこの地球(ほし)つつむ"
    new "Always enveloping this Earth (planet)"

    old "总是包围着地球"
    new "Always surrounding the Earth"

    old "たとえ街は荒んでいっても"
    new "Even if the city is desolate"

    old "就算街上一片荒凉"
    new "Even if the streets are deserted"

    old "夢をみる力が"
    new "The power to dream"

    old "做梦的力量"
    new "The Power of Dreaming"

    old "この胸に希望の鐘"
    new "The bell of hope in this heart"

    old "明日将会在我胸中"
    new "Tomorrow will be in my heart"

    old "明日(あす)も鳴らすだろう"
    new "It will ring tomorrow too."

    old "敲响希望的钟"
    new "Ring the Bell of Hope"

    old "また新しい 物語を生きるよ"
    new "I'll live a new story again."

    old "会再走过一个新的人生"
    new "I'll live a new life again."

    old "把歌词按分段均匀铺到对应小节上，返回 [(start_beat, jp, cn), ...]。"
    new "Distribute the lyrics evenly across the corresponding measures according to the sections. Return [(start_beat, jp, cn), ...]."

    old "返回歌曲时间 t（秒）对应的歌词 (日语, 中文)；还没到第一句则返回 None。"
    new "Returns the lyrics (Japanese, Chinese) corresponding to the song time t (seconds); if the first line has not yet been reached, None is returned."

    old "把键盘谱文本解析成轨道序列。空白与未知字符会被忽略。"
    new "Parse the keyboard notation text into a track sequence. Spaces and unknown characters will be ignored."

    old "返回 (notes, song_end)。notes 为 Note(index, time, lane, duration) 元组。"
    new "Returns (notes, song_end). notes is a tuple of Note(index, time, lane, duration)."

    old "谱面音符数 %d 与时值数 %d 不一致"
    new "The number of notes on the score %d does not match the duration %d"

    old "推进一个逻辑步长，返回这一步新漏掉的音符下标列表。"
    new "Advance one logical step and return the list of newly missed note indices in this step."

    old "按下某条轨道。返回"
    new "Press a certain track. Return"

    old "/ None（没有可判定的音符）。"
    new "/ None (No identifiable notes)."

    old "返回当前要绘制的音符 [(Note, state)]，state 为 None /"
    new "Return the note you are currently drawing [(Note, state)], with the state being None /"

    old "返回当前处于「按下高亮」状态的轨道集合。"
    new "Return the collection of tracks that are currently in the \"Press Highlight\" state."

    old "加权准确率：PERFECT 记 1 分，GOOD 记 0.5 分，MISS 记 0 分。"
    new "Weighted accuracy: PERFECT scores 1 point, GOOD scores 0.5 points, and MISS scores 0 points."

    old "1) 谱面数据"
    new "1) Chart data"

    old "轨道序列与独立写死的期望值一致 (%d 个音)"
    new "The track sequence matches the expected hardcoded value (%d notes)."

    old "音符数 = 时值数 = %d"
    new "Number of notes = Number of note values = %d"

    old "总音符数 116"
    new "Total number of notes 116"

    old "所有音都在 0..9 号轨道内"
    new "All notes are within tracks 0..9"

    old "时间严格递增"
    new "Strictly increasing time"

    old "最小音符间隔 %.3fs >= 0.30s（足够简单，不会出现连打）"
    new "Minimum note interval %.3fs >= 0.30s (simple enough to avoid consecutive hits)"

    old "最大音符间隔 %.3fs（句尾长音，不超过 2 拍）"
    new "Maximum note interval %.3fs (sustained note at the end of a phrase, not exceeding 2 beats)"

    old "第一个音在 0.0s"
    new "The first sound is at 0.0s"

    old "曲终时间 %.3fs 等于最后音符 + 尾巴"
    new "Song end time %.3fs equals the last note + tail"

    old "10 条轨道全部用到"
    new "All 10 tracks are used"

    old "黑键分布正确：E-F 与 B-C 之间没有黑键"
    new "Correct black key distribution: No black keys between E-F and B-C"

    old "2) 完美演奏"
    new "2) Perfect performance"

    old "start() 后进入 play"
    new "Enter play after start()"

    old "起始歌曲时间为 -LEAD_TIME"
    new "Song start time is -LEAD_TIME"

    old "第 %d 个音被判成 %r"
    new "The %dth note is judged as %r"

    old "%d 个音全部 PERFECT"
    new "0⟧ sounds all PERFECT"

    old "曲终后 finished/result"
    new "finished/result"

    old "满分 %d"
    new "Full score: %d"

    old "最大连击 %d"
    new "Maximum combo %d"

    old "准确率 1.0 / 评级 S"
    new "Accuracy rate: 1.0 / Rating: S"

    old "2b) 真实时钟 tick_wall()"
    new "2b) Real clock tick_wall()"

    old "第一次调用只记录时间，不推进"
    new "The first call only records the time and does not advance."

    old "第一次调用后歌曲时间不变"
    new "The song time remains unchanged after the first call."

    old "0.1 秒真实时间 = 0.1 秒歌曲时间"
    new "0.1 second of real time = 0.1 second of song time"

    old "卡顿 4.9 秒只推进 %.2fs（钳制在 MAX_FRAME_TIME）"
    new "Stuttering for 4.9 seconds, only advanced %.2fs (capped at MAX_FRAME_TIME)"

    old "时间未前进时不推进"
    new "Do not advance when time has not advanced"

    old "按 60fps 真实时钟跑完整曲（%.2fs）"
    new "Play the entire song at 60fps real-time clock (%.2fs)"

    old "真实时钟下所有音符都被判定（miss=%d）"
    new "All notes are judged under the real-time clock (miss=%d)"

    old "3) 完全不按"
    new "3) Do not press at all"

    old "全部 MISS、0 分"
    new "All MISSES, 0 points"

    old "准确率 0 / 评级 D"
    new "Accuracy 0 / Grade D"

    old "4) 判定细节"
    new "4) Determination details"

    old "窗口外按键不判定、不计分"
    new "Keys pressed outside the window are not recognized and do not count towards the score."

    old "无效按键不影响分数"
    new "Invalid keys do not affect the score"

    old "0.06s 内判 PERFECT"
    new "PERFECT within 0.06s"

    old "0.16s 内判 GOOD"
    new "Judged as GOOD within 0.16s"

    old "超时自动 MISS"
    new "Automatic MISS after timeout"

    old "active() 里还有后续音符"
    new "There are subsequent notes in active()"

    old "progress() 正常"
    new "progress() is normal"

    old "5) 输入 / 视图接口"
    new "5) Input/View interface"

    old "ready 阶段不接受输入"
    new "The ready stage does not accept input"

    old "非法轨道返回 None"
    new "The illegal track returns None"

    old "active() 返回 (Note, state)"
    new "active() returns (Note, state)"

    old "落下的音符按时间排好序"
    new "Dropped notes sorted by time"

    old "5b) 屏幕坐标换算 falling()"
    new "5b) Screen Coordinate Conversion falling()"

    old "时间 0 时有音符要画（%d 个）"
    new "There are notes to draw at time 0 (%d)"

    old "每行是 (lane, y, missed)"
    new "Each row is (lane, y, missed)"

    old "y 必须是 int —— 浮点会被 Ren'Py 当成容器百分比"
    new "y must be an int – floating points will be treated as container percentages by Ren'Py"

    old "所有 y 都落在可视范围内"
    new "All y's fall within the visible range"

    old "第一个音正好停在判定线上 (lane=%d y=%d)"
    new "The first note stops right on the decision line (lane=%d y=%d)"

    old "未判定音符 missed=False"
    new "Unjudged note missed=False"

    old "时间前进后音符向下移动"
    new "Notes move down as time progresses"

    old "漏掉的音符以 missed=True 继续下坠"
    new "The missed notes continue to fall with missed=True"

    old "全部超出范围时不画任何东西"
    new "Do not draw anything when everything is out of range"

    old "刚出现时音符处在轨道顶端 y=%s"
    new "When it first appears, the note is at the top of the track y=%s"

    old "press_lanes() 返回集合"
    new "press_lanes() returns a collection"

    old "stats() 字段齐全"
    new "stats() fields are complete"

    old "6) 评级阈值"
    new "6) Rating Thresholds"

    old "0.95/0.85/0.70/0.50 分档正确"
    new "0.95/0.85/0.70/0.50 tiers are correct"

    old "7) 歌词"
    new "7) Lyrics"

    old "歌词共 34 句"
    new "34 lines of lyrics in total"

    old "每句都是 (日语, 中文) 两元组"
    new "Each sentence is a (Japanese, Chinese) tuple"

    old "歌词时间轴共 34 条"
    new "The lyrics timeline consists of 34 lines"

    old "歌词时间轴单调不减"
    new "The timeline of the lyrics remains monotonous"

    old "歌曲开始前无歌词"
    new "There are no lyrics before the song starts"

    old "第 0 秒显示第一句（主歌1）"
    new "Display the first line (Verse 1) at second 0"

    old "第 13 秒仍在主歌1（Don't be afraid）"
    new "The 13th second is still in verse 1 (Don't be afraid)"

    old "第 14 秒进入主歌2（思い悩み傷つき）"
    new "Verse 2 starts at 14 seconds (思い悩み傷つき)"

    old "第 28 秒进入副歌（終わりのない旅）"
    new "The chorus starts at 28 seconds (An Endless Journey)"

    old "第 54 秒进入副歌收尾（この胸に希望の鐘）"
    new "The chorus ends at 54 seconds (この胸に希望の鐘)"

    old "超出长度时停在最后一句"
    new "Stop at the last sentence when the length is exceeded"

    old "自检失败 %d 项："
    new "Self-test failed for %d items:"

    old "全部自检通过：%d 个音符，%.1f 秒，%d 条轨道，最慢间隔 %.3fs"
    new "All self-checks passed: %d notes, %.1f seconds, %d tracks, slowest interval %.3fs"

    old "夏日大三角"
    new "Summer Triangle"

    old "夏日大三角：织女、天津四、牛郎——三颗一等亮星跨着银河相望呢"
    new "The Summer Triangle: Vega, Deneb, and Altair – three first-magnitude stars gaze at each other across the Milky Way."

    old "织女星"
    new "the Weaving-girl star"

    old "天津四"
    new "Deneb"

    old "牛郎星"
    new "Cow Herd Star (Altair)"

    old "嗯——最亮的那颗在星图左上角哦，视星等很低，是全天排得上号的亮星呢～"
    new "Hmm... The brightest one is in the upper-left corner of the star chart. It has a very low apparent magnitude and is one of the brightest stars in the entire sky!"

    old "从它往右平移过去呀，会碰到更高的一颗；那是颗白色超巨星呢。"
    new "If you move to the right from it, you'll come across a brighter one; that's a white supergiant."

    old "最后一颗在右下角啦，和第一颗隔着好大一段赤经，遥遥相对的样子哦～"
    new "The last one is in the lower right corner, separated from the first one by a long stretch of right ascension, looking like they're facing each other from a distance."

    old "猎户座"
    new "Orion"

    old "猎户座：肩、腰带、双腿——一条挂着三星腰带的冬季巨人哦"
    new "Orion: Shoulders, belt, legs – a winter giant with a belt of three stars."

    old "参宿四"
    new "Betelgeuse"

    old "参宿五"
    new "Shen Su 5"

    old "参宿三"
    new "Shen Su SAN"

    old "参宿二"
    new "Shen Su Er"

    old "参宿一"
    new "Shen Su Yi"

    old "参宿六"
    new "Shen Su 6"

    old "参宿七"
    new "Shen Su Qi"

    old "先从左上角那颗偏红的开始吧——那是颗红超巨星，颜色一眼就能认出来呢。"
    new "Let's start with the reddish one in the upper left corner – that's a red supergiant, and its color is immediately recognizable."

    old "往右一点呀，还有颗同样亮的肩星哦，偏蓝的，又年轻又高温呢～"
    new "A little to the right, there's another star on the shoulder that's just as bright. It's bluish, young, and hot!"

    old "往下走啦，去找腰带的右端；猎户腰带那三颗，可是这个星座最有名的标志哦。"
    new "Go down to the right end of the belt. The three stars in Orion's belt are the most famous feature of this constellation."

    old "腰带横着排三颗，取中间那颗吧，它离我们挺远的呢。"
    new "There are three stars in a row on the belt. Take the middle one. It's quite far from us."

    old "继续沿腰带往左，最后一颗——它旁边还藏着一颗伴星，挺有名的哦～"
    new "Continue along the asteroid belt to the left. The last one – there's a companion star hidden next to it. It's quite famous!"

    old "从腰带往下，走左下那条腿；那是颗蓝白超巨星呢。"
    new "From the belt down, follow the lower left leg; that's a blue-white supergiant star."

    old "最后收在右下那条腿啦——蓝白超巨星，视星等很低，全天排前几的亮星哦～"
    new "Finally, we have the leg at the bottom right – the blue-white supergiant. It has a very low apparent magnitude and is one of the brightest stars in the sky!"

    old "星线 PNG 的裁切原点，由星位推出，避免和素材脚本各写一份而走样。"
    new "The cropping origin of the star line PNG is derived from the star position to avoid distortion caused by separate writing in the asset script."

    old "连星进度档位：0 前段 / 1 中段 / 2 后段，用来选不同音高的音效。"
    new "Lianxing progress level: 0 front section / 1 middle section / 2 back section, used to select sound effects of different pitches."

    old "%s：线索 %d 条，星星 %d 颗，数量不一致"
    new "%s: %d clues, %d stars. The numbers don't match."

    old "%s：没有干扰星"
    new "%s: No Interference Star"

    old "干扰星%d"
    new "Interference Star%d"

    old "%s：%s 的 x=%d 越界"
    new "%s: x=%d of %s is out of bounds"

    old "%s：%s 的 y=%d 越界"
    new "%s: y=%d of %s is out of bounds"

    old "%s：%s 与 %s 只隔 %.0fpx（下限 %d）"
    new "%s: %s and %s are only %.0fpx apart (lower limit %d)"

    old "%s：第 %d 条线索为空"
    new "%s: Clue %d is empty"

    old "评分不单调：%s / %s / %s"
    new "Non-monotonic rating: %s / %s / %s"

    old "零失误零提示却不是 S：%s"
    new "Zero errors and zero prompts, but not S:%s"

    old "表现很差却给了 %s"
    new "I performed poorly but gave %s"

    old "%s：音效档位随进度倒退 %s"
    new "0⟧ : The sound effect level goes backward with progress %s"

    old "%s：档位没有覆盖前段/后段 %s"
    new "0⟧ : the gear does not cover the front/rear %s"

    old "%s：档位越界 %s"
    new "0⟧ : gear out of bounds %s"

    old "%s：crop 计算异常"
    new "0⟧ : crop calculation exception"

    old "星座核心自检失败："
    new "The core self-check of the constellation failed"

    old "星座核心自检通过：%d 个星座"
    new "Constellation Core Self-Check Passed: %d Constellations"

    old "%-8s %d 颗星 + %d 颗干扰星，crop=%s，档位=%s"
    new "%-8s %d stars + %d interference stars, crop=%s, level=%s"

    old "第 %d 关：把小球推到对应颜色出口"
    new "Level %d: Push the balls to the corresponding colored exits"

    old "这里推不动，再换一个方向"
    new "It won't move here. Let's try another direction."

    old "全部通关！%d 步完成"
    new "All cleared! Completed in %d steps."

    old "第 %d 关完成（%d 步），点击「下一关」"
    new "Level %d completed (%d steps). Tap \"Next Level."

    old "移动次数：%d"
    new "Number of moves: %d"

    old "返回该格的出口颜色名（red/blue/gold），不是出口则返回 None。"
    new "Returns the color name of the exit of the cell (red/blue/gold). If it is not an exit, it returns None."

    old "已经推进出口的小球数量。"
    new "The number of balls that have been pushed to the outlet."

    old "moving balls　第 %d / %d 关"
    new "Moving Balls　Level %d / %d"

    old "推动小球进入相同颜色的出口　方向键或下方按钮移动"
    new "Push the ball into the exit of the same color. Use the arrow keys or the buttons below to move."

    old "归位 %d / %d"
    new "Reset %d / %d"

    old "出口"
    new "OUTLET"

    old "上"
    new "Upward"

    old "下"
    new "Bawah"

    old "左"
    new "Kiri"

    old "右"
    new "Right"

    old "重来本关"
    new "Restart this level"

    old "下一关"
    new "The next level"

    old "完成"
    new "Completed"

    old "不在这个星座里"
    new "Not in this zodiac sign"

    old "来～按顺序点亮星星，把它们连成星座吧"
    new "Come on ~ Light up the stars in sequence and connect them into constellations"

    old "屏幕定时器驱动，刷新计时显示。"
    new "Screen timer driver, refresh the timing display."

    old "哇——整条星座都亮起来啦，好漂亮呢～"
    new "Wow - the entire constellation is lit up. How beautiful"

    old "提示哦：下一颗是「%s」，我在旁边看着你呢～"
    new "Tip: The next one is \"%s\". I'm watching you from the side~"

    old "「%s」完整显现啦！评价 %s 哦～"
    new "\"%s\" is fully revealed! Rate %s Oh~"

    old "接上啦～现在是 %d / %d 呢"
    new "Connected! It's now %d / %d"

    old "诶？这颗好像还不是时候呢，再看看上面的线索呀～"
    new "Huh? It doesn't seem like it's time for this one yet. Take another look at the clues above!"

    old "唔……方向有点偏啦，想想刚才说的赤经方位？"
    new "Hmm... The direction is a bit off. Think about the right ascension position we just talked about."

    old "别急嘛，星星又不会跑掉，慢慢找就好啦～"
    new "Don't rush. The stars aren't going anywhere. Just take your time and look for them."

    old "这颗呀，不在这个星座里哦——是颗干扰星呢～"
    new "This one isn't part of this constellation – it's a stray star!"

    old "真实时钟。只在函数内部导入，避免把模块对象放进 store。"
    new "Real-time clock. Import only within functions to avoid placing module objects in the store."

    old "希实香"
    new "Kimika"

    old "用时 %.1fs"
    new "Time taken: %.1fs"

    old "失误 %d"
    new "Lapses"

    old "目标 %.0fs 内"
    new "Target within %.0fs"

    old "评价 %s　%d 分"
    new "Rating %s　%d points"

    old "提示 %d"
    new "Tip"

    old "重来"
    new "Retry"

    old "在查看器里翻页：只在已解锁的图之间循环，避免翻到未解锁的 CG。"
    new "Scroll through pages in the viewer: Only cycle through unlocked images to avoid scrolling to unlocked CGs."

    old "画 廊"
    new "Gallery"

    old "已收集 [gal_seen_count()] / [GALLERY_COUNT] 张"
    new "[gal_seen_count()]/[GALLERY_COUNT] cards collected"

    old "返 回"
    new "Return to"

    old "未解锁"
    new "Not unlocked"

    old "← / → 翻页　　ESC 关闭"
    new "← / → Turn the page and press ESC to close"

    old "按下一轨：先出声（像真的琴键），再做判定。"
    new "Press the next track: Sound first (like real piano keys), then make a judgment."

    old "当前真实时间（秒）。time 只在函数内部导入，避免把模块对象放进 store。"
    new "Current real time (in seconds). \"time\" is only imported within the function to avoid putting module objects into the store."

    old "《遙かなる夢に～》　下落式钢琴"
    new "\"Harukanaru Yume ni ~\" Drop piano"

    old "得分 %d　　连击 %d　　PERFECT %d　GOOD %d　MISS %d"
    new "Score %d　　Combo %d　　PERFECT %d　GOOD %d　MISS %d"

    old "咔+琴音"
    new "Click + Piano Sound"

    old "《遙かなる夢に～》"
    new "Harukanaru Yume ni ~"

    old "下落式钢琴，机器人的返场曲"
    new "Descending piano, robot encore"

    old "音符落到红色判定线时，按下对应的琴键"
    new "Press the corresponding key when the note falls on the red judgment line."

    old "键盘：1 2 3 4 5 6 7 8 9 0　　也可以用鼠标点击轨道"
    new "Keyboard: 1 2 3 4 5 6 7 8 9 0　　You can also click on the tracks with the mouse."

    old "116 个音符　约 1 分钟　完整右手旋律"
    new "116 notes　Approximately 1 minute　Full right-hand melody"

    old "空格 / 回车 / 点击下面的按钮　开始　　　ESC 放弃"
    new "Spacebar / Enter / Click the button below to start　　　ESC to quit"

    old "开始演奏"
    new "Start playing"

    old "演奏结束"
    new "Performance ended"

    old "评级 %s　%s"
    new "Rating %s　%s"

    old "得分 %d"
    new "Score"

    old "最大连击 %d　　准确率 %.1f%%"
    new "Max Combo %d　　Accuracy %.1f%%"

    old "再弹一次（空格）"
    new "Play again (spacebar)"

    old "回到剧情（回车 / ESC）"
    new "Return to the story (Enter/ESC)"

