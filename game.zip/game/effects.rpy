# ---------------------------------------------------------------------------
#  剧情演出特效（由 story 里的标记处调用）
# ---------------------------------------------------------------------------

# 天地旋转：药效发作时的眩晕感。
# 先放大到 1.18 倍再摆动，旋转时四个角不会露出黑边。
transform spin_dizzy:
    zoom 1.18
    xalign 0.5
    yalign 0.5
    rotate 0
    ease 0.60 rotate 13
    ease 0.60 rotate -13
    ease 0.55 rotate 10
    ease 0.55 rotate -10
    ease 0.60 rotate 0


# 强烈震动：冲击 / 重击时的画面抖动。
# 放大 1.06 倍，抖动时边缘不会露黑。
transform quake_strong:
    zoom 1.06
    xalign 0.5
    yalign 0.5
    xoffset 0
    yoffset 0
    linear 0.035 xoffset 24 yoffset -13
    linear 0.035 xoffset -22 yoffset 15
    linear 0.035 xoffset 19 yoffset -11
    linear 0.035 xoffset -15 yoffset 9
    linear 0.035 xoffset 11 yoffset -7
    linear 0.035 xoffset -7 yoffset 4
    linear 0.05 xoffset 0 yoffset 0


# 轻微震动：适合短促的冲击，不影响阅读。
transform quake_soft:
    zoom 1.03
    xalign 0.5
    yalign 0.5
    linear 0.03 xoffset 10 yoffset -6
    linear 0.03 xoffset -9 yoffset 7
    linear 0.03 xoffset 7 yoffset -4
    linear 0.03 xoffset -5 yoffset 3
    linear 0.04 xoffset 0 yoffset 0
