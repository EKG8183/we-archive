﻿# TODO: Translation updated at 2026-11-13 12:54

translate english strings:

    # game/options.rpy:14
    old "遙かなる夢に～"
    new "Harukanaru Yume ni ~"

