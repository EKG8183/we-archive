# -*- coding: utf-8 -*-
"""《遙かなる夢に～》下落式钢琴小游戏 —— 纯 Python 核心逻辑（不依赖 Ren'Py）。

这个文件放在 game/ 目录下，Ren'Py 的 importer 会把 game/ 加入模块搜索路径，
所以 game/piano_sea.rpy 里直接 ``import piano_sea_core`` 即可。
也可以脱离 Ren'Py 单独运行自检：

    python game/piano_sea_core.py

玩法：10 条轨道 = 一个八度加三度的白键 C5 D5 E5 F5 G5 A5 B5 C6 D6 E6，
音符从上往下落，落到判定线时按对应轨道的键（1 2 3 4 5 6 7 8 9 0），
也可以用鼠标点轨道。

谱面：旋律素材取自《海阔天空》(Beyond)，为完整右手单旋律（C 大调），
音高取自公开的社区键盘谱（见 SOURCE_SCORE），八度关系原样保留（高八度
的 C6/D6/E6 不会再被折回低八度），节奏做了简化：每个音一个键位、以
平均时值下落。全部用纯 Python 表达，方便单独测试。
"""

import collections

# ---------------------------------------------------------------------------
# 轨道定义
# ---------------------------------------------------------------------------

LANES = 10
LANE_NAMES = ("C", "D", "E", "F", "G", "A", "B", "C'", "D'", "E'")
LANE_PITCHES = ("C5", "D5", "E5", "F5", "G5", "A5", "B5", "C6", "D6", "E6")
LANE_KEYS = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
LANE_KEY_NAMES = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
LANE_COLORS = (
    "#3ec1f3", "#56d6a0", "#f0d264", "#f79a63", "#f2718c",
    "#b98cff", "#6f9dff", "#7fd7e8", "#8ce6c8", "#d9e9f7",
)
#: 真实钢琴采样（三角钢琴录音，44.1kHz / 192kbps）。
#: 低音衰减长、高音衰减短，音色比之前的合成音自然得多。
#: 文件来自 tonejs-instruments 的 acoustic piano 采样库。
LANE_SOUNDS = tuple("audio/piano/%s.mp3" % p.lower() for p in LANE_PITCHES)
MISS_SOUND = "audio/piano/miss.wav"

#: 第 i 条轨道与第 i+1 条轨道之间是否有一颗黑键。
#: 真实键盘上 E-F、B-C 之间没有黑键，画面上要留出这个缺口。
#: 音名带撇号（C' 表示高八度），所以只比较首字母。
_NO_SHARP_PAIRS = (("E", "F"), ("B", "C"))
LANE_HAS_SHARP_BETWEEN = tuple(
    (lo[0], hi[0]) not in _NO_SHARP_PAIRS for lo, hi in zip(LANE_NAMES, LANE_NAMES[1:])
)

# ---------------------------------------------------------------------------
# 节奏与判定参数
# ---------------------------------------------------------------------------

BPM = 72.0                # 慢速抒情曲速，方便上手
TAIL_BEATS = 2.0          # 最后一个音之后的空拍，让余音散开
PERFECT_WINDOW = 0.10     # ±0.10s 以内 PERFECT
GOOD_WINDOW = 0.22        # ±0.22s 以内 GOOD
LEAD_TIME = 2.4           # 音符从出现到判定线的飞行时间（秒）
TICK = 0.02               # 屏幕定时器的间隔（只决定刷新率，不决定游戏速度）
MAX_FRAME_TIME = 0.10     # 真实时钟单帧最多推进多少秒（防止卡顿后跳音符）
SCORE_PERFECT = 100
SCORE_GOOD = 50

#: 社区键盘谱（AutoPiano「自由钢琴」的键盘记谱格式）。
#: 键位 -> 音级：s=C5 d=D5 f=E5 g=F5 h=G5 j=A5 k=B5 l=C6 z=D6 x=E6
#: （完整右手单旋律，八度关系原样保留，不再把高八度折回低八度。）
SOURCE_SCORE = (
    "fds dfhhhhjh jkllllllkjhj "
    "jhh hfds fgfddfdd fdddssss dss "
    "jkllllllkjhhhfds "
    "llllzzzlzx xzl "
    "llllzz hhxzl "
    "llllzzzzlkl "
    "jjkjkl llzlzx xzxl"
)
SOURCE_KEYMAP = {"s": 0, "d": 1, "f": 2, "g": 3, "h": 4, "j": 5, "k": 6, "l": 7, "z": 8, "x": 9}

#: 每小节的时值（4/4 拍）。每小节合计 4 拍，节拍与小节内音符数一一对应。
BEAT_BARS = (
    (1.0, 1.0, 2.0),                                             # 原谅我
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 这一生 不羁放纵
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 爱 自 由——
    (0.5, 0.5, 1.0, 2.0),                                        # 过渡句
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1.0),                         # 也会怕 有一天会跌倒
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 背弃了理想
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 谁人都可以
    (1.0, 1.0, 2.0),                                             # 句尾
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 哪会怕 有 一 天
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 只 你 共 我
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 仍然 自由 自我
    (0.5, 0.5, 1.0, 1.0, 1.0),                                   # 永远 高唱
    (0.5, 0.5, 0.5, 0.5, 0.5, 1.5),                              # 仍然 自由 自我
    (0.5, 0.5, 1.0, 1.0, 1.0),                                   # 我 歌
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 走遍 千里
    (1.0, 1.0, 2.0),                                             # 句尾
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 副歌再现
    (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5),                    # 走遍千里
)

RANK_TITLES = {
    "S": "完美演绎",
    "A": "相当出色",
    "B": "还算流畅",
    "C": "有点勉强",
    "D": "仍需练习",
}

FEEDBACK_COLORS = {
    "perfect": "#7ef0c0",
    "good": "#f0d264",
    "miss": "#ff7b8a",
}


# ---------------------------------------------------------------------------
# 歌词（演奏时逐句显示，每句同时给出日语与中文对照）
# ---------------------------------------------------------------------------

LYRICS = (
    ("遠く遥かな歌が", "遥远的歌声"),
    ("たえまなく聞こえてくる", "阵阵的传来"),
    ("微笑みを讃(たた)えるように", "像是装满了微笑"),
    ("ときに優しく強く…", "有时温柔有时坚强"),
    ("(Don't be afraid)", "（别害怕）"),
    ("思い悩み傷つき", "思想烦恼受伤害"),
    ("眠れない夜もあった", "也有受挫的夜晚"),
    ("信じ合い 肩を支えて", "互相信赖　互相支持"),
    ("励ましあったあの日", "互相勉励的那一天"),
    ("(Don't worry friend)", "（别担心 朋友）"),
    ("終わりのない旅の途中で", "在这没有结束的旅途中"),
    ("振り向けば君がいる", "我一回头总是看到你"),
    ("人は皆ひとりきりじゃ", "人总是无法"),
    ("生きてゆけないから…", "自己一个人活下去"),
    ("広い大地の上に", "在广大的大地上"),
    ("寝転んで見あげた空", "躺着看天空"),
    ("果てしない銀河の流れ", "没有尽头的银河"),
    ("いつもこの地球(ほし)つつむ", "总是包围着地球"),
    ("(Don't be afraid)", "（别害怕）"),
    ("たとえ街は荒んでいっても", "就算街上一片荒凉"),
    ("夢をみる力が", "做梦的力量"),
    ("この胸に希望の鐘", "明日将会在我胸中"),
    ("明日(あす)も鳴らすだろう", "敲响希望的钟"),
    ("また新しい 物語を生きるよ", "会再走过一个新的人生"),
    ("終わりのない旅の途中で", "在这没有结束的旅途中"),
    ("振り向けば君がいる", "我一回头总是看到你"),
    ("人は皆ひとりきりじゃ", "人总是无法"),
    ("生きてゆけないから…", "自己一个人活下去"),
    ("この胸に希望の鐘", "明日将会在我胸中"),
    ("明日(あす)も鳴らすだろう", "敲响希望的钟"),
    ("終わりのない旅の途中で", "在这没有结束的旅途中"),
    ("振り向けば君がいる", "我一回头总是看到你"),
    ("人は皆ひとりきりじゃ", "人总是无法"),
    ("生きてゆけないから…", "自己一个人活下去"),
)

# 歌词分段：与海阔天空原曲结构（也就是 SOURCE_SCORE 的 7 行乐句）一一对应，
# 依据用户提供的《海阔天空↔遥远的梦》歌词对应表。
# 每项 = (该段用到的 LYRICS 起止下标[含首不含尾], 起止小节[含首不含尾])。
# 每小节 4 拍，SOURCE_SCORE 共 18 小节。
# 结构：主歌1 / 主歌2 / 副歌 / 主歌1 / 副歌 / 桥段 / 副歌收尾。
LYRIC_SECTIONS = (
    (0, 5, 0, 4),        # 遠く遥かな歌が…Don't be afraid（主歌1）
    (5, 10, 4, 8),       # 思い悩み傷つき…Don't worry friend（主歌2）
    (10, 14, 8, 10),     # 終わりのない旅…生きてゆけないから（副歌）
    (14, 19, 10, 12),    # 広い大地の上に…Don't be afraid（主歌1）
    (19, 24, 12, 14),    # たとえ街は荒んで…物語を生きるよ（副歌）
    (24, 28, 14, 16),    # 終わりのない旅…生きてゆけないから（桥段）
    (28, 34, 16, 18),    # この胸に希望の鐘…生きてゆけないから（副歌收尾）
)


def _build_lyric_timeline():
    """把歌词按分段均匀铺到对应小节上，返回 [(start_beat, jp, cn), ...]。"""
    out = []
    for ls, le, start_bar, end_bar in LYRIC_SECTIONS:
        start_beat = start_bar * 4.0
        span = (end_bar - start_bar) * 4.0
        count = le - ls
        for i in range(count):
            beat = start_beat + span * i / count
            jp, cn = LYRICS[ls + i]
            out.append((round(beat, 3), jp, cn))
    return tuple(out)


_LYRIC_TIMELINE = _build_lyric_timeline()


def lyric_at_time(t, bpm=BPM):
    """返回歌曲时间 t（秒）对应的歌词 (日语, 中文)；还没到第一句则返回 None。"""
    if t < 0:
        return None
    beat = t * bpm / 60.0
    active = None
    for start_beat, jp, cn in _LYRIC_TIMELINE:
        if start_beat <= beat:
            active = (jp, cn)
        else:
            break
    return active


# ---------------------------------------------------------------------------
# 谱面
# ---------------------------------------------------------------------------

def parse_source(score=SOURCE_SCORE):
    """把键盘谱文本解析成轨道序列。空白与未知字符会被忽略。"""
    return [SOURCE_KEYMAP[ch] for ch in score if ch in SOURCE_KEYMAP]


def chart_lanes():
    # 完整右手单旋律：原样保留每个音，不做同音连打折叠。
    return parse_source()


def beat_list():
    beats = []
    for bar in BEAT_BARS:
        beats.extend(bar)
    return beats


Note = collections.namedtuple("Note", "index time lane duration")


def build_chart(bpm=BPM, tail_beats=TAIL_BEATS):
    """返回 (notes, song_end)。notes 为 Note(index, time, lane, duration) 元组。"""
    beat = 60.0 / float(bpm)
    lanes = chart_lanes()
    beats = beat_list()
    if len(lanes) != len(beats):
        raise ValueError("谱面音符数 %d 与时值数 %d 不一致" % (len(lanes), len(beats)))

    notes = []
    t = 0.0
    for i, (lane, num_beats) in enumerate(zip(lanes, beats)):
        notes.append(Note(i, round(t, 6), lane, round(num_beats * beat, 6)))
        t += num_beats * beat
    return tuple(notes), round(t + tail_beats * beat, 6)


# ---------------------------------------------------------------------------
# 游戏状态机
# ---------------------------------------------------------------------------

class RhythmGame(object):
    """下落式音游的判定与记分。所有时间都是「歌曲时间」（秒）。

    phase: "ready" -> "play" -> "result"
    """

    def __init__(self, notes, song_end, lane_count=LANES, tick=TICK,
                 perfect=PERFECT_WINDOW, good=GOOD_WINDOW, lead=LEAD_TIME):
        self.notes = tuple(notes)
        self.song_end = float(song_end)
        self.lane_count = int(lane_count)
        self.tick = float(tick)
        self.perfect = float(perfect)
        self.good = float(good)
        self.lead = float(lead)

        self.time = -self.lead           # 第一个音在 0.0s，提前 lead 秒开始下落
        self.phase = "ready"
        self.finished = False
        self.wall_now = None             # tick_wall() 用的上一帧真实时间戳

        self.judged = [None] * len(self.notes)
        self.score = 0
        self.combo = 0
        self.max_combo = 0
        self.perfect_count = 0
        self.good_count = 0
        self.miss_count = 0

        self.feedback = ""
        self.feedback_kind = ""
        self.feedback_lane = 0
        self.feedback_time = -99.0

        self.flash = [-99.0] * self.lane_count      # 每条轨道的按键高亮时刻
        self.miss_lane = -1                         # 最近一次 miss 的轨道

    # -- 流程 ---------------------------------------------------------------
    def start(self):
        if self.phase == "ready":
            self.phase = "play"
            self.wall_now = None

    def tick_wall(self, now):
        """用真实时钟推进游戏（`now` 是 time.monotonic() 的秒数）。

        Ren'Py 屏幕里的 timer 只保证「按间隔重复触发」，实际触发频率会随帧率
        和机器而变：如果按「每次固定加 0.02 秒」来计时，曲子会随帧率高低下
        漂移（实测会有 2%~4% 的偏差，帧率越低越明显）。这里改成按真实经过的
        时间推进，并对单帧时长做钳制，以免卡顿或窗口失焦后音符瞬间跳过去。
        """
        if self.phase != "play":
            return []
        if self.wall_now is None:
            self.wall_now = now
            return []
        dt = now - self.wall_now
        self.wall_now = now
        if dt <= 0.0:
            return []
        return self.advance(min(dt, MAX_FRAME_TIME))

    def advance(self, dt=None):
        """推进一个逻辑步长，返回这一步新漏掉的音符下标列表。"""
        if self.phase != "play":
            return []
        if dt is None:
            dt = self.tick
        self.time += dt

        missed = []
        for i, note in enumerate(self.notes):
            if self.judged[i] is None and self.time > note.time + self.good:
                self.judged[i] = "miss"
                self.miss_count += 1
                self.combo = 0
                self.miss_lane = note.lane
                missed.append(i)
                self._feedback("miss", note.lane, self.time)

        if self.time >= self.song_end:
            self.finished = True
            self.phase = "result"
        return missed

    # -- 输入 ---------------------------------------------------------------
    def press(self, lane):
        """按下某条轨道。返回 "perfect" / "good" / None（没有可判定的音符）。"""
        if self.phase != "play" or not (0 <= lane < self.lane_count):
            return None
        self.flash[lane] = self.time

        best_index = None
        best_delta = None
        for i, note in enumerate(self.notes):
            if note.lane != lane or self.judged[i] is not None:
                continue
            delta = abs(note.time - self.time)
            if delta <= self.good and (best_delta is None or delta < best_delta):
                best_index, best_delta = i, delta
        if best_index is None:
            return None

        kind = "perfect" if best_delta <= self.perfect else "good"
        self.judged[best_index] = kind
        if kind == "perfect":
            self.perfect_count += 1
            self.score += SCORE_PERFECT
        else:
            self.good_count += 1
            self.score += SCORE_GOOD
        self.combo += 1
        self.max_combo = max(self.max_combo, self.combo)
        self._feedback(kind, lane, self.time)
        return kind

    def _feedback(self, kind, lane, when):
        self.feedback_kind = kind
        self.feedback_lane = lane
        self.feedback_time = when
        self.feedback = {"perfect": "PERFECT", "good": "GOOD", "miss": "MISS"}[kind]

    # -- 视图数据 -----------------------------------------------------------
    def active(self):
        """返回当前要绘制的音符 [(Note, state)]，state 为 None / "miss"。"""
        out = []
        for i, note in enumerate(self.notes):
            delta = note.time - self.time
            state = self.judged[i]
            if state in ("perfect", "good"):
                continue          # 命中后立刻消失，由判定线特效代替
            if delta < -0.6:
                continue          # 已经滑出屏幕
            if delta > self.lead:
                continue          # 还没进入屏幕
            out.append((note, state))
        return out

    def falling(self, speed, judge_y, top_y, bottom_y):
        """返回当前要画的音符 [(lane, y, missed)]。

        屏幕坐标在 Python 里一次算好，屏幕只管画，避免在 screen 的循环里写
        Python 表达式。注意 `y` 一律是 **整数**：Ren'Py 的 xpos/ypos 把浮点数
        当作「容器的百分比」，只有整数才是像素，所以这里必须先取整。
        坐标超出 [top_y, bottom_y] 的音符不会返回。
        """
        out = []
        for i, note in enumerate(self.notes):
            state = self.judged[i]
            if state in ("perfect", "good"):
                continue          # 命中后立刻消失
            delta = note.time - self.time
            if delta < -0.6 or delta > self.lead:
                continue          # 还没进屏幕 / 已经滑出屏幕
            y = int(round(judge_y - delta * speed))
            if y < top_y or y > bottom_y:
                continue
            out.append((note.lane, y, state == "miss"))
        return out

    def press_lanes(self, fade=0.18):
        """返回当前处于「按下高亮」状态的轨道集合。"""
        return set(i for i in range(self.lane_count)
                   if self.time - self.flash[i] < fade)

    def progress(self):
        if self.song_end <= 0:
            return 1.0
        return max(0.0, min(1.0, self.time / self.song_end))

    def judged_count(self):
        return sum(1 for j in self.judged if j is not None)

    def accuracy(self):
        """加权准确率：PERFECT 记 1 分，GOOD 记 0.5 分，MISS 记 0 分。"""
        total = len(self.notes)
        if total == 0:
            return 0.0
        return (self.perfect_count * 1.0 + self.good_count * 0.5) / total

    def rank(self):
        return rank_for(self.accuracy())

    def rank_title(self):
        return RANK_TITLES.get(self.rank(), "")

    def stats(self):
        return {
            "score": self.score,
            "combo": self.max_combo,
            "perfect": self.perfect_count,
            "good": self.good_count,
            "miss": self.miss_count,
            "total": len(self.notes),
            "accuracy": self.accuracy(),
            "rank": self.rank(),
            "rank_title": self.rank_title(),
        }


def rank_for(accuracy):
    if accuracy >= 0.95:
        return "S"
    if accuracy >= 0.85:
        return "A"
    if accuracy >= 0.70:
        return "B"
    if accuracy >= 0.50:
        return "C"
    return "D"


# ---------------------------------------------------------------------------
# 自检：python game/piano_sea_core.py
# ---------------------------------------------------------------------------

#: 独立写死的轨道序列（不通过 SOURCE_SCORE 推导，用于交叉验证谱面）
EXPECTED_LANES = (
    "210" "12444454" "56777777" "6545"
    "5444210" "23211211" "21110000" "100"
    "56777777" "65444210" "77778887" "89987"
    "777788" "44987" "77778888" "767"
    "55656777" "87899897"
)


def _selftest():
    fails = []

    def check(cond, msg):
        if cond:
            print("  [ok]   %s" % msg)
        else:
            print("  [FAIL] %s" % msg)
            fails.append(msg)

    print("1) 谱面数据")
    notes, song_end = build_chart()
    lanes = chart_lanes()
    check("".join(str(x) for x in lanes) == EXPECTED_LANES,
          "轨道序列与独立写死的期望值一致 (%d 个音)" % len(lanes))
    check(len(notes) == len(lanes) == len(beat_list()),
          "音符数 = 时值数 = %d" % len(notes))
    check(len(notes) == 116, "总音符数 116")
    check(all(0 <= n.lane < LANES for n in notes), "所有音都在 0..9 号轨道内")
    check(all(b.time > a.time for a, b in zip(notes, notes[1:])), "时间严格递增")
    gaps = [b.time - a.time for a, b in zip(notes, notes[1:])]
    check(min(gaps) >= 0.30,
          "最小音符间隔 %.3fs >= 0.30s（足够简单，不会出现连打）" % min(gaps))
    check(max(gaps) <= 1.70, "最大音符间隔 %.3fs（句尾长音，不超过 2 拍）" % max(gaps))
    check(notes[0].time == 0.0, "第一个音在 0.0s")
    check(abs(song_end - (notes[-1].time + notes[-1].duration + TAIL_BEATS * 60.0 / BPM)) < 1e-6,
          "曲终时间 %.3fs 等于最后音符 + 尾巴" % song_end)
    check(set(n.lane for n in notes) == set(range(LANES)), "10 条轨道全部用到")
    check(LANE_HAS_SHARP_BETWEEN == (True, True, False, True, True, True, False, True, True),
          "黑键分布正确：E-F 与 B-C 之间没有黑键")

    print("2) 完美演奏")
    g = RhythmGame(notes, song_end)
    g.start()
    check(g.phase == "play", "start() 后进入 play")
    check(abs(g.time + LEAD_TIME) < 1e-9, "起始歌曲时间为 -LEAD_TIME")
    for n in notes:
        g.advance(n.time - g.time)
        kind = g.press(n.lane)
        if kind != "perfect":
            check(False, "第 %d 个音被判成 %r" % (n.index, kind))
            break
        g.advance(0.001)
    else:
        check(True, "%d 个音全部 PERFECT" % len(notes))
    g.advance(song_end - g.time + 0.5)
    check(g.finished and g.phase == "result", "曲终后 finished/result")
    check(g.score == len(notes) * SCORE_PERFECT, "满分 %d" % g.score)
    check(g.max_combo == len(notes), "最大连击 %d" % g.max_combo)
    check(abs(g.accuracy() - 1.0) < 1e-9 and g.rank() == "S", "准确率 1.0 / 评级 S")

    print("2b) 真实时钟 tick_wall()")
    g6 = RhythmGame(notes, song_end)
    g6.start()
    check(g6.tick_wall(1000.0) == [], "第一次调用只记录时间，不推进")
    check(g6.time == -LEAD_TIME, "第一次调用后歌曲时间不变")
    g6.tick_wall(1000.0)
    check(g6.tick_wall(1000.1) == [] and abs(g6.time - (-LEAD_TIME + 0.1)) < 1e-9,
          "0.1 秒真实时间 = 0.1 秒歌曲时间")
    g6.tick_wall(1005.0)
    check(abs(g6.time - (-LEAD_TIME + 0.2)) < 1e-9,
          "卡顿 4.9 秒只推进 %.2fs（钳制在 MAX_FRAME_TIME）" % MAX_FRAME_TIME)
    g6.tick_wall(1005.0)
    check(abs(g6.time - (-LEAD_TIME + 0.2)) < 1e-9, "时间未前进时不推进")
    big = RhythmGame(notes, song_end)
    big.start()
    big.tick_wall(0.0)
    for i in range(1, 4001):                     # 以 60fps 跑 66 秒
        big.tick_wall(i / 60.0)
    check(big.finished and big.time >= song_end,
          "按 60fps 真实时钟跑完整曲（%.2fs）" % big.time)
    check(big.rank() == "S" or big.judged_count() >= len(notes), "真实时钟下所有音符都被判定（miss=%d）" % big.miss_count)

    print("3) 完全不按")
    g2 = RhythmGame(notes, song_end)
    g2.start()
    g2.advance(song_end + 1.0)
    check(g2.miss_count == len(notes) and g2.score == 0, "全部 MISS、0 分")
    check(g2.accuracy() == 0.0 and g2.rank() == "D", "准确率 0 / 评级 D")

    print("4) 判定细节")
    g3 = RhythmGame(notes, song_end)
    g3.start()
    g3.advance(LEAD_TIME + notes[0].time - 0.30)      # 早于 GOOD 窗口
    check(g3.press(notes[0].lane) is None, "窗口外按键不判定、不计分")
    check(g3.score == 0 and g3.combo == 0, "无效按键不影响分数")
    g3.advance(0.30 - 0.06)                            # 距音符 0.06s -> PERFECT
    check(g3.press(notes[0].lane) == "perfect", "0.06s 内判 PERFECT")
    g3.advance(notes[1].time - g3.time - 0.16)         # 距下一个音 0.16s -> GOOD
    check(g3.press(notes[1].lane) == "good", "0.16s 内判 GOOD")
    g3.advance(notes[2].time + GOOD_WINDOW + 0.05 - g3.time)
    check(g3.miss_count >= 1, "超时自动 MISS")
    check(len(g3.active()) >= 1, "active() 里还有后续音符")
    check(g3.progress() > 0.0, "progress() 正常")

    print("5) 输入 / 视图接口")
    g4 = RhythmGame(notes, song_end)
    check(g4.press(0) is None, "ready 阶段不接受输入")
    g4.start()
    check(g4.press(99) is None and g4.press(-1) is None, "非法轨道返回 None")
    vis = g4.active()
    check(all(isinstance(v[0], Note) for v in vis), "active() 返回 (Note, state)")
    times_now = [v[0].time for v in vis]
    check(times_now == sorted(times_now), "落下的音符按时间排好序")

    print("5b) 屏幕坐标换算 falling()")
    SPEED, JUDGE_Y, TOP_LIMIT, BOTTOM_LIMIT = 265.833, 806, 78, 956
    g5 = RhythmGame(notes, song_end)
    g5.start()
    g5.advance(LEAD_TIME)                       # 歌曲时间回到 0
    rows = g5.falling(SPEED, JUDGE_Y, TOP_LIMIT, BOTTOM_LIMIT)
    check(len(rows) >= 1, "时间 0 时有音符要画（%d 个）" % len(rows))
    check(all(len(r) == 3 for r in rows), "每行是 (lane, y, missed)")
    check(all(isinstance(r[1], int) for r in rows),
          "y 必须是 int —— 浮点会被 Ren'Py 当成容器百分比")
    check(all(TOP_LIMIT <= r[1] <= BOTTOM_LIMIT for r in rows), "所有 y 都落在可视范围内")
    check(rows[0][0] == notes[0].lane and rows[0][1] == JUDGE_Y,
          "第一个音正好停在判定线上 (lane=%d y=%d)" % (rows[0][0], rows[0][1]))
    check(rows[0][2] is False, "未判定音符 missed=False")
    g5.advance(0.5)
    rows2 = g5.falling(SPEED, JUDGE_Y, TOP_LIMIT, BOTTOM_LIMIT)
    check(rows2 and rows2[0][1] > rows[0][1], "时间前进后音符向下移动")
    check(any(r[2] for r in rows2), "漏掉的音符以 missed=True 继续下坠")
    check(g5.falling(SPEED, JUDGE_Y, 1e9, 2e9) == [], "全部超出范围时不画任何东西")
    g5.time = -LEAD_TIME
    rows3 = g5.falling(SPEED, JUDGE_Y, TOP_LIMIT, BOTTOM_LIMIT)
    check(rows3 and rows3[0][1] == int(round(JUDGE_Y - LEAD_TIME * SPEED)),
          "刚出现时音符处在轨道顶端 y=%s" % (rows3[0][1] if rows3 else None))
    for _ in range(5):
        g4.advance()
    check(isinstance(g4.press_lanes(), set), "press_lanes() 返回集合")
    check(set(g4.stats()) == {"score", "combo", "perfect", "good", "miss",
                              "total", "accuracy", "rank", "rank_title"},
          "stats() 字段齐全")

    print("6) 评级阈值")
    check([rank_for(a) for a in (1.0, 0.9, 0.75, 0.6, 0.3)] == list("SABCD"),
          "0.95/0.85/0.70/0.50 分档正确")

    print("7) 歌词")
    check(len(LYRICS) == 34, "歌词共 34 句")
    check(all(len(p) == 2 for p in LYRICS), "每句都是 (日语, 中文) 两元组")
    check(len(_LYRIC_TIMELINE) == 34, "歌词时间轴共 34 条")
    check(all(a[0] <= b[0] for a, b in zip(_LYRIC_TIMELINE, _LYRIC_TIMELINE[1:])),
          "歌词时间轴单调不减")
    check(lyric_at_time(-0.1) is None, "歌曲开始前无歌词")
    check(lyric_at_time(0.0) == LYRICS[0], "第 0 秒显示第一句（主歌1）")
    check(lyric_at_time(13.0) == LYRICS[4], "第 13 秒仍在主歌1（Don't be afraid）")
    check(lyric_at_time(14.0) == LYRICS[5], "第 14 秒进入主歌2（思い悩み傷つき）")
    check(lyric_at_time(28.0) == LYRICS[10], "第 28 秒进入副歌（終わりのない旅）")
    check(lyric_at_time(54.0) == LYRICS[28], "第 54 秒进入副歌收尾（この胸に希望の鐘）")
    check(lyric_at_time(1e9) == LYRICS[-1], "超出长度时停在最后一句")

    print("")
    if fails:
        print("自检失败 %d 项：" % len(fails))
        for f in fails:
            print("  - %s" % f)
        return 1
    print("全部自检通过：%d 个音符，%.1f 秒，%d 条轨道，最慢间隔 %.3fs"
          % (len(notes), song_end, LANES, min(gaps)))
    return 0


if __name__ == "__main__":
    raise SystemExit(_selftest())
