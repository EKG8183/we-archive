# -*- coding: utf-8 -*-
"""星座连线小游戏的纯逻辑与数据（不依赖 Ren'Py，可单独运行自测）。

    python game/constellation_core.py

之所以把星位、线索、评分放在这里而不是直接写在 .rpy 里：
几何关系（星星间距、是否越界）和评分曲线都是可以静态验证的，
放在纯 Python 模块里就能在没装 Ren'Py SDK 的情况下跑自检。
"""

#: 星图底板的落位与尺寸，与 screen 里 board.png 的 xpos/ypos 保持一致。
BOARD = (340, 190, 1240, 700)

#: 星线 PNG 四周留白，素材生成脚本与这里的 crop 计算必须用同一个值。
LINE_PAD = 70

#: 星星点击区边长
STAR_HIT = 128
#: 干扰星点击区边长（更小，减少误触）
DECOY_HIT = 80

#: 任意两个可点目标的最小中心距。
#: 小于这个值时，相邻目标的点击区会重叠，玩家想点 A 却点到 B。
MIN_TARGET_GAP = 132

#: 每个星座可用的提示次数
CONSTELLATION_HINTS = 3

#: 目标时间（秒）。超时不失败，只影响评价。
CONSTELLATION_TARGET = 90.0

#: 时间惩罚上限。慢只会压一档，不会因为看得久就判不及格。
TIME_PENALTY_CAP = 30.0

CONSTELLATIONS = {
    "summer": {
        "title": "夏日大三角",
        "hint": "夏日大三角：织女、天津四、牛郎——三颗一等亮星跨着银河相望呢",
        "stars": (
            ("织女星", 760, 330),
            ("天津四", 1200, 265),
            ("牛郎星", 1330, 640),
        ),
        # 每一步的线索：只描述位置和相对关系，不直接报名字。
        "clues": (
            "嗯——最亮的那颗在星图左上角哦，视星等很低，是全天排得上号的亮星呢～",
            "从它往右平移过去呀，会碰到更高的一颗；那是颗白色超巨星呢。",
            "最后一颗在右下角啦，和第一颗隔着好大一段赤经，遥遥相对的样子哦～",
        ),
        # 干扰星：不属于这个星座，点中只提示、不影响已有进度。
        "decoys": (
            (930, 640),
            (1120, 780),
        ),
    },
    "orion": {
        "title": "猎户座",
        "hint": "猎户座：肩、腰带、双腿——一条挂着三星腰带的冬季巨人哦",
        "stars": (
            ("参宿四", 720, 320),
            ("参宿五", 960, 350),
            ("参宿三", 1090, 487),
            ("参宿二", 950, 505),
            ("参宿一", 810, 523),
            ("参宿六", 760, 720),
            ("参宿七", 1010, 700),
        ),
        "clues": (
            "先从左上角那颗偏红的开始吧——那是颗红超巨星，颜色一眼就能认出来呢。",
            "往右一点呀，还有颗同样亮的肩星哦，偏蓝的，又年轻又高温呢～",
            "往下走啦，去找腰带的右端；猎户腰带那三颗，可是这个星座最有名的标志哦。",
            "腰带横着排三颗，取中间那颗吧，它离我们挺远的呢。",
            "继续沿腰带往左，最后一颗——它旁边还藏着一颗伴星，挺有名的哦～",
            "从腰带往下，走左下那条腿；那是颗蓝白超巨星呢。",
            "最后收在右下那条腿啦——蓝白超巨星，视星等很低，全天排前几的亮星哦～",
        ),
        "decoys": (
            (1180, 720),
            (600, 460),
            (1150, 300),
        ),
    },
}

CONSTELLATION_ORDER = ("summer", "orion")


def stars_of(name):
    return CONSTELLATIONS[name]["stars"]


def decoys_of(name):
    return CONSTELLATIONS[name]["decoys"]


def clues_of(name):
    return CONSTELLATIONS[name]["clues"]


def crop_of(name):
    """星线 PNG 的裁切原点，由星位推出，避免和素材脚本各写一份而走样。"""
    stars = stars_of(name)
    x0 = min(s[1] for s in stars) - LINE_PAD
    y0 = min(s[2] for s in stars) - LINE_PAD
    return (x0, y0)


def link_stage(step, total):
    """连星进度档位：0 前段 / 1 中段 / 2 后段，用来选不同音高的音效。"""
    if total <= 1:
        return 0
    frac = step / float(total)
    if frac < 0.40:
        return 0
    if frac < 0.75:
        return 1
    return 2


def grade(elapsed, errors, hints_used):
    """把用时 / 失误 / 提示折算成 0~100 分与 S/A/B/C 评价。

    时间惩罚是**封顶**的：慢只会把分数压下去一档，不会因为慢慢看星星
    就判成不及格——这个游戏是用来欣赏夜空的，不是竞速。
    """
    time_penalty = min(TIME_PENALTY_CAP, max(0.0, elapsed - CONSTELLATION_TARGET * 0.5) * 0.35)
    score = 100.0 - errors * 6.0 - hints_used * 10.0 - time_penalty
    score = max(0.0, min(100.0, score))
    if score >= 90.0:
        rank = "S"
    elif score >= 75.0:
        rank = "A"
    elif score >= 60.0:
        rank = "B"
    else:
        rank = "C"
    return score, rank


def _selftest():
    problems = []
    bx, by, bw, bh = BOARD

    for name in CONSTELLATION_ORDER:
        data = CONSTELLATIONS[name]
        stars = data["stars"]
        decoys = data["decoys"]

        if len(data["clues"]) != len(stars):
            problems.append("%s：线索 %d 条，星星 %d 颗，数量不一致"
                            % (name, len(data["clues"]), len(stars)))
        if not decoys:
            problems.append("%s：没有干扰星" % name)

        # 所有可点目标都必须在底板内，且点击区不越界
        for label, x, y, hit in (
                [(s[0], s[1], s[2], STAR_HIT) for s in stars] +
                [("干扰星%d" % i, d[0], d[1], DECOY_HIT) for i, d in enumerate(decoys)]):
            half = hit / 2.0
            if not (bx + half <= x <= bx + bw - half):
                problems.append("%s：%s 的 x=%d 越界" % (name, label, x))
            if not (by + half <= y <= by + bh - half):
                problems.append("%s：%s 的 y=%d 越界" % (name, label, y))

        # 任意两个目标之间要有足够间距，否则点击区重叠会点错
        pts = [(s[0], s[1], s[2]) for s in stars] + \
              [("干扰星%d" % i, d[0], d[1]) for i, d in enumerate(decoys)]
        for i in range(len(pts)):
            for j in range(i + 1, len(pts)):
                gap = ((pts[i][1] - pts[j][1]) ** 2 + (pts[i][2] - pts[j][2]) ** 2) ** 0.5
                if gap < MIN_TARGET_GAP:
                    problems.append("%s：%s 与 %s 只隔 %.0fpx（下限 %d）"
                                    % (name, pts[i][0], pts[j][0], gap, MIN_TARGET_GAP))

        # 线索不能是空串
        for i, clue in enumerate(data["clues"]):
            if not clue.strip():
                problems.append("%s：第 %d 条线索为空" % (name, i + 1))

    # 评分：表现越好分越高，且等级不会倒退
    perfect = grade(20.0, 0, 0)
    good = grade(60.0, 1, 1)
    poor = grade(200.0, 6, 3)
    if not (perfect[0] > good[0] > poor[0]):
        problems.append("评分不单调：%s / %s / %s" % (perfect[0], good[0], poor[0]))
    if perfect[1] != "S":
        problems.append("零失误零提示却不是 S：%s" % (perfect[1],))
    if poor[1] not in ("B", "C"):
        problems.append("表现很差却给了 %s" % (poor[1],))

    # 音效档位：随进度不倒退，且落在 0~2
    for name in CONSTELLATION_ORDER:
        total = len(stars_of(name))
        stages = [link_stage(step, total) for step in range(1, total + 1)]
        if stages != sorted(stages):
            problems.append("%s：音效档位随进度倒退 %s" % (name, stages))
        if stages[0] != 0 or stages[-1] != 2:
            problems.append("%s：档位没有覆盖前段/后段 %s" % (name, stages))
        if any(s not in (0, 1, 2) for s in stages):
            problems.append("%s：档位越界 %s" % (name, stages))

    # crop 必须与素材脚本的裁切一致（留白一致）
    for name in CONSTELLATION_ORDER:
        stars = stars_of(name)
        x0, y0 = crop_of(name)
        if x0 != min(s[1] for s in stars) - LINE_PAD:
            problems.append("%s：crop 计算异常" % name)
        if y0 != min(s[2] for s in stars) - LINE_PAD:
            problems.append("%s：crop 计算异常" % name)

    if problems:
        print("星座核心自检失败：")
        for p in problems:
            print("  -", p)
        return False

    print("星座核心自检通过：%d 个星座" % len(CONSTELLATION_ORDER))
    for name in CONSTELLATION_ORDER:
        stars = stars_of(name)
        print("  %-8s %d 颗星 + %d 颗干扰星，crop=%s，档位=%s"
              % (CONSTELLATIONS[name]["title"], len(stars),
                 len(decoys_of(name)), crop_of(name),
                 [link_stage(s, len(stars)) for s in range(1, len(stars) + 1)]))
    return True


if __name__ == "__main__":
    import sys
    sys.exit(0 if _selftest() else 1)
