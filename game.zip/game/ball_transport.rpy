# 透明背景推球迷宫小游戏（两关）。
# 玩家需要把三种颜色的小球推到对应颜色的出口；结果只影响对白。

default ball_transport_result = False
default ball_transport_state = None

init python:
    class BallTransportState(object):
        WIDTH = 8
        HEIGHT = 6
        COLORS = {"red": "#F05A68", "blue": "#58B7FF", "gold": "#FFD45C"}

        # 三关递进：第一关开放好上手，第二关需要绕路，第三关墙壁更密。
        LEVELS = (
            {
                "walls": frozenset((
                    (2, 0), (5, 0),
                    (5, 1),
                    (5, 2),
                    (2, 3), (5, 3),
                    (2, 4),
                    (2, 5),
                )),
                "player": (0, 0),
                "balls": {"red": (1, 2), "blue": (4, 3), "gold": (6, 5)},
                "targets": {"red": (3, 2), "blue": (4, 5), "gold": (7, 5)},
            },
            {
                "walls": frozenset((
                    (0, 0), (1, 0), (7, 0),
                    (1, 2), (4, 2),
                    (0, 3), (4, 3),
                    (4, 5), (7, 5),
                )),
                "player": (1, 3),
                "balls": {"red": (4, 4), "blue": (5, 2), "gold": (5, 4)},
                "targets": {"red": (3, 4), "blue": (4, 1), "gold": (5, 1)},
            },
            {
                "walls": frozenset((
                    (0, 0), (3, 0), (4, 0),
                    (4, 2), (7, 2),
                    (1, 3),
                    (0, 4), (3, 4), (4, 4),
                    (0, 5), (2, 5), (5, 5), (6, 5),
                )),
                "player": (0, 1),
                "balls": {"red": (3, 2), "blue": (4, 1), "gold": (6, 1)},
                "targets": {"red": (5, 2), "blue": (1, 2), "gold": (5, 4)},
            },
        )

        def __init__(self):
            self.reset()

        def reset(self):
            self.level = 0
            self.load_level()

        def load_level(self):
            data = self.LEVELS[self.level]
            self.walls = data["walls"]
            self.player = data["player"]
            self.balls = dict(data["balls"])
            self.targets = data["targets"]
            self.moves = 0
            self.finished = False
            self.cleared = False
            self.message = "第 %d 关：把小球推到对应颜色出口" % (self.level + 1)

        def restart_level(self):
            self.load_level()

        @property
        def last_level(self):
            return self.level >= len(self.LEVELS) - 1

        def ball_at(self, pos):
            for color, location in self.balls.items():
                if location == pos:
                    return color
            return None

        def blocked(self, pos):
            return (pos[0] < 0 or pos[0] >= self.WIDTH or
                    pos[1] < 0 or pos[1] >= self.HEIGHT or pos in self.walls)

        def move(self, dx, dy):
            if self.cleared:
                return
            target = (self.player[0] + dx, self.player[1] + dy)
            if self.blocked(target):
                sfx(SFX_BLOCKED, "sfx_move", 0.5)
                return
            color = self.ball_at(target)
            if color is not None:
                beyond = (target[0] + dx, target[1] + dy)
                if self.blocked(beyond) or self.ball_at(beyond) is not None:
                    self.message = "这里推不动，再换一个方向"
                    sfx(SFX_BLOCKED, "sfx_move", 0.7)
                    renpy.restart_interaction()
                    return
                self.balls[color] = beyond
                if self.balls[color] == self.targets[color]:
                    # 推到位：闷响 + 明亮铃音，用不同通道让两声叠在一起
                    sfx(SFX_PUSH, "sfx_move", 0.8)
                    sfx(SFX_PLACE, "sfx_chime", 0.9)
                else:
                    sfx(SFX_PUSH, "sfx_move")
            else:
                sfx(SFX_STEP, "sfx_move", 0.55)
            self.player = target
            self.moves += 1
            if all(self.balls[c] == self.targets[c] for c in self.balls):
                self.cleared = True
                sfx(SFX_LEVEL_CLEAR, "sfx_chime")
                if self.last_level:
                    self.finished = True
                    self.message = "全部通关！%d 步完成" % self.moves
                else:
                    self.message = "第 %d 关完成（%d 步），点击「下一关」" % (self.level + 1, self.moves)
            else:
                self.message = "移动次数：%d" % self.moves
            renpy.restart_interaction()

        def next_level(self):
            if self.cleared and not self.last_level:
                self.level += 1
                self.load_level()

        def finish(self):
            store.ball_transport_result = self.finished

        def cell_color(self, x, y):
            for color, pos in self.targets.items():
                if pos == (x, y):
                    return self.COLORS[color]
            return None

        def cell_target(self, x, y):
            """返回该格的出口颜色名（red/blue/gold），不是出口则返回 None。"""
            for color, pos in self.targets.items():
                if pos == (x, y):
                    return color
            return None

        def placed_count(self):
            """已经推进出口的小球数量。"""
            return sum(1 for c in self.balls if self.balls[c] == self.targets[c])

    BALL_IMAGES = {
        "red": "images/ball_transport/ball_red.png",
        "blue": "images/ball_transport/ball_blue.png",
        "gold": "images/ball_transport/ball_gold.png",
    }

    TARGET_IMAGES = {
        "red": "images/ball_transport/target_red.png",
        "blue": "images/ball_transport/target_blue.png",
        "gold": "images/ball_transport/target_gold.png",
    }
    TARGET_TEXT_COLORS = {"red": "#C2334C", "blue": "#1F6E9E", "gold": "#9A6A0C"}

image btn_frame = Frame("images/ball_transport/btn_idle.png", 20, 20)
image btn_frame_hover = Frame("images/ball_transport/btn_hover.png", 20, 20)

screen ball_transport():
    modal True
    zorder 300

    # 薄荷绿背景（与原图同色 #C0F2E6），降低不透明度让剧情 CG 透出来。
    add "images/ball_transport/bg_mint.png" alpha 0.70

    $ st = ball_transport_state
    $ cell = 92
    $ origin_x = (config.screen_width - cell * st.WIDTH) // 2 + 2
    $ origin_y = 210
    $ placed = st.placed_count()

    # 文字加白色描边：背景半透明后 CG 会透上来，描边保证任何画面上都读得清。
    text ("moving balls　第 %d / %d 关" % (st.level + 1, len(st.LEVELS))) xalign 0.5 ypos 44 size 46 color "#26464E" outlines [(2, "#FFFFFFD0", 0, 0)]
    text "推动小球进入相同颜色的出口　方向键或下方按钮移动" xalign 0.5 ypos 108 size 25 color "#24474E" outlines [(2, "#FFFFFFC0", 0, 0)]
    text st.message xalign 0.5 ypos 146 size 26 color "#6E2A0C" outlines [(2, "#FFFFFFC0", 0, 0)]

    # 归位进度条
    $ total_balls = len(st.balls)
    add Solid("#FFFFFFB0") xpos origin_x ypos 182 xysize (cell * st.WIDTH - 4, 12)
    add Solid("#F08A5D") xpos origin_x ypos 182 xysize (int((cell * st.WIDTH - 4) * placed / float(total_balls)), 12)
    text ("归位 %d / %d" % (placed, total_balls)) xpos origin_x + cell * st.WIDTH + 16 ypos 176 size 22 color "#24474E" outlines [(2, "#FFFFFFC0", 0, 0)]

    key "K_UP" action Function(st.move, 0, -1)
    key "K_DOWN" action Function(st.move, 0, 1)
    key "K_LEFT" action Function(st.move, -1, 0)
    key "K_RIGHT" action Function(st.move, 1, 0)

    for y in range(st.HEIGHT):
        for x in range(st.WIDTH):
            $ pos = (x, y)
            if pos in st.walls:
                add "images/ball_transport/wall.png" xpos int(origin_x + x * cell) ypos int(origin_y + y * cell)
            else:
                add "images/ball_transport/tile.png" xpos int(origin_x + x * cell) ypos int(origin_y + y * cell)
                $ target_name = st.cell_target(x, y)
                if target_name:
                    $ target_img = TARGET_IMAGES[target_name]
                    add target_img xpos int(origin_x + x * cell) ypos int(origin_y + y * cell)
                    text "出口" xpos int(origin_x + x * cell + (cell - 4) // 2) xanchor 0.5 ypos int(origin_y + y * cell + 32) size 20 color TARGET_TEXT_COLORS[target_name]

    for color, pos in st.balls.items():
        $ ball_img = BALL_IMAGES[color]
        add ball_img:
            xpos int(origin_x + pos[0] * cell + (cell - 72) // 2)
            ypos int(origin_y + pos[1] * cell + (cell - 72) // 2)

    # 主角：希实香 Q 版立绘（透明背景贴图，按格子中心对齐）
    add "images/ball_transport/player_chibi.png":
        xpos int(origin_x + st.player[0] * cell + cell // 2)
        ypos int(origin_y + st.player[1] * cell + cell // 2)
        xanchor 0.5
        yanchor 0.5

    hbox:
        xalign 0.5
        ypos 800
        spacing 16
        textbutton "上":
            action Function(st.move, 0, -1)
            activate_sound None
            background "btn_frame"
            hover_background "btn_frame_hover"
            padding (22, 11)
            text_size 26
            text_color "#26464E"
            text_hover_color "#B4532A"
        textbutton "下":
            action Function(st.move, 0, 1)
            activate_sound None
            background "btn_frame"
            hover_background "btn_frame_hover"
            padding (22, 11)
            text_size 26
            text_color "#26464E"
            text_hover_color "#B4532A"
        textbutton "左":
            action Function(st.move, -1, 0)
            activate_sound None
            background "btn_frame"
            hover_background "btn_frame_hover"
            padding (22, 11)
            text_size 26
            text_color "#26464E"
            text_hover_color "#B4532A"
        textbutton "右":
            action Function(st.move, 1, 0)
            activate_sound None
            background "btn_frame"
            hover_background "btn_frame_hover"
            padding (22, 11)
            text_size 26
            text_color "#26464E"
            text_hover_color "#B4532A"
        textbutton "重来本关":
            action Function(st.restart_level)
            background "btn_frame"
            hover_background "btn_frame_hover"
            padding (22, 11)
            text_size 26
            text_color "#26464E"
            text_hover_color "#B4532A"
        if st.cleared and not st.last_level:
            textbutton "下一关":
                action Function(st.next_level)
                background "btn_frame"
                hover_background "btn_frame_hover"
                padding (22, 11)
                text_size 26
                text_color "#26464E"
                text_hover_color "#B4532A"
        textbutton "完成":
            action [Function(st.finish), Return()]
            background "btn_frame"
            hover_background "btn_frame_hover"
            padding (22, 11)
            text_size 26
            text_color "#26464E"
            text_hover_color "#B4532A"

label ball_transport_minigame:
    if ball_transport_state is None:
        $ ball_transport_state = BallTransportState()
    $ ball_transport_result = False
    $ ball_transport_state.reset()
    call screen ball_transport
    return
