# 音效系统
#
# 音效文件在 game/audio/sfx/ 下，由 tools/make_sfx.py 合成（可重跑调整音量/音高）。
# 这里统一登记路径、注册通道，并把点击音挂到所有按钮样式上。

init python:
    # 分开的通道：一次操作可能同时触发两个音（推球 + 归位），
    # 共用一个通道会互相打断，所以按用途拆开。
    renpy.music.register_channel("sfx_ui", mixer="sound", loop=False, tight=True)
    renpy.music.register_channel("sfx_move", mixer="sound", loop=False, tight=True)
    renpy.music.register_channel("sfx_chime", mixer="sound", loop=False, tight=True)

    SFX_UI_HOVER = "audio/sfx/ui_hover.wav"
    SFX_UI_CLICK = "audio/sfx/ui_click.wav"
    SFX_STEP = "audio/sfx/ball_step.wav"
    SFX_PUSH = "audio/sfx/ball_push.wav"
    SFX_BLOCKED = "audio/sfx/ball_blocked.wav"
    SFX_PLACE = "audio/sfx/ball_place.wav"
    SFX_LEVEL_CLEAR = "audio/sfx/level_clear.wav"
    SFX_STAR = "audio/sfx/star_link.wav"
    # 连星音阶：前段低、中段中、后段高，越接近完成音越高。
    SFX_STAR_MID = "audio/sfx/star_link_mid.wav"
    SFX_STAR_HI = "audio/sfx/star_link_hi.wav"
    SFX_STAR_HINT = "audio/sfx/star_hint.wav"
    SFX_STAR_DONE = "audio/sfx/star_done.wav"

    def sfx(name, channel="sfx_move", volume=1.0):
        """播放一个音效。channel 决定它会不会打断同类音。"""
        renpy.sound.play(name, channel=channel, relative_volume=volume)


# offset 1：确保 screens.rpy 里的样式已经定义完再挂音效。
init offset = 1

init python:
    # 注意：screens.rpy 里 choice_button / quick_button 的父样式是 default，
    # confirm_button 继承 gui_medium_button，它们都不从 button 继承，
    # 所以必须逐个点名，否则剧情里的选项按钮不会有音效。
    for _name in ("button", "gui_button", "gui_medium_button", "nvl_button",
                  "choice_button", "quick_button", "confirm_button",
                  "navigation_button", "return_button", "page_button", "slot_button",
                  "radio_button", "check_button", "slider_button", "help_button",
                  "mute_all_button"):
        _st = getattr(style, _name, None)
        if _st is not None:
            _st.activate_sound = SFX_UI_CLICK
            _st.hover_sound = SFX_UI_HOVER
    del _name, _st
