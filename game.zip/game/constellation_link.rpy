# 星座连线小游戏
#
# 玩法：
#   · 未轮到的星星是暗的、不显示名字，要靠线索和观察去找下一颗
#   · 每步给一句线索；每个星座 3 次提示，用了就直接点亮并报出星名
#   · 点错不重置进度，只累计失误（影响评价）
#   · 星图里混有干扰星，点中只提示"不在这个星座里"
#   · 计时只影响评价，超时不会失败
#
# 星位、线索、评分都在 game/constellation_core.py（纯逻辑，可脱离 Ren'Py 自测）。
# 结果只通过布尔量 constellation_link_result 影响剧情，
# 评级放在 constellation_link_rank / _score 里，剧情不用也不会出问题。

default constellation_link_result = False
default constellation_link_rank = None
default constellation_link_score = 0

init python:
    import constellation_core as ccore

    def constellation_link_sound(stage):
        """连星音效按进度换档：前段低、中段中、后段高。

        必须在调用时现取 SFX_* 常量，不能在这里的模块层先装成元组：
        Ren'Py 按文件名顺序执行 init 块，constellation_link.rpy 排在 sfx.rpy
        之前，模块层引用那些常量会直接 NameError。
        """
        return (SFX_STAR, SFX_STAR_MID, SFX_STAR_HI)[stage]

    class _ConstellationLinkState(object):
        def reset(self, constellation="summer"):
            self.constellation = constellation
            self.selected = []
            self.completed = False
            self.errors = 0
            self.hints = ccore.CONSTELLATION_HINTS
            #: 本步是否已经用提示点亮了下一颗星
            self.reveal_next = False
            self.elapsed = 0.0
            self.started_at = ccore_now()
            self.rank = None
            self.score = 0
            data = ccore.CONSTELLATIONS[constellation]
            self.title = data["title"]
            self.message = "来～按顺序点亮星星，把它们连成星座吧"

        def choose_constellation(self, constellation):
            if constellation == self.constellation and not self.selected:
                return
            self.reset(constellation)
            renpy.restart_interaction()

        def restart(self):
            self.reset(self.constellation)
            renpy.restart_interaction()

        @property
        def total(self):
            return len(ccore.stars_of(self.constellation))

        @property
        def hints_used(self):
            return ccore.CONSTELLATION_HINTS - self.hints

        def tick(self):
            """屏幕定时器驱动，刷新计时显示。"""
            if not self.completed:
                self.elapsed = ccore_now() - self.started_at
            renpy.restart_interaction()

        def clue(self):
            if self.completed:
                return "哇——整条星座都亮起来啦，好漂亮呢～"
            clues = ccore.clues_of(self.constellation)
            return clues[min(len(self.selected), len(clues) - 1)]

        def next_name(self):
            stars = ccore.stars_of(self.constellation)
            if self.completed or len(self.selected) >= self.total:
                return ""
            return stars[len(self.selected)][0]

        def use_hint(self):
            if self.completed or self.hints <= 0 or self.reveal_next:
                return
            self.hints -= 1
            self.reveal_next = True
            self.message = "提示哦：下一颗是「%s」，我在旁边看着你呢～" % self.next_name()
            sfx(SFX_STAR_HINT, "sfx_chime", 0.7)
            renpy.restart_interaction()

        def choose(self, index):
            if self.completed:
                return
            if index == len(self.selected):
                self.selected.append(index)
                self.reveal_next = False
                data = ccore.CONSTELLATIONS[self.constellation]
                if len(self.selected) == self.total:
                    self.completed = True
                    self.elapsed = ccore_now() - self.started_at
                    self.score, self.rank = ccore.grade(
                        self.elapsed, self.errors, self.hints_used)
                    store.constellation_link_rank = self.rank
                    store.constellation_link_score = int(round(self.score))
                    self.message = "「%s」完整显现啦！评价 %s 哦～" % (data["title"], self.rank)
                    sfx(SFX_STAR_DONE, "sfx_chime")
                else:
                    self.message = "接上啦～现在是 %d / %d 呢" % (len(self.selected), self.total)
                    stage = ccore.link_stage(len(self.selected), self.total)
                    sfx(constellation_link_sound(stage), "sfx_chime", 0.6)
            else:
                self.errors += 1
                if self.errors == 1:
                    self.message = "诶？这颗好像还不是时候呢，再看看上面的线索呀～"
                elif self.errors <= 3:
                    self.message = "唔……方向有点偏啦，想想刚才说的赤经方位？"
                else:
                    self.message = "别急嘛，星星又不会跑掉，慢慢找就好啦～"
                sfx(SFX_BLOCKED, "sfx_move", 0.45)
            renpy.restart_interaction()

        def choose_decoy(self):
            if self.completed:
                return
            self.errors += 1
            self.message = "这颗呀，不在这个星座里哦——是颗干扰星呢～"
            sfx(SFX_BLOCKED, "sfx_move", 0.40)
            renpy.restart_interaction()

        def done(self):
            store.constellation_link_result = self.completed

    def ccore_now():
        """真实时钟。只在函数内部导入，避免把模块对象放进 store。"""
        import time
        return time.monotonic()

    constellation_link_state = _ConstellationLinkState()
    constellation_link_state.reset()


screen constellation_link():
    modal True
    zorder 300

    # 半透明背景：保留当前剧情 CG，同时叠加星尘。
    add Solid("#04060F99")
    add "images/constellation/starfield.png"
    add "images/constellation/board.png" xpos 340 ypos 190

    $ st = constellation_link_state
    $ cdata = ccore.CONSTELLATIONS[st.constellation]
    $ crop = ccore.crop_of(st.constellation)

    # 完成后的柔光。静态叠加、不做动画：屏幕每 0.5 秒重建一次，
    # 动画会被反复重启，反而不如稳定的一层柔光干净。
    if st.completed:
        add "images/constellation/flash.png" alpha 0.85

    text _(st.title) xalign 0.5 ypos 54 size 52 color "#f4e9cd"
    text _(cdata["hint"]) xalign 0.5 ypos 116 size 24 color "#9fb3d1"

    # ---- 希实香的对话气泡：线索与反馈都放到底部，像她在旁边说话 ----
    add "images/constellation/bubble.png" xpos 340 ypos 886

    text "希实香":
        xpos 374
        ypos 890
        size 23
        color "#ffe69a"

    text _(st.clue()):
        xpos 374
        ypos 920
        size 25
        color "#f4e9cd"

    text _(st.message):
        xpos 374
        ypos 959
        size 21
        color "#bfe4ff"

    # ---- 状态栏：用时 / 失误 / 提示 / 评价 ----
    text ("用时 %.1fs" % st.elapsed) xpos 70 ypos 200 size 22 color "#8194ad"
    text ("失误 %d" % st.errors) xpos 70 ypos 230 size 22 color "#8194ad"
    text ("目标 %.0fs 内" % (ccore.CONSTELLATION_TARGET * 0.5)) xpos 70 ypos 260 size 20 color "#5b6b82"
    if st.completed and st.rank:
        text ("评价 %s　%d 分" % (st.rank, st.score)) xpos 70 ypos 292 size 26 color "#ffe69a"

    # 星座切换：当前选中的高亮。
    vbox:
        xpos 70
        ypos 60
        spacing 10
        for key in ccore.CONSTELLATION_ORDER:
            $ active = (key == st.constellation)
            textbutton ccore.CONSTELLATIONS[key]["title"]:
                text_size 24
                text_color ("#ffe69a" if active else "#8194ad")
                action Function(st.choose_constellation, key)

    # 星线先画，保证星星和名字压在上面。颜色随进度蓝→紫→金。
    $ line_image = None
    if len(st.selected) >= 2:
        $ line_image = "images/constellation/lines_%s_%d.png" % (
            st.constellation, len(st.selected))
    if line_image:
        add line_image:
            xpos crop[0]
            ypos crop[1]

    # ---- 干扰星：暗、小、无名字 ----
    for decoy in ccore.decoys_of(st.constellation):
        add "images/constellation/star_idle.png":
            xpos decoy[0] - 22
            ypos decoy[1] - 22
            zoom 0.7
            alpha 0.30
        button:
            xpos decoy[0] - 40
            ypos decoy[1] - 40
            xysize (80, 80)
            background Solid("#ffffff00")
            activate_sound None
            hover_sound None
            action Function(st.choose_decoy)

    for i, star in enumerate(ccore.stars_of(st.constellation)):
        $ lit = i in st.selected
        $ is_next = (not st.completed) and i == len(st.selected)
        if lit:
            add "images/constellation/star_lit.png" xpos star[1] - 48 ypos star[2] - 48
        elif is_next and st.reveal_next:
            # 用过提示：直接点亮目标星
            add "images/constellation/star_hint.png" xpos star[1] - 48 ypos star[2] - 48
        elif is_next:
            # 目标星：比周围的暗星亮一档，需要扫一眼才能找到，但不至于找不到
            add "images/constellation/star_idle.png":
                xpos star[1] - 32
                ypos star[2] - 32
                alpha 0.70
        else:
            # 还没轮到的星：只留一点微光，需要靠线索去找
            add "images/constellation/star_idle.png":
                xpos star[1] - 32
                ypos star[2] - 32
                alpha 0.36

        # 名字只显示已经点亮的，以及用提示点出来的那颗
        if lit or (is_next and st.reveal_next):
            text star[0]:
                xpos star[1]
                xanchor 0.5
                ypos star[2] + 34
                size 22
                color ("#ffe9b0" if lit else "#8FE7FF")

        # 星星本身已经由 st.choose 播放连星音效，关掉全局 UI 音避免双重声音。
        button:
            xpos star[1] - 64
            ypos star[2] - 64
            xysize (128, 128)
            background Solid("#ffffff00")
            activate_sound None
            hover_sound None
            action Function(st.choose, i)

    # ---- 底部操作栏 ----
    hbox:
        xalign 0.5
        ypos 1024
        spacing 22
        textbutton _("提示 %d" % st.hints):
            action Function(st.use_hint)
            text_color ("#ffe69a" if (st.hints > 0 and not st.completed) else "#5b6b82")
        textbutton _("重来") action Function(st.restart)
        textbutton _("完成") action [Function(st.done), Return()]

    # 计时刷新：0.5 秒一次，够用又不会频繁重建界面。
    timer 0.5 repeat True action Function(st.tick)


label constellation_link_minigame:
    $ constellation_link_result = False
    $ constellation_link_rank = None
    $ constellation_link_score = 0
    $ constellation_link_state.reset()
    call screen constellation_link
    return
