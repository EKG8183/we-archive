﻿# TODO: Translation updated at 2026-11-13 12:54

# game/转换后的Ren'Py脚本文件.rpy:370
translate english start_ae70a0e2:

    # "一颗星悬在科学馆的飞檐"
    "A star hangs from the eaves of the Science Museum."

# game/转换后的Ren'Py脚本文件.rpy:371
translate english start_6c8239c4:

    # "耳坠子一般的悬着"
    "Hanging like earrings"

# game/转换后的Ren'Py脚本文件.rpy:372
translate english start_30201493:

    # "瑞士表显示已经七点了。忽然你走来"
    "The Swiss watch shows that it's already seven o'clock. Suddenly, you come."

# game/转换后的Ren'Py脚本文件.rpy:373
translate english start_c06c6e1a:

    # "夜里的科技馆，似乎是我第一次来呢。不过像我这样的neet，对科学倒也提不起什么兴趣，科技馆这样的地方自然也来得很少。"
    "This seems to be my first time at the Science Museum at night. However, a NEET like me doesn't have much interest in science, so naturally, I rarely visit places like science museums."

# game/转换后的Ren'Py脚本文件.rpy:374
translate english start_47362e88:

    # "不过似乎每个人小时候都会说自己想要当科学家，我也并不例外。只是随着一天天长大，最后发现还是看h漫更适合我。"
    "However, it seems that everyone says they want to be a scientist when they are young, and I am no exception. It's just that as I grew up day by day, I eventually found that watching H-themed comics suits me better."

# game/转换后的Ren'Py脚本文件.rpy:375
translate english start_866da523:

    # "如果不是因为那个疯女人，这辈子或许再也没有机会来这种地方……把约会的地点定在科学馆……真是让人捉摸不透呢，希实香。或许她完全没有想到我什么都看不懂吧"
    "If it weren't for that crazy woman, perhaps I would never have the chance to come to a place like this again in my life... Set the place for the date at the Science Museum... It's really hard to figure out, Kimika. Perhaps she didn't expect at all that I couldn't understand anything"

# game/转换后的Ren'Py脚本文件.rpy:379
translate english start_d29a6be0:

    # "肚子……好痛……就像被人捅了一刀……"
    "Stomach... It hurts so much... It's just like being stabbed..."

# game/转换后的Ren'Py脚本文件.rpy:380
translate english start_fdacbcf0:

    # "来科学馆之前，感觉自己做了一个荒诞的梦。在阴暗的地下室，空气中充满了发电机的汽油味。西村也好，城山也好，所有dqn在我的面前喊着一些莫名其妙的话语，然后死去"
    "Before coming to the Science Museum, I felt like I had had a ridiculous dream. In the gloomy basement, the air was filled with the smell of gasoline from the generator. Whether it was Nishimura or Shiroyama, all the DQNS shouted some inexplicable words in front of me and then died"

# game/转换后的Ren'Py脚本文件.rpy:381
translate english start_cc3b9530:

    # "这些畜牲如果真的死掉了该多好啊……"
    "How wonderful it would be if these animals really died..."

# game/转换后的Ren'Py脚本文件.rpy:382
translate english start_7e23cc26:

    # "当然那些不堪的往事已无暇顾及，用不了多久，我就能和重要的人一起离开这该死的学校。城山的拳头又能怎样呢，dqn难道还敢杀了我吗。现在要做的，只有等待"
    "Of course, I have no time to care about those unpleasant past events. It won't be long before I can leave this damn school with the important people. What can Shiroyama's fist do? Does dqn still dare to kill me? All that needs to be done now is wait"

# game/转换后的Ren'Py脚本文件.rpy:383
translate english start_147cc560:

    # "也许我是个很敏感的人吧，比起肉体的伤害，更害怕的是被人无视的孤独。幸好如今终于有了关心我的人，终于有了深深爱着我的最重要的人。希实香……只要离开了这里，就能让我们手牵着手，幸福地活下去……"
    "Perhaps I am a very sensitive person. I am more afraid of the loneliness of being ignored than of physical harm. Fortunately, I finally have someone who cares about me, and I finally have the most important person who loves me deeply. Kimika... As long as we leave this place, we can hold hands and live happily ever after..."

# game/转换后的Ren'Py脚本文件.rpy:385
translate english start_c9b82876:

    # x "「笨蛋卓司……这个时候还闭着眼睛」"
    x "Idiot Takuji... still with his eyes closed at this moment."

# game/转换后的Ren'Py脚本文件.rpy:386
translate english start_0aefb396:

    # x "「是不是因为不想看见我？」"
    x "Is it because you don't want to see me?"

# game/转换后的Ren'Py脚本文件.rpy:387
translate english start_b9f09b9f:

    # z "「啊……呃……」"
    z "Ah... Uh..."

# game/转换后的Ren'Py脚本文件.rpy:389
translate english start_c33ce6c4:

    # x "「开玩笑的……打起点精神来啊」"
    x "Just kidding... Cheer up!"

# game/转换后的Ren'Py脚本文件.rpy:390
translate english start_f06ba23e:

    # x "「有哪里不舒服吗？」"
    x "Are you feeling unwell anywhere?"

# game/转换后的Ren'Py脚本文件.rpy:391
translate english start_733cb79a:

    # z "「没有……只是在想一些事」"
    z "No... Just thinking about something."

# game/转换后的Ren'Py脚本文件.rpy:392
translate english start_908b3094:

    # x "「那就好」"
    x "Great."

# game/转换后的Ren'Py脚本文件.rpy:393
translate english start_f67d691e:

    # x "「像卓司这样的neet应该是第一次来这里吧……总之要打起精神来哦」"
    x "neet like Takuji should be coming here for the first time... In short, cheer up"

# game/转换后的Ren'Py脚本文件.rpy:394
translate english start_7f1226bb:

    # "我不想扫她的兴，紧紧跟了上来"
    "I didn't want to spoil her fun, so I followed closely."

# game/转换后的Ren'Py脚本文件.rpy:395
translate english start_b08b1d12:

    # x "「唔……现在已经7点多了，往这走应该可以赶上机器人表演」"
    x "Hmm... It's already past 7:00. If we go this way, we should be able to catch the robot show."

# game/转换后的Ren'Py脚本文件.rpy:398
translate english start_63b7a46b:

    # "一台银色的机器人映入眼帘，电线与软管把它固定在钢琴前，手指在琴键上跃动，奏出一个个音符"
    "A silver robot catches the eye, wires and hoses holding it in place at the piano, its fingers dancing across the keys, playing one note after another."

# game/转换后的Ren'Py脚本文件.rpy:400
translate english start_854dec95:

    # x "「这可是人类电气和自动化的结晶」"
    x "This is the crystallization of human electricity and automation"

# game/转换后的Ren'Py脚本文件.rpy:401
translate english start_2d24cefa:

    # z "「它只有手指能动吗」"
    z "Can only its fingers move?"

# game/转换后的Ren'Py脚本文件.rpy:402
translate english start_212e7994:

    # x "「从结构上看脚应该也是可以活动的」"
    x "Structurally speaking, the feet should also be movable."

# game/转换后的Ren'Py脚本文件.rpy:403
translate english start_26167d31:

    # "说话的时间里，它的脚已经从踏板上离开"
    "While I was talking, his foot had already come off the pedal."

# game/转换后的Ren'Py脚本文件.rpy:404
translate english start_214c4bd2:

    # z "「好厉害」"
    z "So amazing!"

# game/转换后的Ren'Py脚本文件.rpy:405
translate english start_098db1cf:

    # x "「……」"
    x "..."

# game/转换后的Ren'Py脚本文件.rpy:406
translate english start_c6d19429:

    # z "「既然脚可以活动，是不是有一天它也可以离开这台钢琴」"
    z "Since the feet can move, could there be a day when they can also leave this piano?"

# game/转换后的Ren'Py脚本文件.rpy:407
translate english start_dc8d70a3:

    # x "「恐怕是不行的……机器人只能按设定好的程序活动……就像……八音盒一样」"
    x "I'm afraid it won't work... Robots can only move according to the pre-set program... Just like... a music box."

# game/转换后的Ren'Py脚本文件.rpy:408
translate english start_e4662176:

    # "机器人的手指接连落在琴键上，如八音盒的滚筒"
    "The robot's fingers fall successively on the keys, like the cylinder of a music box."

# game/转换后的Ren'Py脚本文件.rpy:409
translate english start_d18f7c6a:

    # z "「就像……我一样的吗？」"
    z "Just like... Am I the same?"

# game/转换后的Ren'Py脚本文件.rpy:410
translate english start_3d124b68:

    # x "「间宫君确实是钢琴大师哦。听说放学之后还会去给酒吧弹钢琴」"
    x "Mamiya-kun is indeed a piano maestro. I heard that he goes to a bar to play the piano after school."

# game/转换后的Ren'Py脚本文件.rpy:411
translate english start_3fcfe545:

    # z "「不是这样的！」"
    z "It's not true."

# game/转换后的Ren'Py脚本文件.rpy:413
translate english start_95d2bfbc:

    # x "「噢……抱歉」"
    x "Oh... I'm sorry."

# game/转换后的Ren'Py脚本文件.rpy:414
translate english start_7d6bf9e9:

    # z "「我学钢琴完全是母亲的意愿，从来不觉得弹钢琴开心」"
    z "I learned to play the piano entirely at my mother's insistence, and I never enjoyed playing it."

# game/转换后的Ren'Py脚本文件.rpy:415
translate english start_062a0f76:

    # z "「小时候弹钢琴，被迫盯着一行行的乐谱，手指麻木地敲击琴键，就像执行输入好的程序一样，练习好几个小时无聊的古典音乐」"
    z "When I was a child, I played the piano. I was forced to stare at lines of sheet music and numbly tap the keys with my fingers, like executing a pre-programmed routine, practicing hours of boring classical music."

# game/转换后的Ren'Py脚本文件.rpy:416
translate english start_27d893a5:

    # z "「所以我只觉得机器人可怜」"
    z "So I just think robots are pitiful."

# game/转换后的Ren'Py脚本文件.rpy:417
translate english start_ef50c07a:

    # x "「居然是这样嘛……」"
    x "Is that so..."

# game/转换后的Ren'Py脚本文件.rpy:418
translate english start_71954741:

    # z "「会和一台机器共情，真的很奇怪吧……不过话说人类有的时候也是很奇怪的生物呢，居然把名贵的三角钢琴和先进的机器结构组合在一起做成一台八音盒」"
    z "It's really strange to empathize with a machine... But sometimes humans are also strange creatures. They actually combined an expensive grand piano with an advanced machine structure to make a music box."

# game/转换后的Ren'Py脚本文件.rpy:419
translate english start_78882a46:

    # x "「只是一个比喻而已……这个装置主要目的还是展示机器人的运行吧……」"
    x "It's just a metaphor... The main purpose of this device is still to demonstrate the operation of robots, right..."

# game/转换后的Ren'Py脚本文件.rpy:420
translate english start_8ed88599:

    # z "「嗯嗯，继续向前走吧」"
    z "Mm-hmm, let's keep going forward."

# game/转换后的Ren'Py脚本文件.rpy:421
translate english start_57c3eba4:

    # x "「……等一下」"
    x "... Wait a moment."

# game/转换后的Ren'Py脚本文件.rpy:422
translate english start_cf20ac08:

    # x "「在这台机器人下班之前，卓司同学要不要亲自弹一次？」"
    x "Before this robot finishes its shift, would Takuji-kun like to play it himself?"

# game/转换后的Ren'Py脚本文件.rpy:423
translate english start_bda8b08c:

    # z "「我？」"
    z "I"

# game/转换后的Ren'Py脚本文件.rpy:424
translate english start_038d00e5:

    # x "「这首曲子叫《遙かなる夢に～》，正好也存在这台钢琴的程序里」"
    x "This piece is called 'Harukanaru Yume ni ~', and it just so happens to be in this piano's program."

# game/转换后的Ren'Py脚本文件.rpy:425
translate english start_53686637:

    # x "「音符会从上面落下来，落到白线的时候按下对应的琴键就好了」"
    x "Notes will fall from above. When they reach the white line, just press the corresponding key."

# game/转换后的Ren'Py脚本文件.rpy:426
translate english start_4a23179b:

    # z "「……可是我弹琴，从来都没有觉得开心过」"
    z "... But I've never felt happy when playing the piano."

# game/转换后的Ren'Py脚本文件.rpy:427
translate english start_22390c66:

    # x "「这次不是弹给母亲听，也不是弹给评委听哦」"
    x "This time, I'm not playing for my mother, nor for the judges."

# game/转换后的Ren'Py脚本文件.rpy:428
translate english start_cdd8508d:

    # x "「就当是弹给这台只能待在钢琴前的机器人听吧」"
    x "Just pretend you're playing for this robot that can only sit in front of the piano."

# game/转换后的Ren'Py脚本文件.rpy:430
translate english start_e9a68c6b:

    # z "「……好吧」"
    z "OK."

# game/转换后的Ren'Py脚本文件.rpy:436
translate english start_f6146814:

    # z "「……算了，手指还是不听使唤」"
    z "...Forget it, my fingers still won't obey."

# game/转换后的Ren'Py脚本文件.rpy:437
translate english start_bd556958:

    # x "「没关系的。机器人的程序也是调试了很多次，才学会第一个音符的」"
    x "It's okay. The robot's program also had to be debugged many times before it learned its first note."

# game/转换后的Ren'Py脚本文件.rpy:439
translate english start_d4e35740:

    # x "「哇……」"
    x "Wah!"

# game/转换后的Ren'Py脚本文件.rpy:440
translate english start_8b2da7e1:

    # x "「刚才那段，和机器人弹出来的完全不一样呢」"
    x "That last part was completely different from what the robot played."

# game/转换后的Ren'Py脚本文件.rpy:441
translate english start_162be537:

    # z "「……有吗」"
    z "Thought of something?"

# game/转换后的Ren'Py脚本文件.rpy:442
translate english start_585fd9d5:

    # x "「机器人的手指只是按顺序落在琴键上」"
    x "The robot's fingers simply fall on the keys in sequence."

# game/转换后的Ren'Py脚本文件.rpy:443
translate english start_3cfa2da7:

    # x "「可是卓司同学刚才弹的时候，听起来像是在说自己的话」"
    x "But when Takuji-kun was playing just now, it sounded like he was speaking for himself."

# game/转换后的Ren'Py脚本文件.rpy:444
translate english start_df75f7ab:

    # z "「因为我一直在想别的事情」"
    z "Because I've been thinking about something else."

# game/转换后的Ren'Py脚本文件.rpy:445
translate english start_6f0bc0c2:

    # z "「想到这些音符不是别人规定好的，手就没有那么僵了」"
    z "Thinking that these notes were not prescribed by others, my hand didn't feel so stiff."

# game/转换后的Ren'Py脚本文件.rpy:446
translate english start_7ec27e06:

    # x "「这就叫作自由吧，救世主大人」"
    x "Let's call this freedom, Lord Savior."

# game/转换后的Ren'Py脚本文件.rpy:448
translate english start_1da6f9d7:

    # x "「嗯……虽然有几个音掉在了白线外面」"
    x "Well... Although a few sounds fell outside the white line."

# game/转换后的Ren'Py脚本文件.rpy:449
translate english start_bfe45b0e:

    # x "「不过比机器人第一次调试的时候好多了哦」"
    x "But it's much better than when the robot was debugged for the first time."

# game/转换后的Ren'Py脚本文件.rpy:450
translate english start_605f7a85:

    # z "「这种安慰一点说服力都没有」"
    z "This kind of consolation is not persuasive at all."

# game/转换后的Ren'Py脚本文件.rpy:451
translate english start_6926732a:

    # x "「是真的啦，机器人的程序里可没有「跑调」这种东西」"
    x "It's true. There's no such thing as \"off-key\" in a robot's program."

# game/转换后的Ren'Py脚本文件.rpy:452
translate english start_11b4f8e6:

    # z "「……」"
    z "..."

# game/转换后的Ren'Py脚本文件.rpy:453
translate english start_367a1e84:

    # z "「不过刚才弹的时候，我好像没那么讨厌钢琴了」"
    z "But when I was playing just now, I didn't seem to hate the piano that much."

# game/转换后的Ren'Py脚本文件.rpy:458
translate english start_d4e38ad7:

    # "经过了一段彩色的走廊"
    "After passing through a colorful corridor"

# game/转换后的Ren'Py脚本文件.rpy:460
translate english start_edd52dc4:

    # z "「这里看上去好像是儿童区的样子」"
    z "This looks like a children's area."

# game/转换后的Ren'Py脚本文件.rpy:462
translate english start_93313759:

    # x "「是这样，不过我们的卓司宝宝已经是大孩子了呢，进去玩恐怕会直接卡住」"
    x "That's right, but our baby Takuji is already a big boy. I'm afraid he'll get stuck if he goes in to play."

# game/转换后的Ren'Py脚本文件.rpy:463
translate english start_11b4f8e6_1:

    # z "「……」"
    z "..."

# game/转换后的Ren'Py脚本文件.rpy:464
translate english start_8b4f12e1:

    # x "「生气了？」"
    x "Are you angry?"

# game/转换后的Ren'Py脚本文件.rpy:465
translate english start_a7d8f581:

    # z "「只是比较喜欢看小孩而已」"
    z "I just prefer to watch children."

# game/转换后的Ren'Py脚本文件.rpy:466
translate english start_7c63a422:

    # x "「哇，想不到间宫君居然是萝莉控呢~」"
    x "Wow, I didn't expect Mamiya-kun to be a lolicon~"

# game/转换后的Ren'Py脚本文件.rpy:467
translate english start_11b4f8e6_2:

    # z "「……」"
    z "..."

# game/转换后的Ren'Py脚本文件.rpy:468
translate english start_36fb23a3:

    # z "「啊是的是的，毕竟希实香看上去就是小小的一只呢，小时候的希实香肯定比现在还要可爱吧」"
    z "Oh, yes, yes. After all, Kimika looks like a little one. Kimika must have been even cuter when she was a child."

# game/转换后的Ren'Py脚本文件.rpy:470
translate english start_1c8d3337:

    # x "「萝莉控吗……真是恶心啊……」"
    x "A lolicon...? How disgusting..."

# game/转换后的Ren'Py脚本文件.rpy:471
translate english start_f27730c1:

    # "她好像……生气了？我识趣地闭上嘴，轻轻跟在她的身后"
    "She seems...angry? I wisely kept quiet and quietly followed behind her."

# game/转换后的Ren'Py脚本文件.rpy:473
translate english start_51052b2e:

    # "儿童区左边，一个不起眼的角落里几束向日葵的模型在悄悄转动"
    "To the left of the children's area, in an inconspicuous corner, several models of sunflowers are quietly turning."

# game/转换后的Ren'Py脚本文件.rpy:475
translate english start_6fd24699:

    # x "「几个模型就这么好看嘛……」"
    x "A few models look this good..."

# game/转换后的Ren'Py脚本文件.rpy:476
translate english start_dc05bd61:

    # x "「向日葵会朝着太阳转动，这可是小孩子都知道的事噢」"
    x "Sunflowers turn towards the sun. Even children know that."

# game/转换后的Ren'Py脚本文件.rpy:477
translate english start_973f1582:

    # z "「但是这么大的向日葵……是不会朝着太阳转动的吧」"
    z "But such a big sunflower... it won't turn towards the sun, will it?"

# game/转换后的Ren'Py脚本文件.rpy:479
translate english start_9dbb8276:

    # x "「啊？……」"
    x "(HAPPY) <Ah!>&#10;Momo: (HAPPY) <Ah!>&#10;Bella: (HAPPY) <Ah!>"

# game/转换后的Ren'Py脚本文件.rpy:480
translate english start_6a3fb48f:

    # x "「这么说起来……好像只见过花盆里的向日葵……毕竟……我也只是个水泥丛林里的城市小孩而已……」"
    x "Now that you mention it... it seems like I've only seen sunflowers in pots... After all... I'm just a city kid from the concrete jungle..."

# game/转换后的Ren'Py脚本文件.rpy:481
translate english start_bcb31090:

    # z "「向日葵真的是一种很奇怪的花呢……至少在我的记忆里，只有在还是花苞的时候，才会向着太阳」"
    z "Sunflowers are really strange flowers... At least in my memory, they only face the sun when they're still buds."

# game/转换后的Ren'Py脚本文件.rpy:482
translate english start_72ec99e0:

    # z "「等花茎变得像木头一样之后，向日葵就再也不会动了……」"
    z "Once the stem becomes as hard as wood, the sunflower will never move again..."

# game/转换后的Ren'Py脚本文件.rpy:483
translate english start_34e88bfe:

    # x "「噢噢，原来间宫君还有观察向日葵爱好……」"
    x "Oh, so Mamiya-kun also has a fondness for observing sunflowers..."

# game/转换后的Ren'Py脚本文件.rpy:484
translate english start_2c50cc51:

    # z "「倒也不是刻意去观察的……」"
    z "It's not that I deliberately observed..."

# game/转换后的Ren'Py脚本文件.rpy:485
translate english start_efdcf274:

    # z "「小时候在一个叫泽衣村的地方住过一段时间……房子后的山坡上种满了向日葵」"
    z "When I was a child, I lived in a place called Sawae Village for a while... the hillside behind the house was filled with sunflower."

# game/转换后的Ren'Py脚本文件.rpy:487
translate english start_1856ca3b:

    # z "「天还没亮的时候，就喜欢在山坡上散步，一边看着稀疏的星星，一边等着日出」"
    z "Before dawn, I like to take a walk on the hillside, gazing at the sparse stars while waiting for the sunrise."

# game/转换后的Ren'Py脚本文件.rpy:488
translate english start_8af2a143:

    # x "「听起来……很浪漫的样子」"
    x "It sounds... very romantic."

# game/转换后的Ren'Py脚本文件.rpy:489
translate english start_40bdaf27:

    # x "「在这种时候……城市里的路灯都还没有熄灭吧……想要看见星星和向日葵更是不可能的吧」"
    x "At such a time... the street lamps in the city haven't gone out yet... it's impossible to see the stars and sunflower, isn't it?"

# game/转换后的Ren'Py脚本文件.rpy:490
translate english start_607f908b:

    # z "「不过想起来，我也有很久没有回到故乡了……」"
    z "But when I think about it, I haven't been back to my hometown for a long time..."

# game/转换后的Ren'Py脚本文件.rpy:491
translate english start_5dde5256:

    # z "「或者是某种奇怪的爱好吧，在泽衣村的那段时间里，那条坡道……明明已经去过很多次，却还是忍不住一次又一次地故地重游」"
    z "Or maybe it's some kind of strange hobby. During my time in Sawae Village, that slope... Even though I've been there many times, I still can't help but revisit the place again and again."

# game/转换后的Ren'Py脚本文件.rpy:492
translate english start_cbac04a2:

    # z "「这个时候就会想啊，一个人欣赏这些会不会有点太孤单了……」"
    z "At this moment, I wonder if it's a bit too lonely to appreciate these things alone..."

# game/转换后的Ren'Py脚本文件.rpy:493
translate english start_098db1cf_1:

    # x "「……」"
    x "..."

# game/转换后的Ren'Py脚本文件.rpy:495
translate english start_7d100894:

    # z "「如果有天能和你一起过去……就好了……」"
    z "If only I could go there with you one day..."

# game/转换后的Ren'Py脚本文件.rpy:496
translate english start_c22b975d:

    # x "「就像现在这样吗」"
    x "Like this?"

# game/转换后的Ren'Py脚本文件.rpy:497
translate english start_6a47fea6:

    # z "「就像现在这样」"
    z "Just like now."

# game/转换后的Ren'Py脚本文件.rpy:498
translate english start_01648480:

    # x "「如果真的有这一天的话……间宫君肯定会很幸福吧」"
    x "If that day really comes... Mamiya-kun will surely be very happy."

# game/转换后的Ren'Py脚本文件.rpy:499
translate english start_74a1d1b5:

    # z "「可是幸福的生活，到底应该是什么样的呢」"
    z "But what exactly should a happy life look like?"

# game/转换后的Ren'Py脚本文件.rpy:500
translate english start_3f8bb8f5:

    # x "「幸福嘛……可能很难说清楚……」"
    x "Happiness... it might be hard to define..."

# game/转换后的Ren'Py脚本文件.rpy:502
translate english start_e9691c11:

    # x "「听起来可能有些荒诞吧……在我还读幼稚园的时候，身边就只剩妈妈一个人」"
    x "It may sound a bit absurd... When I was in kindergarten, my mom was the only one left by my side."

# game/转换后的Ren'Py脚本文件.rpy:503
translate english start_d7b09624:

    # x "「所以日子就经常过得紧巴巴，小时候也从来没有过零花钱」"
    x "So, life was always tight, and I never had any pocket money as a child."

# game/转换后的Ren'Py脚本文件.rpy:504
translate english start_f94a0353:

    # x "「幼稚园里有小朋友去了马尔代夫，回来就告诉大家，马尔代夫是『蓝天白云椰林树影，水清沙白，坐落于印度洋的世外桃源』」"
    x "Some children in kindergarten went to the Maldives, and when they came back, they told everyone that the Maldives is 'a paradise in the Indian Ocean with blue skies, white clouds, coconut groves, clear water, and white sand.'"

# game/转换后的Ren'Py脚本文件.rpy:505
translate english start_d63802b6:

    # x "「所以小时候最大的梦想，就是去马尔代夫旅行」"
    x "So, my biggest dream as a child was to travel to the Maldives."

# game/转换后的Ren'Py脚本文件.rpy:506
translate english start_045964d4:

    # x "「有一次，我生了很重很重的病，妈妈以为我活不下来了，于是鼓励我说等病好了就带我去马尔代夫」"
    x "Once, I was very, very sick. My mom thought I wasn't going to make it, so she encouraged me by saying that she would take me to the Maldives when I got better."

# game/转换后的Ren'Py脚本文件.rpy:507
translate english start_1c86f6bf:

    # x "「当然后来，病情也慢慢好转起来……不过呢，妈妈当然是没有钱带希实香小朋友去马尔代夫的……」"
    x "Of course, later on, the condition gradually improved... But, Mom certainly didn't have the money to take Kimika to the Maldives..."

# game/转换后的Ren'Py脚本文件.rpy:508
translate english start_1070d543:

    # x "「于是她就带我去了冲绳岛，告诉我这里就是马尔代夫」"
    x "So she took me to Okinawa Island and told me that this was the Maldives."

# game/转换后的Ren'Py脚本文件.rpy:509
translate english start_bc72978c:

    # x "「希实香小朋友在山顶坐了缆车，看了海湾，见识了山顶的鸟语花香」"
    x "Little Kimika took the cable car on the top of the mountain, looked at the bay and witnessed the singing of birds and the fragrance of flowers at the summit."

# game/转换后的Ren'Py脚本文件.rpy:510
translate english start_c1f1d9a6:

    # x "「这就是我生命里最幸福的一天……」"
    x "This is the happiest day of my life..."

# game/转换后的Ren'Py脚本文件.rpy:511
translate english start_73ab5c8e:

    # z "「后来呢？你是怎么知道那里不是马尔代夫的？」"
    z "And then? How did you know that place wasn't the Maldives?"

# game/转换后的Ren'Py脚本文件.rpy:512
translate english start_e8a41181:

    # x "「不告诉你！」"
    x "I won't tell you!"

# game/转换后的Ren'Py脚本文件.rpy:513
translate english start_6884669a:

    # z "「知道真相之后，希实香小朋友哭了吗」"
    z "Did little Kimika cry after learning the truth?"

# game/转换后的Ren'Py脚本文件.rpy:515
translate english start_4df085f9:

    # x "「不重要……至少在山顶上的那一天，是我最幸福的日子」"
    x "It doesn't matter... At least that day on the mountaintop was the happiest day of my life."

# game/转换后的Ren'Py脚本文件.rpy:516
translate english start_f0f26d64:

    # x "「听上去很荒谬……对吧……毕竟我也是个奇怪的人呢」"
    x "It sounds absurd... right... After all, I'm a strange person too."

# game/转换后的Ren'Py脚本文件.rpy:517
translate english start_11b4f8e6_3:

    # z "「……」"
    z "..."

# game/转换后的Ren'Py脚本文件.rpy:519
translate english start_ecc613b1:

    # "科技馆的晚上，真是安静得出奇，安静到只能听见彼此的心跳"
    "The night at the Science Museum was surprisingly quiet, so quiet that we could only hear each other's heartbeats."

# game/转换后的Ren'Py脚本文件.rpy:520
translate english start_b671e969:

    # "说话间，偌大的科学馆似乎没有碰见别人，透过日光灯照射下的窗户，隐约能看到月明星稀的天空"
    "As we spoke, the vast Science Museum seemed empty of other people. Through the windows illuminated by fluorescent lights, we could faintly see the sky with a bright moon and few stars."

# game/转换后的Ren'Py脚本文件.rpy:521
translate english start_db6e5e35:

    # "空气里弥漫着奇怪的气氛，好像整间科技馆就是一个为我们两人打造的空间"
    "There was a strange atmosphere in the air, as if the entire science museum was a space created just for the two of us."

# game/转换后的Ren'Py脚本文件.rpy:523
translate english start_a770c7d9:

    # z "「探索之光？」"
    z "Light of Exploration?"

# game/转换后的Ren'Py脚本文件.rpy:524
translate english start_2e8eafcb:

    # "我在一组显示屏前停下了脚步。眼前这面屏幕里的内容，虽然看不太懂，但或许是在介绍人类的进化"
    "I stopped in front of a set of display screens. Although I can't quite understand the content on this screen in front of me, it might be an introduction to human evolution."

# game/转换后的Ren'Py脚本文件.rpy:526
translate english start_7ad18b83:

    # x "「卓司同学可真是个好奇宝宝呢」"
    x "Takuji is really a curious kid."

# game/转换后的Ren'Py脚本文件.rpy:527
translate english start_aa5bbd1b:

    # "人类从使用自然火到主动钻木取火，经历了漫长实践；而各地神话中天神盗火的故事，正是对这一过程的诗意升华。"
    "Humanity underwent a long process of experimentation, from using natural fire to actively making fire by drilling wood. The stories of gods stealing fire in various myths are a poetic sublimation of this process."

# game/转换后的Ren'Py脚本文件.rpy:528
translate english start_1cbaaf40:

    # z "「天神盗火……」"
    z "The god steals fire..."

# game/转换后的Ren'Py脚本文件.rpy:529
translate english start_89846422:

    # z "「似乎是母亲经常提到的故事呢……阿撒兹勒……盗火的天使……」"
    z "It seems to be a story that my mother often mentioned... Azazel... The angel who stole fire..."

# game/转换后的Ren'Py脚本文件.rpy:530
translate english start_c949ad6c:

    # x "「阿撒兹勒？这不是伪经里的天使嘛……间宫君为什么会知道这些」"
    x "Azazel? Isn't that the angel from the apocryphal scriptures...? How does Mamiya-kun know about this?"

# game/转换后的Ren'Py脚本文件.rpy:531
translate english start_29df9645:

    # z "「啊……呃……是因为母亲大人经常提到过这些……」"
    z "Ah... Uh... It's because Mother often mentioned these things..."

# game/转换后的Ren'Py脚本文件.rpy:532
translate english start_25048971:

    # z "「不过说实话，母亲大人也是不太靠谱的样子……总是愿意相信奇奇怪怪的教派」"
    z "But to be honest, Mother doesn't seem very reliable either... She's always willing to believe in strange sects."

# game/转换后的Ren'Py脚本文件.rpy:533
translate english start_6bf376ed:

    # x "「听起来确实不太靠谱的样子……不过应该没有做过伤害卓司的事情来吧」"
    x "It doesn't sound very reliable... But he probably hasn't done anything to harm Takuji."

# game/转换后的Ren'Py脚本文件.rpy:534
translate english start_71a58df4:

    # z "「当然有！」"
    z "Of course not"

# game/转换后的Ren'Py脚本文件.rpy:535
translate english start_3149327f:

    # z "「比方说……你有听过『米油』吗」"
    z "For example... have you ever heard of 'rice oil'?"

# game/转换后的Ren'Py脚本文件.rpy:537
translate english start_83dc85f3:

    # x "「『米油』……是什么？」"
    x "What is 'rice oil'?"

# game/转换后的Ren'Py脚本文件.rpy:538
translate english start_9cdb387b:

    # z "「呃……就是白粥表面那层汤汁」"
    z "Uh... it's the layer of broth on top of the congee."

# game/转换后的Ren'Py脚本文件.rpy:539
translate english start_656b3e8e:

    # z "「母亲一直相信那些东西很有营养，就用它代替牛奶给我喝……」"
    z "My mother always believed that those things were nutritious, so she used them instead of milk to feed me..."

# game/转换后的Ren'Py脚本文件.rpy:540
translate english start_d6cdfea9:

    # x "「这种东西……不就是糊化的淀粉嘛……能有什么营养呢……怪不得间宫君看上去比我还要瘦呢」"
    x "This stuff... it's just gelatinized starch... what kind of nutrition can it have?... No wonder Mamiya-kun looks even thinner than me."

# game/转换后的Ren'Py脚本文件.rpy:541
translate english start_8380ea5e:

    # x "「这么说来，确实不太靠谱的样子」"
    x "So, it does seem rather unreliable."

# game/转换后的Ren'Py脚本文件.rpy:542
translate english start_d29bde6d:

    # z "「简直是……深受其害了」"
    z "It's simply... I've suffered a lot from it."

# game/转换后的Ren'Py脚本文件.rpy:543
translate english start_9dfa0658:

    # z "「好了，不要再说这些了……」"
    z "All right, stop talking about this..."

# game/转换后的Ren'Py脚本文件.rpy:544
translate english start_8a39dcbb:

    # x "「好的救世主大人」"
    x "Alright, Savior!"

# game/转换后的Ren'Py脚本文件.rpy:548
translate english start_0812ec1f:

    # z "「什么？」"
    z "What?"

# game/转换后的Ren'Py脚本文件.rpy:549
translate english start_d66109ab:

    # x "「呃呃……没什么」"
    x "Uh uh... Nothing."

# game/转换后的Ren'Py脚本文件.rpy:550
translate english start_1175db21:

    # x "「比起这些，我其实更好奇人类为什么喜欢把自己的发现，强加到天神的身上」"
    x "More than that, I'm actually more curious as to why humans like to attribute their own discoveries to deities."

# game/转换后的Ren'Py脚本文件.rpy:551
translate english start_3dcfa23f:

    # z "「或许是因为盗火的故事更加动听？」"
    z "Perhaps it's because the story of stealing fire is more captivating?"

# game/转换后的Ren'Py脚本文件.rpy:552
translate english start_ac71e92e:

    # x "「其实细想一下……用随手找到的木头钻出火来，要比简单的盗取下更多的功夫……盗火的故事虽然动听，可实际上盗火要比取火容易得多」"
    x "Actually, if you think about it... making fire with a piece of wood you find lying around takes more effort than simply stealing it... The story of stealing fire is captivating, but in reality, stealing fire is much easier than making it."

# game/转换后的Ren'Py脚本文件.rpy:553
translate english start_44a6aab9:

    # z "「感觉……很厉害的样子」"
    z "It feels... really powerful."

# game/转换后的Ren'Py脚本文件.rpy:554
translate english start_fdcdf601:

    # "比起这些，我更好奇刚刚说的「救世主」到底是什么。这样的称呼，大概只在母亲口中听过。不过，这些都不是重点，真正要命的，是她在说「救世主」时，小腹传来的剧痛"
    "More than anything, I'm curious about what this \"Savior\" she just mentioned actually is. I've probably only heard that term from my mother. However, these are not the main points. What's really crucial is the severe pain in her lower abdomen when she said \"Savior.\""

# game/转换后的Ren'Py脚本文件.rpy:555
translate english start_c7d7797a:

    # x "「又有哪里不舒服吗」"
    x "Is there anything else that feels uncomfortable?"

# game/转换后的Ren'Py脚本文件.rpy:556
translate english start_f0c97c3d:

    # z "「我好像做了一个……不太好的梦……」"
    z "I seem to have had... a rather bad dream..."

# game/转换后的Ren'Py脚本文件.rpy:557
translate english start_b7a3b5cf:

    # z "「不知道为什么，眼前总是闪过地下室的景象……小腹也时不时地刺痛……」"
    z "I don't know why, but I keep seeing flashes of the basement... And my lower abdomen aches from time to time..."

# game/转换后的Ren'Py脚本文件.rpy:558
translate english start_7f6b00d1:

    # x "「原来是这样……」"
    x "so it&apos;s like this"

# game/转换后的Ren'Py脚本文件.rpy:559
translate english start_89b391fb:

    # x "「好好休息一下吧，好孩子」"
    x "Get some good rest, good boy."

# game/转换后的Ren'Py脚本文件.rpy:561
translate english start_4995eac9:

    # "希实香在身后拥抱着我，两颗心脏紧紧贴在了一起。这或许是我短暂的生命里，第一次和女生拥抱吧。"
    "Kimika hugged me from behind, and our two hearts beat close together. This was probably the first time I hugged a girl in my short life."

# game/转换后的Ren'Py脚本文件.rpy:562
translate english start_41d5b5a5:

    # "余光里，侧脸的发丝扫过女孩的脸颊，那颗小小的脑袋轻靠在我的肩头"
    "Out of the corner of my eye, the hair on the side of my face swept over the girl's cheek, and her tiny head rested lightly on my shoulder"

# game/转换后的Ren'Py脚本文件.rpy:564
translate english start_44246d62:

    # "希实香的手上似乎有什么粉末，又好像什么都没有。惨白的日光灯下，纤细的手指轻轻捂在刚刚还疼痛不已的小腹。刺痛消失不见，取而代之的是一阵恍惚"
    "It seemed that there was some powder on Kimika's hand, yet it also appeared as if there was nothing. Under the pale fluorescent light, the slender fingers gently clutched the lower abdomen that had been aching just now. The sting vanished, replaced by a moment of confusion"

# game/转换后的Ren'Py脚本文件.rpy:565
translate english start_9b97380e:

    # "无力地靠在希实香的怀里，女孩每次呼吸的起伏都无比明显。空调的微风吹动着她的发丝，也牵引着我的梦，只有在余光里才第一次发现这个瘦弱的女孩在此刻这么可爱"
    "Leaning feebly against Kimika's arms, the girl's breathing rose and fell with each breath, and it was extremely obvious. The gentle breeze from the air conditioner rustled her hair and also tugged at my dreams. Only in the corner of my eye did I notice for the first time that this thin girl was so adorable at this moment"

# game/转换后的Ren'Py脚本文件.rpy:566
translate english start_02f387f1:

    # "不知多久，我才回过神，支支吾吾吐出两个字来"
    "I don't know how long it took me to come to my senses and stammered out two words"

# game/转换后的Ren'Py脚本文件.rpy:567
translate english start_515df239:

    # z "「谢谢……」"
    z "Thank you"

# game/转换后的Ren'Py脚本文件.rpy:568
translate english start_83479b91:

    # x "「我是为了等你说这个的吗」"
    x "Was I waiting for you to say this?"

# game/转换后的Ren'Py脚本文件.rpy:569
translate english start_dc92b8b6:

    # z "「抱歉……」"
    z "Oops"

# game/转换后的Ren'Py脚本文件.rpy:570
translate english start_0e95b4d4:

    # "希实香背向我，我紧紧跟在身后，口中那句话却迟迟说不出来"
    "Kimika turned her back to me and I followed closely behind, but I couldn't utter the words for a long time"

# game/转换后的Ren'Py脚本文件.rpy:571
translate english start_1a84fbfd:

    # "我是什么时候遇见她的呢，为什么有关的记忆全都想不起来。唯一能确定的是，遇见这个女孩前，一直过着孤独的生活"
    "When did I meet her? Why can't I recall any of the related memories? The only thing that can be confirmed is that before meeting this girl, I had been living a lonely life"

# game/转换后的Ren'Py脚本文件.rpy:572
translate english start_8cf32362:

    # "就像是夜里的飞蛾，只要一点光亮就能让它奋不顾身。我就这样孤零零地活着，dqn欺负的总是我，母亲也毫不关心，所以哪怕只是一点点善意，也会拼尽全力地抓住；只要有一点点爱，就能幸福地活下去"
    "Just like a moth in the night, even a tiny bit of light can make it throw itself in recklessly. This is how I lived, all alone. I was always the one being bullied by the delinquents, and my mother didn't care at all. So, even if it was just a little bit of kindness, I would do my utmost to cling to it. As long as there was a little bit of love, I could live happily."

# game/转换后的Ren'Py脚本文件.rpy:573
translate english start_36cd1d95:

    # x "「你想去地下馆吗」"
    x "Do you want to go to the Underground Hall?"

# game/转换后的Ren'Py脚本文件.rpy:575
translate english start_77aa2fc5:

    # "她的声音再次把我拉回现实"
    "Her voice brought me back to reality again."

# game/转换后的Ren'Py脚本文件.rpy:576
translate english start_443ca27e:

    # "不知不觉又来到了走廊上"
    "Before I knew it, I was back in the hallway."

# game/转换后的Ren'Py脚本文件.rpy:585
translate english flag1_c00faed9:

    # z "「啊……随便吧」"
    z "Ah... Whatever."

# game/转换后的Ren'Py脚本文件.rpy:586
translate english flag1_9ef59972:

    # x "「里面有地震体验……我不太喜欢……」"
    x "There's an earthquake experience inside... I don't really like it..."

# game/转换后的Ren'Py脚本文件.rpy:587
translate english flag1_f2329507:

    # "不知是不是空调的缘故，黑洞洞的入口显得格外阴冷，就像梦中的地下室"
    "Perhaps it was because of the air conditioning, but the dark entrance felt especially chilly, like a basement in a dream."

# game/转换后的Ren'Py脚本文件.rpy:588
translate english flag1_f68cabc0:

    # z "「嗯……我也不喜欢这里……不如带我看看前面」"
    z "Well... I don't like it here either... Why don't you show me what's ahead?"

# game/转换后的Ren'Py脚本文件.rpy:591
translate english flag1_fc11f211:

    # "希实香带着我走马观花地体验了一台又一台设施，我总是不知道怎么接话，她却一直乐此不疲"
    "Kimika took me on a whirlwind tour of one facility after another. I never knew how to respond, but she never tired of it."

# game/转换后的Ren'Py脚本文件.rpy:593
translate english flag1_7113c3cc:

    # x "「这个『食物的旅行』其实更像是鬼屋之类的东西哦~」"
    x "This 'Food Journey' is actually more like a haunted house or something."

# game/转换后的Ren'Py脚本文件.rpy:594
translate english flag1_9b78b311:

    # x "「从这里进去的话就可以看到食物被消化的过程了」"
    x "If you go in from here, you can see the process of food being digested."

# game/转换后的Ren'Py脚本文件.rpy:595
translate english flag1_50dfa592:

    # z "「那从出口出来不就变成便便了嘛……」"
    z "Then it would turn into poop if it came out of the exit..."

# game/转换后的Ren'Py脚本文件.rpy:596
translate english flag1_5e25441d:

    # x "「嗯嗯，出来的时候就可以看到便便卓司了噢」"
    x "Uh-huh, you'll be able to see Poop Takuji when you come out."

# game/转换后的Ren'Py脚本文件.rpy:597
translate english flag1_de1bcf96:

    # z "「那还是……算了吧……」"
    z "Well... Forget it..."

# game/转换后的Ren'Py脚本文件.rpy:599
translate english flag1_4844c7ee:

    # x "「间宫君真是无聊的家伙呢」"
    x "Mamiya-kun is such a boring guy!"

# game/转换后的Ren'Py脚本文件.rpy:601
translate english flag1_2769bf89:

    # z "「前面这些彩色的管子又是干什么的呢」"
    z "What are these colorful pipes in front for?"

# game/转换后的Ren'Py脚本文件.rpy:603
translate english flag1_8c3f4522:

    # x "「嗯……我看看……好像是运输小球的通道呢」"
    x "Hmm... Let me see... It seems to be a passage for transporting small balls."

# game/转换后的Ren'Py脚本文件.rpy:604
translate english flag1_e00a93f6:

    # x "「小球通过压缩空气，机械结构，还有水力在这些透明管道里移动，用来模拟资源在城市里的传输」"
    x "Small balls move through these transparent pipes using compressed air, mechanical structures, and hydraulic power to simulate the transmission of resources in a city."

# game/转换后的Ren'Py脚本文件.rpy:605
translate english flag1_3aa1d9a2:

    # z "「怪不得叫MOVING BALLS呢」"
    z "No wonder it's called MOVING BALLS."

# game/转换后的Ren'Py脚本文件.rpy:606
translate english flag1_7bf229fc:

    # x "「这些都是给小孩玩的装置噢，带你看点好玩的东西吧~」"
    x "These are all devices for children to play with. Let me show you something fun~"

# game/转换后的Ren'Py脚本文件.rpy:609
translate english flag1_2fe9c00b:

    # x "「看吧！小球顺利到达终点了，卓司同学其实很擅长这种游戏嘛」"
    x "Look! The ball has successfully reached the finish line. Takuji is actually very good at this game."

# game/转换后的Ren'Py脚本文件.rpy:610
translate english flag1_b703939c:

    # z "「只是照着顺序按下去而已……」"
    z "Just press them in order..."

# game/转换后的Ren'Py脚本文件.rpy:612
translate english flag1_292f2012:

    # x "「没关系，管道游戏本来就很容易走错嘛」"
    x "It's okay. It's easy to make mistakes in the pipe game."

# game/转换后的Ren'Py脚本文件.rpy:613
translate english flag1_adb9a6b9:

    # z "「小球最后还是没能到达终点啊……」"
    z "In the end, the little ball still couldn't reach the finish line..."

# game/转换后的Ren'Py脚本文件.rpy:615
translate english flag1_d32aafb3:

    # "她带着我来到了一只银色的金属球前，不知为什么，下意识觉得这只球上有不小的电压"
    "She led me to a silver metal ball. For some reason, I subconsciously felt that there was a considerable amount of voltage on this ball."

# game/转换后的Ren'Py脚本文件.rpy:616
translate english flag1_c2c52837:

    # x "「把手放上去吧，间宫君~」"
    x "Put your hand on it, Mamiya-kun~"

# game/转换后的Ren'Py脚本文件.rpy:617
translate english flag1_26b7087b:

    # z "「不要……这个东西肯定是带电的」"
    z "Don't... This thing must be electrified."

# game/转换后的Ren'Py脚本文件.rpy:618
translate english flag1_8fa176bb:

    # "希实香：「放心吧，这只是一台范德格拉夫起电机，而且间宫君的脚没有接地呢，所以肯定不会触电」"
    "Kimika: \"Don't worry, it's just a Van de Graaff generator, and Mamiya-kun's feet aren't grounded, so he definitely won't get an electric shock.\""

# game/转换后的Ren'Py脚本文件.rpy:619
translate english flag1_9103236c:

    # z "「如果漏电……怎么办……」"
    z "What if there's an electrical leak... what should we do..."

# game/转换后的Ren'Py脚本文件.rpy:620
translate english flag1_0e69776a:

    # x "「那就是活该呗……谁叫你是萝莉控呢……」"
    x "That's what you deserve... Who asked you to be a lolicon..."

# game/转换后的Ren'Py脚本文件.rpy:621
translate english flag1_e00ad283:

    # z "「那我不去了……告示牌上写着它有好几千伏的电压……」"
    z "Then I won't go... The sign says it has several thousand volts of electricity..."

# game/转换后的Ren'Py脚本文件.rpy:622
translate english flag1_3842c7f6:

    # x "「心虚了对吧」"
    x "You're feeling guilty, aren't you?"

# game/转换后的Ren'Py脚本文件.rpy:623
translate english flag1_143ccc16:

    # z "「才没有……」"
    z "Never!"

# game/转换后的Ren'Py脚本文件.rpy:625
translate english flag1_a2fa6638:

    # "希实香跳上了仪器，手按在起电机上"
    "Kimika jumped onto the instrument and put her hand on the starter."

# game/转换后的Ren'Py脚本文件.rpy:626
translate english flag1_503fc5df:

    # x "「你看，根本不会触电吧」"
    x "You see, there's no way you'll get an electric shock."

# game/转换后的Ren'Py脚本文件.rpy:627
translate english flag1_c3698315:

    # x "「所以间宫君就是纯粹的心虚罢了」"
    x "So, Mamiya-kun is just feeling guilty."

# game/转换后的Ren'Py脚本文件.rpy:628
translate english flag1_f587fbae:

    # "棕色的发丝在静电的作用下一根根竖起，就像一只炸毛的橘猫"
    "The brown strands of hair stand up one by one under the influence of static electricity, like an orange cat with bristling fur."

# game/转换后的Ren'Py脚本文件.rpy:629
translate english flag1_35086479:

    # x "「给你一点小惊喜吧」"
    x "Here's a little surprise for you."

# game/转换后的Ren'Py脚本文件.rpy:630
translate english flag1_2be539c0:

    # "希实香从仪器上跳下，立刻牵住了我的手"
    "Kimika jumped off the equipment and immediately took my hand."

# game/转换后的Ren'Py脚本文件.rpy:632
translate english flag1_f4eca7e7:

    # z "「好痛……」"
    z "Ouch..."

# game/转换后的Ren'Py脚本文件.rpy:633
translate english flag1_de4592f9:

    # "一股电流穿过手心，我忍不住叫出了声来"
    "A current of electricity ran through the palm of my hand, and I couldn't help but cry out."

# game/转换后的Ren'Py脚本文件.rpy:634
translate english flag1_0b2ed8bc:

    # z "「最后还是逃不过被电吗……」"
    z "Still can't escape being electrocuted in the end..."

# game/转换后的Ren'Py脚本文件.rpy:635
translate english flag1_4dd1d1a0:

    # x "「那是因为我的身体带上了电荷呢，碰到间宫君的时候自然就会有电流了呢」"
    x "That's because my body has an electric charge. When I touch Mamiya-kun, there will naturally be an electric current."

# game/转换后的Ren'Py脚本文件.rpy:636
translate english flag1_30a83ccf:

    # "两只孤独的手紧扣在一起，奇怪的女孩拉着我继续向前"
    "Two lonely hands clasp together, and the strange girl pulls me forward."

# game/转换后的Ren'Py脚本文件.rpy:638
translate english flag1_adb2b75d:

    # "幸福的生活，大概不过如此吧。七月的夜，空调吹来微风，永不熄灭的日光灯将场馆照得格外明亮"
    "This is probably what a happy life looks like. On a July night, a gentle breeze blows from the air conditioner, and the eternally lit fluorescent lights illuminate the venue with an extraordinary brightness."

# game/转换后的Ren'Py脚本文件.rpy:639
translate english flag1_b8e0de62:

    # "今晚或许就是我最幸福的一天吧，不论真实与否，我能感受到的，只剩下心中的悸动"
    "Tonight might be the happiest day of my life. Whether it's real or not, all I can feel is the fluttering in my heart."

# game/转换后的Ren'Py脚本文件.rpy:640
translate english flag1_5ce64451:

    # "脚步不再停留，我们在场馆里横穿，穿过一条条走廊与楼梯，越过3D打印机，经过孟德尔种下豌豆的小屋"
    "Our steps never stopped as we traversed the halls, corridors, and staircases, passing by 3D printers and the small hut where Mendel planted his peas."

# game/转换后的Ren'Py脚本文件.rpy:642
translate english flag1_db00fb9f:

    # x "「我有点……累了……」"
    x "I'm a little... tired..."

# game/转换后的Ren'Py脚本文件.rpy:643
translate english flag1_bc3e7fc2:

    # "女孩在一只木质转椅上坐下，正对着几块电脑屏幕"
    "A girl sits on a wooden swivel chair facing several computer screens."

# game/转换后的Ren'Py脚本文件.rpy:645
translate english flag1_e17dfc5a:

    # x "「这几台电脑……记忆里好像是用来制作动画的……不过具体操作还是挺难的呢」"
    x "These computers... I think they were used to make animations in my memory... But the actual operation is still quite difficult."

# game/转换后的Ren'Py脚本文件.rpy:646
translate english flag1_481eb13c:

    # z "「那我肯定不会用了……」"
    z "Then I definitely won't use it..."

# game/转换后的Ren'Py脚本文件.rpy:647
translate english flag1_8729b186:

    # x "「那就坐在这里休息一会儿吧……」"
    x "Then sit here and rest for a while..."

# game/转换后的Ren'Py脚本文件.rpy:648
translate english flag1_0848106a:

    # x "「小时候来这里……这些显示器还是又大又笨重的样子呢，现在居然变成了这么薄一块的液晶屏幕……」"
    x "When I came here as a child... these monitors were still big and bulky. Now they've become such thin LCD screens..."

# game/转换后的Ren'Py脚本文件.rpy:649
translate english flag1_56036c70:

    # z "「说不定有一天电脑屏幕可以直接拿在手上，说不定还能放在口袋里……」"
    z "Maybe one day, we'll be able to hold computer screens in our hands, and maybe even put them in our pockets..."

# game/转换后的Ren'Py脚本文件.rpy:650
translate english flag1_66d15661:

    # x "「又有谁知道明天会是什么样的呢……生活在科学世纪……每一天都是新的生活啊」"
    x "Who knows what tomorrow will be like... Living in the Scientific Century... Every day is a new life."

# game/转换后的Ren'Py脚本文件.rpy:651
translate english flag1_dec0e475:

    # x "「古人来到科学世纪里，会不会把这些当做怪力乱神呢……我们看见明天的世界……心里又会想什么呢」"
    x "If people from ancient times came to the Scientific Century, would they consider these things to be gods and monsters...? When we see the world of tomorrow... what will we think?"

# game/转换后的Ren'Py脚本文件.rpy:652
translate english flag1_8167f653:

    # z "「我可能只会说好厉害这样的话吧……」"
    z "I can probably only say something like 'that's amazing'..."

# game/转换后的Ren'Py脚本文件.rpy:653
translate english flag1_a12ff4ae:

    # x "「不过当你开始理解科学之后……一切都会变得有趣很多呢……尤其是用学到的原理做出一些小玩意来的时候……真的很有成就感」"
    x "But once you start to understand science... everything becomes a lot more interesting... especially when you use the principles you've learned to make some gadgets... it really gives you a sense of accomplishment."

# game/转换后的Ren'Py脚本文件.rpy:654
translate english flag1_893d4216:

    # z "「比如呢」"
    z "Like what?"

# game/转换后的Ren'Py脚本文件.rpy:655
translate english flag1_cb38461e:

    # x "「你有用过电蚊拍吗」"
    x "Have you ever used an electric mosquito swatter?"

# game/转换后的Ren'Py脚本文件.rpy:656
translate english flag1_be1feb83:

    # z "「电蚊拍……就是那个声音听上去很吓人，但是被电到只是有一点点麻的东西嘛」"
    z "An electric fly swatter... It's the thing that sounds scary, but only gives a slight tingle when you get shocked."

# game/转换后的Ren'Py脚本文件.rpy:658
translate english flag1_e15e7bcb:

    # z "「不过说来也奇怪，据说电蚊拍上的电压有几千伏，应该足够把人电死好几百遍了吧……」"
    z "But it's strange. It's said that the voltage on an electric fly swatter is several thousand volts, which should be enough to electrocute a person hundreds of times over..."

# game/转换后的Ren'Py脚本文件.rpy:659
translate english flag1_89bd2c9c:

    # x "「那是因为电流太小了哦，所以在人身上当然没有什么威力」"
    x "That's because the current is too weak, so of course it has no effect on people."

# game/转换后的Ren'Py脚本文件.rpy:660
translate english flag1_a62b8fe6:

    # x "「不过……」"
    x "However,"

# game/转换后的Ren'Py脚本文件.rpy:661
translate english flag1_db4ada33:

    # z "「怎么了」"
    z "What's the matter?"

# game/转换后的Ren'Py脚本文件.rpy:662
translate english flag1_30ffc979:

    # x "「我有试过在坏掉的电蚊拍前面加一个大电容哦」"
    x "I tried adding a large capacitor in front of a broken electric mosquito swatter."

# game/转换后的Ren'Py脚本文件.rpy:663
translate english flag1_4c3d6f9f:

    # x "「只要按下开关，电蚊拍就会不停给电容充电……充满之后电容再瞬间放电，就会有很大的电流了」"
    x "Just press the switch, and the electric mosquito swatcher will keep charging the capacitor... Once fully charged, the capacitor will discharge instantly, and there will be a large current."

# game/转换后的Ren'Py脚本文件.rpy:664
translate english flag1_ab3158ec:

    # z "「威力应该很大的样子吧」"
    z "It should be very powerful, right?"

# game/转换后的Ren'Py脚本文件.rpy:665
translate english flag1_0eac484d:

    # x "「理论上充满电的话就算是城山这种像狗熊一样壮的dqn也可以直接电晕呢……不过呢……我也没有试过……」"
    x "Theoretically, even a dqn as strong as a bear like Shiroyama could faint directly when fully charged... But... I haven't tried it either..."

# game/转换后的Ren'Py脚本文件.rpy:667
translate english flag1_b0b6e917:

    # "听见城山的名字，我只感觉胸口被拳头狠狠击中。不是因为那些痛苦的回忆，而是纯粹来自内心的无力，只觉得对不起眼前的女孩"
    "Hearing Shiroyama's name, I felt as if a fist had struck my chest hard. It's not because of those painful memories, but purely from the powerlessness in my heart. I just feel sorry for the girl in front of me"

# game/转换后的Ren'Py脚本文件.rpy:668
translate english flag1_2d98a933:

    # "现在不是科学世纪吗，人类不是已经拥抱了文明吗，为什么还要对同类行使恶行呢"
    "Isn't it the Scientific Century now? Hasn't humanity embraced civilization? Why do we still commit evil deeds against our kind"

# game/转换后的Ren'Py脚本文件.rpy:669
translate english flag1_d177d3c6:

    # "间宫卓司，什么时候你才能勇敢一点？母亲希望你能成为救世主，不过科学世纪里也不需要这些怪力乱神，可是你连站出来保护那个爱着你的女孩都做不到，只敢这样懦弱的活着吗"
    "Takuji Mamiya, when will you be braver? Mother hopes you can be Savior, but the Scientific Century doesn't need these gods and monsters either. But you can't even stand up to protect the girl who loves you. Dare you just live so cowardice"

# game/转换后的Ren'Py脚本文件.rpy:671
translate english flag1_62b343b4:

    # "希实香离开了椅子，向着「生物万象」展区走去。看着小小的背影，心里五味杂陈，不知道是否还应该跟上她的脚步"
    "Kimika got up from the chair and walked towards the \"Biological Wonders\" exhibition area. Looking at her tiny figure, I felt a complex mix of emotions in my heart, not knowing if I should still follow in her footsteps"

# game/转换后的Ren'Py脚本文件.rpy:672
translate english flag1_47b12676:

    # x "「居然已经到了最后一个展馆……时间过得真快啊」"
    x "It's already the last exhibition hall... How time flies!"

# game/转换后的Ren'Py脚本文件.rpy:674
translate english flag1_59763952:

    # "小小的身影独自站立在水族缸前，跃动的金鱼就像是深秋的红叶，看着孤独的背影，我唯一能做的，或许就是陪伴"
    "The tiny figure stood alone in front of the aquarium. The leaping goldfish were like the red leaves in late autumn. Looking at the lonely back, perhaps the only thing I could do was to keep company"

# game/转换后的Ren'Py脚本文件.rpy:676
translate english flag1_d833d16d:

    # z "「希实香，现在几点了」"
    z "Kimika, what time is it now?"

# game/转换后的Ren'Py脚本文件.rpy:677
translate english flag1_c5f17c0c:

    # x "「嗯……应该是晚上11点的样子」"
    x "Well... It should be around 11 p.m."

# game/转换后的Ren'Py脚本文件.rpy:678
translate english flag1_24728fa4:

    # x "「因为科学馆没有空间养别的动物……所以这里就只能看鱼了哦」"
    x "Because the Science Museum doesn't have space to keep other animals... so you can only see fish here."

# game/转换后的Ren'Py脚本文件.rpy:679
translate english flag1_fdfb6112:

    # z "「没关系，哪怕只是看金鱼也已经很高兴了」"
    z "It's okay. Even just watching the goldfish is already very enjoyable."

# game/转换后的Ren'Py脚本文件.rpy:680
translate english flag1_1e74982b:

    # x "「这座老科技馆……是我小时候最喜欢来的地方……就是不知道间宫君今天感觉开不开心……」"
    x "This old science museum... was my favorite place to visit when I was a child... I just don't know if Mamiya-kun is happy today..."

# game/转换后的Ren'Py脚本文件.rpy:681
translate english flag1_16168f59:

    # z "「能和希实香一起来玩的话……不管在哪里都很高兴了」"
    z "If I can play with Kimika... I'll be happy no matter where we are."

# game/转换后的Ren'Py脚本文件.rpy:682
translate english flag1_6c482a21:

    # z "「小时候我也挺喜欢看各种各样的鱼啊，不过是在超市里，看着不同长相的海鲜，就时常感叹生命居然是如此的丰富多彩……」"
    z "When I was a child, I also liked to look at all kinds of fish, but it was in the supermarket. Looking at seafood of different appearances, I often marveled at how rich and colorful life actually is..."

# game/转换后的Ren'Py脚本文件.rpy:683
translate english flag1_e7a1ad01:

    # x "「啊！我也是！」"
    x "Ah! Me too!"

# game/转换后的Ren'Py脚本文件.rpy:684
translate english flag1_3416d257:

    # "整个场馆里回荡着她兴奋的尖叫"
    "Her excited scream echoed throughout the venue"

# game/转换后的Ren'Py脚本文件.rpy:685
translate english flag1_a61f1e33:

    # x "「因为家里比较穷……所以去动物园的机会也是比较少的……」"
    x "Because our family is relatively poor... so we don't get many chances to go to the zoo..."

# game/转换后的Ren'Py脚本文件.rpy:687
translate english flag1_9932bff9:

    # x "「这个时候超市里的水产区就变成了我的水族馆！」"
    x "At this time, the seafood section of the supermarket becomes my aquarium!"

# game/转换后的Ren'Py脚本文件.rpy:688
translate english flag1_d2db7b39:

    # x "「在冰面上的大多是海鱼的尸体……有金色的，红色的银色的……很多时候还能看见冻住的鱿鱼」"
    x "Most of what's on the ice are the carcasses of saltwater fish... There are golden ones, red ones, and silver ones... Often, you can also see frozen squid."

# game/转换后的Ren'Py脚本文件.rpy:689
translate english flag1_226048eb:

    # x "「比较浅的水箱里装的就是龙虾螃蟹和贝壳类了，它们身上都有各种各样的花纹……长相也是奇形怪状的」"
    x "The shallower tanks contain lobsters, crabs, and shellfish. They all have various patterns on them... and their appearances are also quite strange."

# game/转换后的Ren'Py脚本文件.rpy:690
translate english flag1_e6b75a7f:

    # x "「有一次我在一只快死的龙虾旁边守了整整三个小时呢，在它刚死的时候再买下来就能便宜很多了」"
    x "Once, I waited for three whole hours next to a dying lobster. If I had bought it just after it died, it would have been much cheaper."

# game/转换后的Ren'Py脚本文件.rpy:691
translate english flag1_f8a6bfbe:

    # "希实香滔滔不绝地讲述着小时候的故事，我也就在这里安静地听着"
    "Kimika talked endlessly about her childhood, and I just sat here listening quietly."

# game/转换后的Ren'Py脚本文件.rpy:692
translate english flag1_d942c8c6:

    # x "「像这种大号的水箱，装的通常就是淡水鱼和乌龟，看上去就没有什么意思了」"
    x "Large tanks like this usually contain freshwater fish and turtles, which don't look very interesting."

# game/转换后的Ren'Py脚本文件.rpy:693
translate english flag1_6de84bc4:

    # x "「不过我最喜欢的，还是那些放虾皮的地方」"
    x "But my favorite places are still those where they put shrimp shells."

# game/转换后的Ren'Py脚本文件.rpy:694
translate english flag1_260ef6ad:

    # x "「虾皮嘛……就是那些晒干的小虾米，不过可能是因为比较劣质，里面就经常混进去一些干的小鱼或者小螃蟹」"
    x "Dried shrimp... they're those small, sun-dried shrimps. But maybe because they're of lower quality, they often have some small dried fish or crabs mixed in."

# game/转换后的Ren'Py脚本文件.rpy:695
translate english flag1_029e0761:

    # x "「对我来说，这一堆堆虾皮就像是金银岛，在里面找到小螃蟹就和找到宝藏一样开心」"
    x "To me, these piles of shrimp shells are like Treasure Island. Finding little crabs in them is as joyful as discovering treasure."

# game/转换后的Ren'Py脚本文件.rpy:696
translate english flag1_c547043b:

    # x "「有一次我在里面找到了一只大拇指那么长的鱿鱼，开心了好长时间」"
    x "Once, I found a squid as long as a thumb inside, and I was happy for a long time."

# game/转换后的Ren'Py脚本文件.rpy:698
translate english flag1_2d400539:

    # x "「不过把这些动物的尸块当成水族馆来欣赏，现在想想还是有点可怕的」"
    x "But now when I think about it, it's still a bit terrifying to treat the carcasses of these animals as if they were from an aquarium."

# game/转换后的Ren'Py脚本文件.rpy:699
translate english flag1_c910c78c:

    # "希实香还在继续兴奋地讲述着，只是不知道为什么科学馆的展区，变得越来越像超市……"
    "Kimika continued to talk excitedly, but she didn't know why the exhibition area of the Science Museum was becoming more and more like a supermarket..."

# game/转换后的Ren'Py脚本文件.rpy:700
translate english flag1_f83ed2b0:

    # z "「为什么你站在一排冻鱼前面」"
    z "Why are you standing in front of a row of frozen fish?"

# game/转换后的Ren'Py脚本文件.rpy:701
translate english flag1_6eb471a5:

    # x "「啊？有吗……」"
    x "Ah? Is there..."

# game/转换后的Ren'Py脚本文件.rpy:702
translate english flag1_3c072965:

    # z "「这里看上去……明明是超市之类的地方吧」"
    z "It looks like... It's clearly a supermarket or something like that, right?"

# game/转换后的Ren'Py脚本文件.rpy:703
translate english flag1_e69b310e:

    # x "「果然是……暗示……」"
    x "Sure enough... It's a hint..."

# game/转换后的Ren'Py脚本文件.rpy:704
translate english flag1_7b4ae932:

    # "我尽可能想听清这些词语，但是无论多么努力，都没能弄明白她在说些什么"
    "I tried my best to make out the words, but no matter how hard I tried, I couldn't understand what she was saying."

# game/转换后的Ren'Py脚本文件.rpy:705
translate english flag1_285911f0:

    # "仔细想想，这次科技馆的旅程确实有些离奇"
    "Thinking about it carefully, this trip to the science museum was indeed a bit strange."

# game/转换后的Ren'Py脚本文件.rpy:706
translate english flag1_9c5a3811:

    # "关于地下室的噩梦暂且放在一边，真正奇怪的是，为什么关于希实香的记忆……无论如何都回想不起来了……"
    "Putting aside the nightmares about the basement for now, what's really strange is why I can't recall any memories of Kimika... no matter what I do..."

# game/转换后的Ren'Py脚本文件.rpy:707
translate english flag1_d491ce28:

    # "生命中萍水相逢的普通人……突然成为了深深爱着的人，在这之间的记忆却没有一丝一毫"
    "Ordinary people who met by chance in life... suddenly became deeply loved ones, and there is not a single memory in between."

# game/转换后的Ren'Py脚本文件.rpy:708
translate english flag1_c0b07115:

    # "不过事已至此，这些已经不重要了，哪怕这一切都是幻想，至少此刻的幸福是如此真实，现在我只想陪她走完这段旅程"
    "But now that things have come to this point, none of that matters anymore. Even if it's all just a fantasy, at least the happiness I feel right now is so real. All I want now is to be with her for the rest of this journey."

# game/转换后的Ren'Py脚本文件.rpy:709
translate english flag1_b0b3f03a:

    # x "「间宫君是不是昨天没有休息好……」"
    x "Did Mamiya-kun not get enough rest yesterday..."

# game/转换后的Ren'Py脚本文件.rpy:710
translate english flag1_aa70db71:

    # z "「应该吧……或许是我出现幻觉了」"
    z "I guess so... Maybe I'm hallucinating."

# game/转换后的Ren'Py脚本文件.rpy:711
translate english flag1_61e53d0d:

    # z "「不过这里有点诡异……我们还是快点离开吧……」"
    z "But it's a bit creepy here... Let's hurry and leave..."

# game/转换后的Ren'Py脚本文件.rpy:715
translate english flag1_87cd72b2:

    # "走出科技馆，迎接我们的是一望无际的莲叶，蝉声沉落，蛙声升起，一池的红莲如红焰"
    "As we stepped out of the Science and Technology Museum, we were greeted by endless lotus leaves. The sound of cicadas faded, and the croaking of frogs rose. A pond of red lotus flowers looked like a sea of red flames."

# game/转换后的Ren'Py脚本文件.rpy:716
translate english flag1_43e6d303:

    # "时间或许快到半夜12点了，天空却仍是傍晚的模样，当然我已经见怪不怪了"
    "It might almost be midnight, but the sky still looks like it's evening. Of course, I'm used to it by now."

# game/转换后的Ren'Py脚本文件.rpy:717
translate english flag1_0b916817:

    # x "「科技馆建在江边呢……沿着江一直向下就要到大海了吧」"
    x "The Science Museum is built by the river... If you follow the river downstream, you'll reach the sea."

# game/转换后的Ren'Py脚本文件.rpy:718
translate english flag1_b2651fea:

    # "天色渐渐昏沉下来，我们在江畔漫无目的地游荡着"
    "As the sky gradually darkened, we wandered aimlessly along the riverbank."

# game/转换后的Ren'Py脚本文件.rpy:719
translate english flag1_0164c289:

    # "夏夜里，阵阵江风带来水汽拂过二人之间的空隙，晴朗的夜空里夏日大三角格外醒目"
    "On a summer night, gusts of river breeze carry moisture through the space between the two. The Summer Triangle is particularly striking in the clear night sky."

# game/转换后的Ren'Py脚本文件.rpy:720
translate english flag1_44c03cf6:

    # "荷花丛中，藏着一只深绿色的小船，看上去是公园常见的样式，希实香轻巧地一跃而上"
    "A small dark green boat is hidden among the lotus flowers. It looks like a common type found in parks. Kimika nimbly jumps aboard."

# game/转换后的Ren'Py脚本文件.rpy:721
translate english flag1_3ad5177a:

    # x "「你也上来吧」"
    x "You come up too."

# game/转换后的Ren'Py脚本文件.rpy:723
translate english flag1_09b1bcbb:

    # "我当然没有理由拒绝，便跟着跳了上去，整条小船在冲击下剧烈摇晃起来" with vpunch
    "Of course, I had no reason to refuse, so I jumped on as well. The whole boat shook violently under the impact." with vpunch

# game/转换后的Ren'Py脚本文件.rpy:724
translate english flag1_ecaafcff:

    # x "「小心点，不要掉下去了」"
    x "Be careful not to fall."

# game/转换后的Ren'Py脚本文件.rpy:725
translate english flag1_04a1cea0:

    # z "「这只船真是出人意料的轻呢」"
    z "This boat is surprisingly light."

# game/转换后的Ren'Py脚本文件.rpy:726
translate english flag1_8f57d9a5:

    # x "「当然了……毕竟是劣质玻璃纤维黏合出的船体……」"
    x "Of course... After all, it's a hull made of low-quality fiberglass..."

# game/转换后的Ren'Py脚本文件.rpy:727
translate english flag1_1c3e0c08:

    # z "「那希实香的体重肯定也很轻了，跳上来居然一点动静都没有呢」"
    z "Kimika must be very light too. She jumped on and didn't make a sound."

# game/转换后的Ren'Py脚本文件.rpy:728
translate english flag1_35bf259f:

    # x "「再怎么说我也是女生嘛……」"
    x "After all, I'm a girl..."

# game/转换后的Ren'Py脚本文件.rpy:729
translate english flag1_e459d42b:

    # "不知是微风还是水流的作用，小绿船越过莲叶，缓缓漂向江心"
    "Whether it was the breeze or the current, the little green boat passed over the lotus leaves and slowly drifted toward the center of the river."

# game/转换后的Ren'Py脚本文件.rpy:730
translate english flag1_f1eaf0b4:

    # "水面上的荷花清润圆正，每片莲叶都迎风挺立着"
    "The lotus flowers on the water's surface are fresh and round, and each lotus leaf stands upright in the wind."

# game/转换后的Ren'Py脚本文件.rpy:731
translate english flag1_b4a31805:

    # "今晚的夜空，此刻也如此美丽，星辉斑斓，洒在洁白的校服上，竟如同阳光一般明亮"
    "The night sky tonight is also so beautiful at this moment, with colorful starlight shining on the pure white school uniform, as bright as sunlight."

# game/转换后的Ren'Py脚本文件.rpy:732
translate english flag1_d707c336:

    # z "「今天的星星……好亮啊……」"
    z "The stars tonight... are so bright..."

# game/转换后的Ren'Py脚本文件.rpy:733
translate english flag1_ca439caf:

    # x "「明明天空除了星星以外都是黑漆漆的……但是船上看起来就像白天一样呢」"
    x "The sky is pitch-black except for the stars... but it looks like daytime on the ship."

# game/转换后的Ren'Py脚本文件.rpy:735
translate english flag1_2e2ac932:

    # x "「全身都是光芒……与此同时却能看银河……就像太空中的宇航员……」"
    x "The whole body is glowing... and at the same time, you can see the Milky Way... like an astronaut in space..."

# game/转换后的Ren'Py脚本文件.rpy:736
translate english flag1_3707c9ca:

    # z "「那我们现在是不是也在太空里呢」"
    z "So, are we in space now too?"

# game/转换后的Ren'Py脚本文件.rpy:737
translate english flag1_a956dc19:

    # x "「是在很接近天空的地方哦」"
    x "It's a place very close to the sky."

# game/转换后的Ren'Py脚本文件.rpy:738
translate english flag1_305e39a2:

    # "江水送着小船向前，先前的荷叶已经完全消失不见"
    "The river carried the small boat forward, and the previous lotus leaves had completely vanished"

# game/转换后的Ren'Py脚本文件.rpy:740
translate english flag1_a6271e66:

    # "此时的银河也越发璀璨，巨大的星盘几乎占领着整个夜空"
    "At this moment, the Milky Way is becoming increasingly brilliant, and the huge star chart almost occupies the entire night sky"

# game/转换后的Ren'Py脚本文件.rpy:741
translate english flag1_0013a66b:

    # x "「我们来找找夏日大三角吧。按顺序连起织女星、天津四和牛郎星，就能看到它了」"
    x "Let's look for the Summer Triangle. Connect Vega, Deneb, and Altair in order, and you'll see it."

# game/转换后的Ren'Py脚本文件.rpy:744
translate english flag1_a617295d:

    # z "「原来把星星连起来，就能看见一个图案啊……」"
    z "Turns out that if you connect the stars together, you can see a pattern..."

# game/转换后的Ren'Py脚本文件.rpy:745
translate english flag1_2b21a27f:

    # x "「嗯！刚才那条线，像不像一座小小的桥？」"
    x "HMM! Didn't that line just now look like a small bridge?"

# game/转换后的Ren'Py脚本文件.rpy:746
translate english flag1_8b1b3ead:

    # z "「像是能一直通到很远的地方」"
    z "It seems to be able to go all the way to a very distant place."

# game/转换后的Ren'Py脚本文件.rpy:748
translate english flag1_823f5048:

    # z "「星星太多了……我还是有点分不清」"
    z "There are too many stars... I still can't tell them apart."

# game/转换后的Ren'Py脚本文件.rpy:749
translate english flag1_646205f6:

    # x "「没关系呀。今天能一起看星星，我就已经很开心了」"
    x "It doesn't matter. I'm already very happy to be able to watch the stars together today."

# game/转换后的Ren'Py脚本文件.rpy:750
translate english flag1_03b4c238:

    # z "「你说天空的上面，到底有什么呢，会是母亲说的上帝之类的东西嘛……」"
    z "What on earth is there up in the sky? Could it be something like God that mother mentioned..."

# game/转换后的Ren'Py脚本文件.rpy:751
translate english flag1_de7a5a67:

    # x "「比天空还要高的地方……大概是臭氧和真空吧……再往上就是太空与群星的交织了」"
    x "A place higher than the sky... probably the ozone layer and the vacuum... and beyond that is the intertwining of space and the stars."

# game/转换后的Ren'Py脚本文件.rpy:752
translate english flag1_616434da:

    # x "「话说间宫君小时候有没有想过要当宇航员呢……每个小朋友都会有这样的梦想吧」"
    x "By the way, did Mamiya-kun ever think about becoming an astronaut when he was a child... Every child has that dream, right?"

# game/转换后的Ren'Py脚本文件.rpy:754
translate english flag1_77ba5ee5:

    # z "「想不起来了唔……只记得母亲想让我当什么救世主来着……」"
    z "I can't remember... I just remember that my mother wanted me to be some kind of Savior..."

# game/转换后的Ren'Py脚本文件.rpy:755
translate english flag1_43a6abd7:

    # x "「那救世主大人一定能到更远的天空去吧」"
    x "Then, Lord Savior must be able to reach even further into the sky."

# game/转换后的Ren'Py脚本文件.rpy:756
translate english flag1_7b33a179:

    # x "「实际上人类的航天员，即使算上登上月球的那些，也始终没有离开希尔球呢」"
    x "In fact, human astronauts, even those who have landed on the moon, have never left the Hill Sphere."

# game/转换后的Ren'Py脚本文件.rpy:757
translate english flag1_4d967f3d:

    # z "「希尔球又是什么呢」"
    z "What is a Hill Ball?"

# game/转换后的Ren'Py脚本文件.rpy:758
translate english flag1_9f85ef04:

    # x "「是地球引力的实际控制区……换句话说就是地球自己的天空哦」"
    x "It's the actual control zone of Earth's gravity... In other words, it's Earth's own sky."

# game/转换后的Ren'Py脚本文件.rpy:759
translate english flag1_23547d0a:

    # x "「所以人类……某种意义上或许从没有离开过地球的天空……」"
    x "So, in a sense, humans may have never left the skies of Earth..."

# game/转换后的Ren'Py脚本文件.rpy:760
translate english flag1_ac3c2031:

    # z "「原来是这样么……可是头顶的星空，看上去离我们又是如此的接近啊」"
    z "So that's how it is... But the starry sky above us seems so close."

# game/转换后的Ren'Py脚本文件.rpy:761
translate english flag1_72052dc7:

    # z "「没开智的时候还以为人类已经可以离开太阳系了呢」"
    z "Before I became sentient, I thought humans could already leave the solar system."

# game/转换后的Ren'Py脚本文件.rpy:762
translate english flag1_e7e83355:

    # x "「但是星星间的距离远比我们想象的要更远」"
    x "But the distance between the stars is much greater than we imagine."

# game/转换后的Ren'Py脚本文件.rpy:763
translate english flag1_113d36a7:

    # x "「猎户座计划，人类最快的飞船，最快也只有1%%的光速」"
    x "Project Orion, humanity's fastest spacecraft, can only reach 1%% of the speed of light at most."

# game/转换后的Ren'Py脚本文件.rpy:764
translate english flag1_73b50d12:

    # x "「但是这个速度，飞出太阳系的引力范围可是要158年哦，到达最近的恒星要花420年……」"
    x "But at this speed, it would take 158 years to escape the gravitational pull of the solar system, and 420 years to reach the nearest star..."

# game/转换后的Ren'Py脚本文件.rpy:765
translate english flag1_1248551f:

    # x "「更何况宇宙还在不停膨胀……星星彼此之间也在不停变远……」"
    x "Not to mention that the universe is constantly expanding... and the stars are constantly moving away from each other..."

# game/转换后的Ren'Py脚本文件.rpy:767
translate english flag1_adc07477:

    # z "「那银河什么的……还是看看就好了……」"
    z "Well, the Milky Way and such... it's better to just take a look..."

# game/转换后的Ren'Py脚本文件.rpy:768
translate english flag1_358131a3:

    # z "「人在孩童时期总会喜欢幻想那些宏大的未来吧……不过现在看来，宇宙也好星辰也罢都已不再关心……我真正在意的，或许只有眼下的生活吧」"
    z "When people are children, they always like to daydream about those grand futures... But now it seems that neither the universe nor the stars care anymore... Perhaps what I truly care about is only my present life."

# game/转换后的Ren'Py脚本文件.rpy:769
translate english flag1_c17f32c2:

    # z "「年龄越大，世界看上去反而就越小了……」"
    z "The older one gets, the smaller the world seems to be..."

# game/转换后的Ren'Py脚本文件.rpy:770
translate english flag1_9d727233:

    # x "「银河虽然很远，但是斑斓的星光还是属于我们的呢……」"
    x "Although the Milky Way is far away, the brilliant stars still belong to us..."

# game/转换后的Ren'Py脚本文件.rpy:771
translate english flag1_38adc7b5:

    # "小船不知道漂出了多远，风中海水的气息越发浓郁"
    "The small boat had drifted far away, and the smell of the sea in the wind grew stronger and stronger"

# game/转换后的Ren'Py脚本文件.rpy:772
translate english flag1_46bfb2f0:

    # z "「我们会漂到哪里去啊」"
    z "Where will we drift to?"

# game/转换后的Ren'Py脚本文件.rpy:773
translate english flag1_1a54d112:

    # x "「或许是一个海港，不过这些也不重要」"
    x "Perhaps it's a seaport, but that doesn't matter."

# game/转换后的Ren'Py脚本文件.rpy:774
translate english flag1_37ef29dc:

    # x "「船都已经到这里了，卓司同学就没有什么想说的嘛」"
    x "The boat has already arrived here. Doesn't Takuji-kun have anything to say?"

# game/转换后的Ren'Py脚本文件.rpy:775
translate english flag1_56c601d1:

    # z "「呃……」"
    z "Uh."

# game/转换后的Ren'Py脚本文件.rpy:776
translate english flag1_85fdbf00:

    # "突如其来的话让我一愣，千言万语凝聚在舌尖却说不出一个字来"
    "The sudden words left me stunned. A thousand words were condensed on the tip of my tongue, but not a single one could be uttered"

# game/转换后的Ren'Py脚本文件.rpy:777
translate english flag1_cd2d6b1d:

    # "或许是想让我说出一些告白的话之类的吗，但这类事情我似乎经常会搞砸"
    "Perhaps they want me to say some confessions or something like that, but I seem to often mess up such things"

# game/转换后的Ren'Py脚本文件.rpy:778
translate english flag1_6416ac12:

    # "平静的水面上，映着我颓废的面孔。如此懦弱的我真的配得上向她告白吗"
    "On the calm water surface, my dejected face was reflected. Is such a cowardly me really worthy of confessing my love to her"

# game/转换后的Ren'Py脚本文件.rpy:779
translate english flag1_faf3c25f:

    # "母亲从小希望我当救世主，可是我连反抗那些不良都做不到……希实香也经常被欺负吧，可是我连保护这个对我满怀期待的女孩都做不到"
    "My mother wanted me to be a Savior since I was a child, but I couldn't even stand up to those bullies... Kimika was often bullied too, but I couldn't even protect this girl who had such high hopes for me."

# game/转换后的Ren'Py脚本文件.rpy:780
translate english flag1_46951ae5:

    # "欺负希实香的那个女生，好像正好是城山的女友吧，某种意义上来说我们也算是门当户对了？"
    "The girl who bullied Kimika seems to be Shiroyama's girlfriend. In a way, are we a good match?"

# game/转换后的Ren'Py脚本文件.rpy:781
translate english flag1_4283614b:

    # x "「卓司真没劲……」"
    x "Takuji is really boring..."

# game/转换后的Ren'Py脚本文件.rpy:782
translate english flag1_79beab32:

    # "她的声音，在我为这漫无边际的幻想而感到羞耻前打断了我。如果没有她的阻止，现在或许已经幻想到结婚以后的生活了"
    "Her voice interrupted me before I felt ashamed of this boundless fantasy. If she hadn't stopped me, I might have already been fantasizing about life after marriage."

# game/转换后的Ren'Py脚本文件.rpy:783
translate english flag1_dc92b8b6:

    # z "「抱歉……」"
    z "Oops"

# game/转换后的Ren'Py脚本文件.rpy:784
translate english flag1_36119108:

    # z "「最近没有人再欺负你吧」"
    z "No one's been bullying you lately, right?"

# game/转换后的Ren'Py脚本文件.rpy:786
translate english flag1_32a06a1b:

    # x "「怎么了？」"
    x "What's the matter?"

# game/转换后的Ren'Py脚本文件.rpy:787
translate english flag1_90bd78d4:

    # x "「想了这么久就只是要问我这个吗」"
    x "You've been thinking about it for so long, and all you want to ask me is this?"

# game/转换后的Ren'Py脚本文件.rpy:788
translate english flag1_bfef80c8:

    # z "「因为想到什么就说什么了……印象里希实香也是像我一样经常被欺负的人吧」"
    z "Because I just say whatever comes to mind... I have the impression that Kimika is also someone who gets bullied often, like me."

# game/转换后的Ren'Py脚本文件.rpy:790
translate english flag1_19b4c317:

    # x "「为什么……要在这个时候说这些……」"
    x "Why... are you saying this... at this time?"

# game/转换后的Ren'Py脚本文件.rpy:791
translate english flag1_19950b32:

    # x "「有的时候……真希望把这些人……全部都烧死……」"
    x "Sometimes... I really wish I could... burn all these people to death..."

# game/转换后的Ren'Py脚本文件.rpy:792
translate english flag1_ec27f543:

    # x "「惠和聪子……自然是最该死的……还有西村和城山也是一样……至于那些让我读空气的同学……也一起去死吧……」"
    x "Megumi and Satoko... they're naturally the ones who deserve to die the most... and Nishimura and Shiroyama are the same... As for those classmates who made me read the room... they can go to hell together..."

# game/转换后的Ren'Py脚本文件.rpy:793
translate english flag1_9c3aa316:

    # z "「对不起……」"
    z "Sorry"

# game/转换后的Ren'Py脚本文件.rpy:794
translate english flag1_0eac1a65:

    # "意识到好像说错了什么，我赶忙向希实香道歉，然而她似乎并不生气，只是保持着略带怪异的微笑"
    "Realizing that I might have said something wrong, I quickly apologized to Kimika. However, she didn't seem angry and just kept a slightly strange smile on her face."

# game/转换后的Ren'Py脚本文件.rpy:795
translate english flag1_9f57a607:

    # x "「我也想过很多遍用炸药把他们炸上天呢……不，应该把他们都烧死……可是终究只是在意淫罢了」"
    x "I've also thought many times about blowing them to smithereens with explosives... No, I should burn them all to death... But in the end, it's just wishful thinking."

# game/转换后的Ren'Py脚本文件.rpy:796
translate english flag1_a39a7047:

    # x "「不知道间宫君有没有听说过二甲酮呢」"
    x "I wonder if Mamiya-kun has heard of dimethone."

# game/转换后的Ren'Py脚本文件.rpy:797
translate english flag1_2c581eac:

    # z "「这个倒是没有……」"
    z "That's not the case..."

# game/转换后的Ren'Py脚本文件.rpy:798
translate english flag1_f183d456:

    # x "「就是一种女生经常会用的卸甲水啦」"
    x "It's just a kind of nail polish remover that girls often use."

# game/转换后的Ren'Py脚本文件.rpy:799
translate english flag1_c09d938a:

    # x "「只要把卸甲水和漂白剂混合在一起，再加入酸性的洁厕灵……二甲酮就会和漂白剂发生亲核加成，形成一种会爆炸的过氧化物……」"
    x "Just mix nail polish remover with bleach and add acidic toilet cleaner... dimethyl ketone will undergo nucleophilic addition with bleach, forming an explosive peroxide..."

# game/转换后的Ren'Py脚本文件.rpy:800
translate english flag1_db9dd1cc:

    # x "「呯！如果有电弧或者火花的话，过氧键就会断裂，放出一大堆气体来」"
    x "Bang! If there's an electric arc or a spark, the peroxide bond will break, releasing a large amount of gas."

# game/转换后的Ren'Py脚本文件.rpy:801
translate english flag1_5e0f825e:

    # x "「只要500克，也就是一个矿泉水瓶那么大的装置，爆炸威力已经赶上小一点的炮弹了吧……如果在教室之类的地方引爆，冲击波还会被墙面来回反射……足够把房间里所有人的内脏震碎了」"
    x "Just 500 grams, which is about the size of a mineral water bottle, the explosive power is already comparable to that of a smaller shell... If it were detonated in a classroom or something like that, the shock wave would be reflected back and forth by the walls... It would be enough to shatter the internal organs of everyone in the room."

# game/转换后的Ren'Py脚本文件.rpy:802
translate english flag1_9bf8d95b:

    # x "「但是如果现在这样做的话……卓司同学肯定也会被炸死吧……」"
    x "But if we do this now... Takuji will surely be blown up as well..."

# game/转换后的Ren'Py脚本文件.rpy:803
translate english flag1_3ba095cf:

    # "说出这些话时，她的脸上没有一丝波澜，好像是犯人在交待作案的经过，所有的流程，都蓄谋已久，只等在某个时间实施，让我不禁感到后怕"
    "When she said these words, there was not a hint of emotion on her face, as if she were a criminal confessing to the details of a crime. Every step had been premeditated for a long time, waiting only for the right moment to be carried out. It made me feel a lingering sense of fear."

# game/转换后的Ren'Py脚本文件.rpy:804
translate english flag1_ec59c836:

    # z "「会不会有点……太恐怖了呢……这么大的威力，很多无关的人也会受伤吧」"
    z "Isn't it a bit... too terrifying... With such great power, many irrelevant people might also get hurt, right?"

# game/转换后的Ren'Py脚本文件.rpy:805
translate english flag1_8d0a0660:

    # x "「不要这么紧张嘛，现实里我可是个连杀死一条鱼都会内疚很久的人哦，肯定是不会做出伤害卓司同学的事来呢」"
    x "Don't be so nervous. In reality, I'm the kind of person who would feel guilty for a long time even after killing a fish. I definitely wouldn't do anything to hurt Takuji."

# game/转换后的Ren'Py脚本文件.rpy:806
translate english flag1_77f49437:

    # x "「可是……有些事……没有办法原谅……」"
    x "But... there are some things... that cannot be forgiven..."

# game/转换后的Ren'Py脚本文件.rpy:807
translate english flag1_21cdd7dd:

    # x "「卓司大人，我是你很重要的朋友吗」"
    x "Mr. Takuji, am I an important friend of yours?"

# game/转换后的Ren'Py脚本文件.rpy:809
translate english flag1_31daf685:

    # z "「嗯……是的……是对我最最重要的人」"
    z "Well... yes... she's the most important person to me."

# game/转换后的Ren'Py脚本文件.rpy:810
translate english flag1_8d0193bc:

    # z "「躲在家里，每天只能听见母亲的训斥……到了学校又不得不忍受霸凌和冷眼……」"
    z "At home, I only hear my mother's scolding every day... And at school, I have to endure bullying and cold stares..."

# game/转换后的Ren'Py脚本文件.rpy:811
translate english flag1_263fa8b9:

    # z "「从来没有感受过他人的关爱，我的人生在这之前就像是终年生活在黑暗里的臭虫」"
    z "I've never felt the love of others. Before this, my life was like that of a bedbug living in darkness all year round."

# game/转换后的Ren'Py脚本文件.rpy:812
translate english flag1_17414aaf:

    # z "「也只有你会愿意带我来这里吧，带我一起参观机器和电，在水面幻想未来、宇宙、还有天空」"
    z "You're the only one who would be willing to bring me here, to show me the machines and the electricity, to imagine the future, the universe, and the sky on the water."

# game/转换后的Ren'Py脚本文件.rpy:813
translate english flag1_92a7e377:

    # z "「今天就是我生命最幸福的一天吧」"
    z "Today is the happiest day of my life."

# game/转换后的Ren'Py脚本文件.rpy:814
translate english flag1_78754969:

    # z "「不管受了多少委屈……只要想到还有人关心着我……就感觉好上很多了呢」"
    z "No matter how much I've been wronged... just thinking that there are still people who care about me... makes me feel much better."

# game/转换后的Ren'Py脚本文件.rpy:815
translate english flag1_26aa0e25:

    # x "「原来我也是别人心里重要的人啊……」"
    x "So, I'm also an important person in someone else's heart..."

# game/转换后的Ren'Py脚本文件.rpy:817
translate english flag1_b8d96808:

    # x "「如果有一天，你的朋友因为你而被欺负呢？或者有一天被迫加入霸凌她的行列中去……」"
    x "What if one day your friend is bullied because of you? Or one day you're forced to join in bullying her..."

# game/转换后的Ren'Py脚本文件.rpy:818
translate english flag1_9deb7f0b:

    # z "「如果做出这样的事情……恐怕我会后悔一生吧……」"
    z "If I do something like that... I'm afraid I'll regret it for the rest of my life..."

# game/转换后的Ren'Py脚本文件.rpy:819
translate english flag1_6500d80d:

    # x "「后悔……」"
    x "Regret"

# game/转换后的Ren'Py脚本文件.rpy:820
translate english flag1_e4308dc0:

    # x "「早上你醒来，简讯里全部都是她被凌辱的照片……不久之后得知了她的死讯，你又会是什么样的感受……」"
    x "You wake up in the morning, and your phone is full of messages with photos of her being abused... Not long after, you learn of her death. How would you feel...?"

# game/转换后的Ren'Py脚本文件.rpy:821
translate english flag1_8aa289f4:

    # z "「比死了还难受……」"
    z "It's worse than being dead..."

# game/转换后的Ren'Py脚本文件.rpy:822
translate english flag1_f510b939:

    # z "「大概会有比你更疯的计划吧……」"
    z "There must be a crazier plan than yours..."

# game/转换后的Ren'Py脚本文件.rpy:823
translate english flag1_098db1cf:

    # x "「……」"
    x "..."

# game/转换后的Ren'Py脚本文件.rpy:824
translate english flag1_7e077dcf:

    # x "「嗯嗯……救世主大人的计划比我更完美哦」"
    x "Uh-huh... Savior's plan is even more perfect than mine."

# game/转换后的Ren'Py脚本文件.rpy:825
translate english flag1_b007a67e:

    # "好奇怪的称呼，在沉默里，听见她在念着某个同学的名字，却无论如何都想不起来"
    "What a strange name. In the silence, I heard her reciting the name of a classmate, but I couldn't remember it no matter how hard I tried."

# game/转换后的Ren'Py脚本文件.rpy:826
translate english flag1_2690fa2f:

    # x "「不说这些了……休息一下吧」"
    x "Let's not talk about this anymore... Take a break."

# game/转换后的Ren'Py脚本文件.rpy:827
translate english flag1_8d5fbc64:

    # "回过神来时，我们已身处一望无际的水面上，或许是入海口，或许已经漂在了海上"
    "When we came to our senses, we were already on an endless expanse of water. Perhaps we were at an estuary, or maybe we were already drifting at sea."

# game/转换后的Ren'Py脚本文件.rpy:828
translate english flag1_cb83bab1:

    # "或许是时间流逝的缘故，银河在此刻已经不再清晰，只剩深蓝的水面倒映着弯曲的月影"
    "Perhaps due to the passage of time, the Milky Way is no longer clearly visible at this moment, leaving only the deep blue water surface reflecting the curved shadow of the moon."

# game/转换后的Ren'Py脚本文件.rpy:829
translate english flag1_33db6ba7:

    # z "「海面和天空……为什么都是一样的颜色呢」"
    z "Why are the sea surface and the sky both of the same color?"

# game/转换后的Ren'Py脚本文件.rpy:830
translate english flag1_eb20e622:

    # x "「忘记了……不过在水下的生物眼里，水面也许就是它们的天空……」"
    x "I forgot... But in the eyes of underwater creatures, the water surface might be their sky..."

# game/转换后的Ren'Py脚本文件.rpy:831
translate english flag1_7c2a5a89:

    # x "「间宫君还记得小学时候的第一节课是什么嘛」"
    x "Mamiya-kun, do you still remember what your first class was in primary school?"

# game/转换后的Ren'Py脚本文件.rpy:832
translate english flag1_9c1e9482:

    # z "「第一节课……唔……好久远的事情啊……」"
    z "The first lesson... Hmm... That was a long time ago..."

# game/转换后的Ren'Py脚本文件.rpy:833
translate english flag1_738400e1:

    # x "「是弯弯的月亮像小船哦，我们的小船，在海底动物的眼里，会不会被当成月亮呢」"
    x "The crescent moon looks like a little boat. Do you think our little boat would be mistaken for the moon in the eyes of the sea creatures?"

# game/转换后的Ren'Py脚本文件.rpy:834
translate english flag1_2a510f9c:

    # z "「那我们就是绿色月亮上的人了……」"
    z "Then we're the people on the Green Moon..."

# game/转换后的Ren'Py脚本文件.rpy:835
translate english flag1_091f3d1b:

    # "话语在此刻戛然而止，只有沉默回荡在空气中"
    "Words abruptly ceased at this moment, and only silence lingered in the air."

# game/转换后的Ren'Py脚本文件.rpy:836
translate english flag1_fee73c70:

    # "和希实香的聊天，总是漫无目的，甚至可以说是毫无逻辑"
    "Conversations with Kimika are always aimless, and even illogical."

# game/转换后的Ren'Py脚本文件.rpy:837
translate english flag1_022f207b:

    # "或许是因为我们都不擅长表达，说话时总像做梦一样，感觉什么都没有说，彼此却总是感觉莫名的喜悦"
    "Perhaps it's because neither of us is good at expressing ourselves. When we talk, it's always like a dream. It feels like we haven't said anything, yet we always feel an inexplicable joy with each other."

# game/转换后的Ren'Py脚本文件.rpy:838
translate english flag1_c98cc1b4:

    # "逻辑的边界或许是语言，但爱的边界不是。即使什么也不做，即使只是看着彼此，只是沉默不语，也掩盖不了此刻的幸福"
    "The boundaries of logic may be language, but the boundaries of love are not. Even if we do nothing, even if we just look at each other and remain silent, we cannot hide the happiness of this moment."

# game/转换后的Ren'Py脚本文件.rpy:839
translate english flag1_660678b1:

    # "沉默间，耳边突然传来微弱的说话声"
    "In the silence, a faint voice suddenly reached my ears."

# game/转换后的Ren'Py脚本文件.rpy:841
translate english flag1_3f6767a0:

    # x "「船儿弯弯入海港，回头望望……沧海茫茫……」"
    x "The boat curves into the harbor, looking back... the sea is vast..."

# game/转换后的Ren'Py脚本文件.rpy:842
translate english flag1_41f50b88:

    # x "「说的大概就是现在这样吧」"
    x "That's probably what it's like now."

# game/转换后的Ren'Py脚本文件.rpy:843
translate english flag1_3ba3ccc8:

    # z "「好厉害……希实香可真是大文豪」"
    z "Wow... Kimika is truly a great writer."

# game/转换后的Ren'Py脚本文件.rpy:844
translate english flag1_8fe70219:

    # x "「只是一首流行歌的歌词而已……」"
    x "It's just the lyrics of a pop song..."

# game/转换后的Ren'Py脚本文件.rpy:845
translate english flag1_97a111c7:

    # z "「那也很厉害了，不像我背了那么多名句，写文章和聊天的时候一句也想不起来……」"
    z "That's pretty impressive. Unlike me, I memorized so many famous quotes, but I can't recall a single one when writing an article or chatting..."

# game/转换后的Ren'Py脚本文件.rpy:846
translate english flag1_f6e3a6b5:

    # z "「不过我们这样真的能漂到某个海港里吗，如果被海风吹到远方该怎么回来呢」"
    z "But can we really drift to a harbor like this? What if the sea breeze blows us far away, how will we get back?"

# game/转换后的Ren'Py脚本文件.rpy:847
translate english flag1_0788205c:

    # x "「等到天亮的时候……你自然可以回家……」"
    x "When dawn comes... you can naturally go home..."

# game/转换后的Ren'Py脚本文件.rpy:848
translate english flag1_53eee30c:

    # z "「天亮的时候……」"
    z "When it's light out."

# game/转换后的Ren'Py脚本文件.rpy:849
translate english flag1_84ea39bc:

    # z "「现在几点了，希实香」"
    z "What time is it, Kimika?"

# game/转换后的Ren'Py脚本文件.rpy:850
translate english flag1_73479321:

    # x "「你大概已经四点了吧……太阳要出来了……」"
    x "It's probably already four o'clock... The sun is about to rise..."

# game/转换后的Ren'Py脚本文件.rpy:851
translate english flag1_bb463994:

    # x "「太阳出来的时候……我就要离开了」"
    x "When the sun comes up... I'll be leaving."

# game/转换后的Ren'Py脚本文件.rpy:852
translate english flag1_78b7e076:

    # "海平面上虽然看不见天阳，此时的天空，却已微亮，呈现出和电脑死机时一样的暗蓝色"
    "Although the sun was not visible above the sea level, the sky was already faintly lit, showing the same dark blue as when a computer crashes."

# game/转换后的Ren'Py脚本文件.rpy:853
translate english flag1_12a7884e:

    # z "「不和我一起回去的话……你又要去哪里呢」"
    z "If you don't come back with me... where else would you go?"

# game/转换后的Ren'Py脚本文件.rpy:854
translate english flag1_5b8e17dc:

    # x "「去和星星在一起的地方……按照救世主大人您的计划哦」"
    x "Go to the place where you are with the stars... Follow your plan, Savior."

# game/转换后的Ren'Py脚本文件.rpy:855
translate english flag1_5a4dd969:

    # x "「去比希尔球更高的地方……比猎户座计划飞得更远的地方……」"
    x "To a place higher than Hill Ball... to a place farther than the Orion program..."

# game/转换后的Ren'Py脚本文件.rpy:857
translate english flag1_6645edb9:

    # z "「有多远呢」"
    z "How far is it?"

# game/转换后的Ren'Py脚本文件.rpy:858
translate english flag1_4ea4a1dd:

    # x "「是一个比本超星系团更高的地方吧」"
    x "Is it a place higher than this supercluster?"

# game/转换后的Ren'Py脚本文件.rpy:859
translate english flag1_08d684f4:

    # "我已经习惯了她无厘头的回答，便索性顺着问题问了下去"
    "I was used to her nonsensical answers, so I just continued asking questions."

# game/转换后的Ren'Py脚本文件.rpy:860
translate english flag1_e70e8c18:

    # z "「那以后……我们还会见面吗」"
    z "Then... will we still meet in the future?"

# game/转换后的Ren'Py脚本文件.rpy:861
translate english flag1_23da382b:

    # x "「或许吧……或许是明天，也可能是后天……或者是在可观测宇宙的庞加莱重现时间里的某一天」"
    x "Perhaps... perhaps it's tomorrow, or maybe it's the day after tomorrow... or some day in the Poincare reenactment time of the observable universe."

# game/转换后的Ren'Py脚本文件.rpy:862
translate english flag1_7048277e:

    # x "「太阳快出来了，我的时间要到新的一天了……还有什么想说的吗」"
    x "The sun is about to rise, and my time is coming to an end for the day... Is there anything else you'd like to say?"

# game/转换后的Ren'Py脚本文件.rpy:863
translate english flag1_afd10170:

    # "不知道是不是太累导致的错觉，希实香的身影似乎变得透明了，眼眶也挂上了一丝不易察觉泪痕"
    "Perhaps it was an illusion caused by exhaustion, but Kimika's figure seemed to become transparent, and there was a faint trace of tears in the corners of her eyes."

# game/转换后的Ren'Py脚本文件.rpy:864
translate english flag1_a08d5a09:

    # "刚刚的语气，像是在哀悼什么，让我心头闪过一丝不好的预感"
    "The tone just now seemed to be mourning something, which made a bad premonition flash through my mind"

# game/转换后的Ren'Py脚本文件.rpy:866
translate english flag1_277f0d16:

    # "就像黑暗中的飞蛾扑向火光，本能让我紧紧抱住了她"
    "Just like a moth in the darkness lunging towards the firelight, instinct made me hold her tightly"

# game/转换后的Ren'Py脚本文件.rpy:867
translate english flag1_a0bcff5e:

    # "把头埋在白色校服里，淡淡的熏衣草味扑面而来"
    "Burying his head in the white school uniform, a faint scent of lavender wafted towards him"

# game/转换后的Ren'Py脚本文件.rpy:868
translate english flag1_3eed17ca:

    # x "「好闻吧，是我的洗衣液的味道哦」"
    x "It smells good, doesn't it? It's the scent of my laundry detergent."

# game/转换后的Ren'Py脚本文件.rpy:869
translate english flag1_385eb97d:

    # z "「请不要……离开我……」"
    z "Please don't... leave me..."

# game/转换后的Ren'Py脚本文件.rpy:870
translate english flag1_b981b8ef:

    # z "「我深深爱着的……最最重要的人……」"
    z "The most important person... whom I love deeply..."

# game/转换后的Ren'Py脚本文件.rpy:871
translate english flag1_f3c8298d:

    # x "「但是救世主大人您的计划就是这样……而且……我也是有罪的人啊……如果放弃回归天空的计划……我是无论如何都不会原谅自己的……」"
    x "But, Lord Savior, this is your plan... And... I am also a sinner... If I abandon the plan to Return to the Sky... I will never forgive myself..."

# game/转换后的Ren'Py脚本文件.rpy:872
translate english flag1_8974d91a:

    # x "「间宫君也是我最最在乎的男生哦，所以请一定要幸福地活下去……」"
    x "Mamiya-kun is also the boy I care about the most, so please be sure to live happily..."

# game/转换后的Ren'Py脚本文件.rpy:873
translate english flag1_6637f20e:

    # "救世主是什么呢，在这科学世纪里，真的会有天父或者怪力乱神吗？"
    "What is Savior? In this Scientific Century, will there really be the Heavenly Father or gods and monsters?"

# game/转换后的Ren'Py脚本文件.rpy:874
translate english flag1_40d0b1c9:

    # "天空也好，怪力乱神也罢……这些都去死吧，我只想抱住眼前的女孩，在这科学世纪里，牵着彼此的手，就这样过着平凡的生活"
    "Whether it's the sky or gods and monsters... Let all of these die. I just want to hold the girl in front of me, in this Scientific Century, hold each other's hands, and just live an ordinary life like this"

# game/转换后的Ren'Py脚本文件.rpy:875
translate english flag1_1f45550e:

    # "dqn的拳头又怎么样呢……就算死掉，我也真心希望唯一在乎我的女孩能替我好好地活着……"
    "So what about dqn's fist... Even if I die, I sincerely hope that the only girl who cares about me can live well for me..."

# game/转换后的Ren'Py脚本文件.rpy:877
translate english flag1_0b9ce5e8:

    # x "「太阳要出来了……」"
    x "The sun is about to rise..."

# game/转换后的Ren'Py脚本文件.rpy:878
translate english flag1_bae3877a:

    # x "「偌大的海面只有我们两个人，什么也没有，就像荒岛上一样……」"
    x "There are only the two of us on this vast sea, with nothing else, just like on a deserted island..."

# game/转换后的Ren'Py脚本文件.rpy:879
translate english flag1_ad44e889:

    # x "「再见了，我深深爱着的男孩」"
    x "Goodbye, the boy I love so deeply."

# game/转换后的Ren'Py脚本文件.rpy:880
translate english flag1_4f53f0dc:

    # z "「再见的意思，就是还会见面吗」"
    z "Does 'goodbye' mean we'll see each other again?"

# game/转换后的Ren'Py脚本文件.rpy:881
translate english flag1_25ec92b3:

    # "希实香只留下了一个微笑，嘴里好像在念叨着什么，或许是像战国的大名死前吟诵的故乡黄花之类的东西。"
    "Kimika only left behind a smile, as if she were muttering something, perhaps something like the yellow flowers of her hometown that a Warring States daimyo would recite before dying."

# game/转换后的Ren'Py脚本文件.rpy:882
translate english flag1_c163e8e3:

    # "海的边缘已经略微能看见金色的晨光，留给我们的时间不多了"
    "The golden morning light is already faintly visible at the edge of the sea. We don't have much time left."

# game/转换后的Ren'Py脚本文件.rpy:884
translate english flag1_05236f40:

    # x "「我在荒岛上迎接黎明……」"
    x "I'm welcoming the dawn on a deserted island..."

# game/转换后的Ren'Py脚本文件.rpy:885
translate english flag1_8ed82c55:

    # x "「太阳初升时，忽然有十万支金喇叭齐鸣」"
    x "When the sun first rose, suddenly a hundred thousand golden trumpets sounded together."

# game/转换后的Ren'Py脚本文件.rpy:886
translate english flag1_ef5ba944:

    # x "「阳光穿过透明的空气，在暗蓝色的天空飞过」"
    x "The sunlight passes through the clear air and flies across the dark blue sky."

# game/转换后的Ren'Py脚本文件.rpy:887
translate english flag1_c129bf7a:

    # x "「在黑暗尚未褪去的海面上燃烧着十万支蜡烛……」"
    x "A hundred thousand candles are burning on the sea where the darkness has not yet faded..."

# game/转换后的Ren'Py脚本文件.rpy:888
translate english flag1_c6e2f4ea:

    # x "「我听见天地之间钟声响了……然后十万支金喇叭又一次齐鸣」"
    x "I heard the bells ringing between heaven and earth... then a hundred thousand golden trumpets blared again in unison."

# game/转换后的Ren'Py脚本文件.rpy:889
translate english flag1_e992734c:

    # x "「告诉他们...我度过了美好的一生...」"
    x "Tell them... I have lived a wonderful life..."

# game/转换后的Ren'Py脚本文件.rpy:890
translate english flag1_e1463eff:

    # "女孩笼罩在金色的晨光里，身体渐渐变得透明"
    "The girl is enveloped in the golden morning light, and her body gradually becomes transparent."

# game/转换后的Ren'Py脚本文件.rpy:891
translate english flag1_0f82f9b7:

    # "再见，就是再次见面的意思吧……再次见面又会是什么时候呢？或许是下午，或许是明天。"
    "\"Goodbye\" means we'll meet again... But when will that be? Maybe this afternoon, maybe tomorrow."

# game/转换后的Ren'Py脚本文件.rpy:892
translate english flag1_3ccfdf4c:

    # z "「风是流动的空气……或许就是大海与天空的交际吧」"
    z "Wind is the flowing air... Perhaps it is the communication between the sea and the sky."

# game/转换后的Ren'Py脚本文件.rpy:893
translate english flag1_cf272be1:

    # z "「如果不能再见，就让这海风替我来保佑你」"
    z "If we can't meet again, let this sea breeze bless you for me."

# game/转换后的Ren'Py脚本文件.rpy:894
translate english flag1_212a23d4:

    # z "「请不要忘记，在时间的某个角落，那个深深爱着你的人……」"
    z "Please don't forget, in some corner of time, that person who loves you deeply..."

# game/转换后的Ren'Py脚本文件.rpy:896
translate english flag1_09b75606:

    # centered "{cps=15}{size=+40}2012年7月20日{/size}{/cps}"
    centered "0⟧{size=+40}20 July 2012 {/size}{/cps}"

# game/转换后的Ren'Py脚本文件.rpy:897
translate english flag1_4a8574cd:

    # centered "{cps=15}{size=+40}北校数十名学生集体跳楼{/size}{/cps}"
    centered "0⟧{size=+40} Dozens of students from North School jumped off a building together {/size}{/cps}"

# game/转换后的Ren'Py脚本文件.rpy:898
translate english flag1_65ea493f:

    # centered "{cps=15}{size=+40}尽管高度较低{/size}{/cps}"
    centered "{cps=15}{size=+40}Despite the lower height{/size}{/cps}"

# game/转换后的Ren'Py脚本文件.rpy:899
translate english flag1_119086fe:

    # centered "{cps=15}{size=+40}依然造成了大量学生死亡{/size}{/cps}"
    centered "{cps=15}{size=+40}Still resulted in a large number of student deaths{/size}{/cps}"

# game/转换后的Ren'Py脚本文件.rpy:900
translate english flag1_db9706ab:

    # centered "{cps=15}{size=+40}只有一人{/size}{/cps}"
    centered "{cps=15}{size=+40}Only one person{/size}{/cps}"

# game/转换后的Ren'Py脚本文件.rpy:901
translate english flag1_a3919aeb:

    # centered "{cps=15}{size=+40}由于被强气流吹入绿化带中{/size}{/cps}"
    centered "{cps=15}{size=+40}Due to being blown into the green belt by strong gusts of wind{/size}{/cps}"

# game/转换后的Ren'Py脚本文件.rpy:902
translate english flag1_1b86ab41:

    # centered "{cps=15}{size=+40}得以幸存……{/size}{/cps}"
    centered "{cps=15}{size=+40}survived……{/size}{/cps}"

# game/转换后的Ren'Py脚本文件.rpy:904
translate english flag1_d46dda23:

    # centered "{size=+60}{color=#C8A84E}遙かなる夢に～{/color}{/size}" with Dissolve(3.0)
    centered "{size=+60}{color=#C8A84E}Harukanaru Yume ni ~{/color}{/size}" with Dissolve(3.0)

# game/转换后的Ren'Py脚本文件.rpy:905
translate english flag1_417bc682:

    # centered "{size=+60}{color=#C8A84E}by Eikige \n2026.7.20{/color}{/size}" with Dissolve(1.0)
    centered "{size=+60}{color=#C8A84E}by Eikige \n2026.7.20{/color}{/size}" with Dissolve(1.0)

# game/转换后的Ren'Py脚本文件.rpy:912
translate english flag2_4781fbe5:

    # z "「地下馆吗……那就去看看好了」"
    z "The Underground Hall...? Let's go and take a look."

# game/转换后的Ren'Py脚本文件.rpy:913
translate english flag2_e3b2eba8:

    # x "「好吧……」"
    x "OK."

# game/转换后的Ren'Py脚本文件.rpy:915
translate english flag2_c203b414:

    # "地下展区的墙壁，用的是天然石材，让整个展馆看上去像是一个山洞。不用说，这大概是个介绍地质活动的场馆"
    "The walls of the underground exhibition area are made of natural stone, making the entire pavilion look like a cave. Needless to say, this is probably a hall that introduces geological activities."

# game/转换后的Ren'Py脚本文件.rpy:916
translate english flag2_4a77204e:

    # "或许是缺少灯光的缘故，地下室显得格外昏暗，视线也变得模糊。在这深灰色的石壁间，一丝格格不入的粉色吸引了我的目光"
    "Perhaps due to the lack of lighting, the basement seemed especially dim, and my vision became blurred. Amidst these dark gray stone walls, a touch of jarring pink caught my eye."

# game/转换后的Ren'Py脚本文件.rpy:917
translate english flag2_250a48f7:

    # z "「彩名同学？」"
    z "Ayana?"

# game/转换后的Ren'Py脚本文件.rpy:919
translate english flag2_771c4faa:

    # c "「你好」"
    c "hello"

# game/转换后的Ren'Py脚本文件.rpy:920
translate english flag2_fb5fea1e:

    # z "「彩名同学为什么会在这里呢」"
    z "Why is Ayana here?"

# game/转换后的Ren'Py脚本文件.rpy:921
translate english flag2_e055a429:

    # c "「卓司同学为什么也在这里呢」"
    c "Why is Takuji-kun here too?"

# game/转换后的Ren'Py脚本文件.rpy:923
translate english flag2_5517ec34:

    # z "「是一个很重要的人带我来的……」"
    z "I was brought here by a very important person..."

# game/转换后的Ren'Py脚本文件.rpy:924
translate english flag2_6346fada:

    # "我下意识向希实香看去，却并未看见那个小小的身影"
    "I subconsciously looked at Kimika, but I didn't see that small figure."

# game/转换后的Ren'Py脚本文件.rpy:925
translate english flag2_bc2fb0a6:

    # c "「现在这里只有我们两个」"
    c "It's just the two of us here now."

# game/转换后的Ren'Py脚本文件.rpy:926
translate english flag2_6d140ba8:

    # c "「所以这就是你想要的幸福的生活吗」"
    c "So, is this the happy life you want?"

# game/转换后的Ren'Py脚本文件.rpy:927
translate english flag2_f084fdaa:

    # z "「算是吧……毕竟只要能看见希实香的笑脸，就已经感觉很开心了……不过你们或许永远没法理解……」"
    z "I guess so... After all, just seeing Kimika's smiling face makes me feel happy... But you may never understand..."

# game/转换后的Ren'Py脚本文件.rpy:929
translate english flag2_f9508fb8:

    # c "「于是你打算幸福地生活多久呢」"
    c "So, how long do you plan to live happily ever after?"

# game/转换后的Ren'Py脚本文件.rpy:930
translate english flag2_a1f6c70d:

    # c "「药物和语言把你带到了这间科学馆里，以此逃避你本该到达的终点」"
    c "Drugs and language bring you to this the Science Museum to escape the destination you should have reached."

# game/转换后的Ren'Py脚本文件.rpy:931
translate english flag2_0812ec1f:

    # z "「什么？」"
    z "What?"

# game/转换后的Ren'Py脚本文件.rpy:932
translate english flag2_485c393a:

    # c "「不信的话可以摸摸你的口袋」"
    c "If you don't believe it, you can touch your pocket."

# game/转换后的Ren'Py脚本文件.rpy:933
translate english flag2_a7a4611e:

    # "将手伸进口袋里，竟真的摸到了一包粉末"
    "He reached into his pocket and actually felt a bag of powder."

# game/转换后的Ren'Py脚本文件.rpy:934
translate english flag2_e28343cd:

    # c "「是东莨菪碱和lsd的混合物哦」"
    c "It's a mixture of scopolamine and lsd."

# game/转换后的Ren'Py脚本文件.rpy:935
translate english flag2_b7e15aee:

    # z "「lsd……是什么……」"
    z "What is lsd...?"

# game/转换后的Ren'Py脚本文件.rpy:937
translate english flag2_525ff436:

    # c "「一群人被锁在山洞里，终身只能面对洞壁……他们只能看到身后火光照射下的影子，以为那就是全部的世界……」"
    c "A group of people were locked in a cave and could only face the cave walls for the rest of their lives... They could only see the shadows cast by the firelight behind them, thinking that was the entire world..."

# game/转换后的Ren'Py脚本文件.rpy:938
translate english flag2_4e39c1fe:

    # c "「只能看见影子的生活，会是幸福的吗」"
    c "Can a life where one can only see shadows be happy?"

# game/转换后的Ren'Py脚本文件.rpy:939
translate english flag2_08559dc3:

    # z "「或许是吧……如果山洞外面只有战争和死亡的话……坐在山洞里到也挺好的」"
    z "Perhaps... If there's only war and death outside the cave... Then sitting in the cave is pretty good."

# game/转换后的Ren'Py脚本文件.rpy:940
translate english flag2_77921b52:

    # z "「小时候在村子里生活……我就喜欢盯着火光发呆……听老人们说火堆又叫丛林电视机……猎人晚上休息的时候就会盯着篝火打发时间」"
    z "When I was a child living in the village... I liked to stare at the flames... I heard the old folks say that the bonfire was also called the jungle TV... Hunters would stare at the bonfire to pass the time when they rested at night."

# game/转换后的Ren'Py脚本文件.rpy:942
translate english flag2_c7ec0046:

    # c "「如果在山洞里的是卓司同学的话……是愿意相信影子就是真实的世界，还是会逃到洞外的阳光下呢」"
    c "If it were Takuji-kun in the cave... would he be willing to believe that the shadow is the real world, or would he escape to the sunlight outside the cave?"

# game/转换后的Ren'Py脚本文件.rpy:943
translate english flag2_33a3e70f:

    # z "「希实香告诉我……眼睛能看见东西是因为物体反射了对应的光……」"
    z "Kimika told me... that the eyes can see things because objects reflect the corresponding light..."

# game/转换后的Ren'Py脚本文件.rpy:944
translate english flag2_8dee64cb:

    # z "「看见影子是因为火焰在发光……看见山洞外的世界，是因为有阳光」"
    z "You see shadows because the fire is glowing... You see the world outside the cave because there is sunlight."

# game/转换后的Ren'Py脚本文件.rpy:945
translate english flag2_00a3a765:

    # z "「或许太阳只不过是个更大的火堆……挣脱锁链，看上去是离开了山洞……实际上或许只是来到另一个山洞……」"
    z "Perhaps the sun is just a bigger bonfire... Breaking free from the chains, it seems like you've left the cave... But in reality, you might have just entered another cave..."

# game/转换后的Ren'Py脚本文件.rpy:946
translate english flag2_a9fea7ee:

    # z "「世界上有太多人总是宣扬自己最真实，最正确，以此来愚弄那些无知的人」"
    z "There are too many people in the world who always claim to be the most truthful and the most correct, using this to fool those who are ignorant."

# game/转换后的Ren'Py脚本文件.rpy:947
translate english flag2_5b8378eb:

    # z "「但我觉得……谁能让我拥有真正的幸福……谁就是正确的……」"
    z "But I feel... whoever can make me truly happy... is the right one..."

# game/转换后的Ren'Py脚本文件.rpy:949
translate english flag2_fc256b4e:

    # z "「所以哪里的生活是快乐的……哪里就是真实的世界……」"
    z "So, where life is happy... that's where the real world is..."

# game/转换后的Ren'Py脚本文件.rpy:950
translate english flag2_9c597e70:

    # "彩名消失不见，只是小腹又痛了起来。希实香大概已经离开这个展馆了，我便加快步伐走了出去"
    "Ayana disappeared, but my lower abdomen started hurting again. Kimika had probably already left the exhibition hall, so I quickened my pace and walked out."

# game/转换后的Ren'Py脚本文件.rpy:952
translate english flag2_ef4ce19b:

    # x "「到哪去了，刚刚我可是一直在找你呢」"
    x "Where have you been? I've been looking for you."

# game/转换后的Ren'Py脚本文件.rpy:953
translate english flag2_a463a927:

    # z "「我可能……有一点不舒服……」"
    z "I might be... feeling a little unwell..."

# game/转换后的Ren'Py脚本文件.rpy:954
translate english flag2_7e83462d:

    # "身体的刺痛越发强烈，我只好跑进厕所，以免被看见失态的模样"
    "The tingling sensation in my body grew stronger, and I had no choice but to run to the bathroom to avoid being seen in an embarrassing state."

# game/转换后的Ren'Py脚本文件.rpy:956
translate english flag2_11ed7e09:

    # "低头望去，身上明明没有伤口，衬衣却已被血染红"
    "Looking down, there were clearly no wounds on his body, but his shirt was stained red with blood."

# game/转换后的Ren'Py脚本文件.rpy:957
translate english flag2_d3689da9:

    # "无数离奇的记忆涌入脑海中，告诉我小腹上的血迹是和某个很熟悉的人决斗时留下的痕迹。可那张面孔，无论如何都回想不起"
    "Countless bizarre memories flooded my mind, telling me that the bloodstain on my lower abdomen was a mark left from a duel with someone very familiar. But no matter what, I couldn't recall that face."

# game/转换后的Ren'Py脚本文件.rpy:958
translate english flag2_dca76978:

    # "血液越渗越多，我只能无力地靠在墙上"
    "The blood kept seeping out, and I could only lean helplessly against the wall."

# game/转换后的Ren'Py脚本文件.rpy:959
translate english flag2_257c04d1:

    # "血迹在白色布料上晕开，形成一个圆形，就像每个小孩画画时都会先在纸上画出的太阳一样"
    "The bloodstain spread on the white fabric, forming a circle, just like the sun that every child draws on paper first when they draw."

# game/转换后的Ren'Py脚本文件.rpy:960
translate english flag2_dfe05f6a:

    # "厕所里既阴冷又潮湿，与灯火通明的科技馆宛若两个世界"
    "The restroom was both chilly and damp, a stark contrast to the brightly lit science museum, as if they belonged to two different worlds."

# game/转换后的Ren'Py脚本文件.rpy:962
translate english flag2_9bbb9f8c:

    # "可这令人窒息的潮湿，却又带来了难以言说的熟悉感"
    "But this suffocating dampness also brings an indescribable sense of familiarity"

# game/转换后的Ren'Py脚本文件.rpy:963
translate english flag2_21ac8ad9:

    # "恍惚间，竟看见自己身处在一间地下室中，高大的承重梁交错纵横"
    "In a trance, I actually saw myself in a basement, with tall load-bearing beams crisscrossing each other"

# game/转换后的Ren'Py脚本文件.rpy:964
translate english flag2_93702a4b:

    # "淫语在耳边回响，那些平日里令我厌恶不堪的同学们正在不远处滥交着，余光里只能勉强看见些肉色"
    "Lewd words echoed in my ears. Those classmates who usually detested me were chatting indiscriminately not far away. Out of the corner of my eye, I could only barely catch a glimpse of some flesh color"

# game/转换后的Ren'Py脚本文件.rpy:966
translate english flag2_cb8a4948:

    # c "「最终还是看见了山洞外的世界吗」"
    c "Did you finally see the world outside the cave?"

# game/转换后的Ren'Py脚本文件.rpy:967
translate english flag2_b135026a:

    # c "「半合成的致幻剂，果然效果有限啊」"
    c "The semi-synthetic hallucinogen really does have limited effects."

# game/转换后的Ren'Py脚本文件.rpy:968
translate english flag2_c36b66c6:

    # c "「橘同学或许应该再加大一点剂量」"
    c "Perhaps Tachibana-san should increase the dosage a little more."

# game/转换后的Ren'Py脚本文件.rpy:969
translate english flag2_9696a58b:

    # "说话声将我的思绪拉了回来"
    "The voice brought my thoughts back"

# game/转换后的Ren'Py脚本文件.rpy:970
translate english flag2_6a1bd180:

    # z "「啊！！为什么你会在这里」"
    z "Ah!! Why are you here?"

# game/转换后的Ren'Py脚本文件.rpy:971
translate english flag2_ce93306c:

    # c "「上厕所」"
    c "Going to the toilet"

# game/转换后的Ren'Py脚本文件.rpy:972
translate english flag2_8b76b0cb:

    # z "「这里可是男厕所！！」"
    z "Here's the men's restroom!!"

# game/转换后的Ren'Py脚本文件.rpy:973
translate english flag2_c35bf2ab:

    # c "「我也是像卓司同学一样要用小便池上厕所的人哦」"
    c "I'm also someone like Takuji who needs to use the urinal to use the toilet."

# game/转换后的Ren'Py脚本文件.rpy:974
translate english flag2_e47edd7d:

    # z "「不要在跟着我说这些奇怪的话了，现在快点给我离开」"
    z "Stop following me and saying these strange things. Get out of here right now."

# game/转换后的Ren'Py脚本文件.rpy:975
translate english flag2_64901932:

    # c "「还是愿意守在那个女孩留给你的火堆前吗」"
    c "Are you still willing to stand by the fire that girl left you?"

# game/转换后的Ren'Py脚本文件.rpy:976
translate english flag2_14ef72e9:

    # "我不愿再理这个奇怪的人，于是便夺门而出"
    "I didn't want to deal with this strange person anymore, so I rushed out of the door"

# game/转换后的Ren'Py脚本文件.rpy:978
translate english flag2_d6f5485e:

    # x "「上了这么久厕所……不会是在里面对我幻想什么东西吧」"
    x "Having been in the toilet for so long... Could it be that you were daydreaming about something in front of me inside?"

# game/转换后的Ren'Py脚本文件.rpy:979
translate english flag2_143ccc16:

    # z "「才没有……」"
    z "Never!"

# game/转换后的Ren'Py脚本文件.rpy:980
translate english flag2_799a1032:

    # "玩笑没能掩盖住希实香眼中闪过的忧伤我尽力想遮住身上的血迹，不愿让她担心"
    "The joke failed to hide the sadness that flashed in Kimika's eyes. I tried my best to cover the bloodstains on my body, not wanting to worry her"

# game/转换后的Ren'Py脚本文件.rpy:981
translate english flag2_030c0274:

    # "低头看时，却发现血迹早已消失不见，彩名的声音却依然回荡在耳边"
    "When she looked down, she found that the bloodstains had already disappeared, but Ayana's voice still echoed in her ears."

# game/转换后的Ren'Py脚本文件.rpy:982
translate english flag2_e8696e6b:

    # z "「那个……我想问你一件事情……」"
    z "Well... I want to ask you something..."

# game/转换后的Ren'Py脚本文件.rpy:983
translate english flag2_7ad03340:

    # x "「什么啊」"
    x "Why?"

# game/转换后的Ren'Py脚本文件.rpy:984
translate english flag2_59b695a5:

    # z "「lsd还有东茛菪碱……都是什么呢」"
    z "LSD and scopolamine... What are they?"

# game/转换后的Ren'Py脚本文件.rpy:985
translate english flag2_85fbfc6b:

    # x "「就是圣药啊…」"
    x "It's the sacred medicine..."

# game/转换后的Ren'Py脚本文件.rpy:989
translate english flag2_542ddfa1:

    # z "「圣药，没听过…」"
    z "Sacred medicine? I've never heard of it..."

# game/转换后的Ren'Py脚本文件.rpy:990
translate english flag2_40611ae6:

    # x "「噢不对不对，你为什么突然问这个呢」"
    x "Oh, no, no. Why are you suddenly asking about this?"

# game/转换后的Ren'Py脚本文件.rpy:991
translate english flag2_155863ee:

    # x "「lsd就是麦角酸乙二胺，是一种半人工合成的致幻剂……因为是脂溶性的，所以通过皮肤接触就能吸收……只要很小的剂量就能产生幻觉…」"
    x "LSD, or lysergic acid diethylamide, is a semi-synthetic hallucinogen... Because it is fat-soluble, it can be absorbed through skin contact... Even a very small dose can induce hallucinations..."

# game/转换后的Ren'Py脚本文件.rpy:992
translate english flag2_94414414:

    # x "「不过因为药理机制原因吧，lsd的毒性实际上相当的低」"
    x "However, due to its pharmacological mechanism, LSD's toxicity is actually quite low."

# game/转换后的Ren'Py脚本文件.rpy:993
translate english flag2_c503ed9b:

    # x "「就算单次摄入极大剂量，也只是会导致体温过高，神经紊乱……目前似乎没有致死的案例」"
    x "Even if a very large dose is ingested at once, it will only lead to hyperthermia and neurological disorders... There don't seem to be any fatal cases at present."

# game/转换后的Ren'Py脚本文件.rpy:994
translate english flag2_6a64e38e:

    # "果然，这会是幻觉么……就算是这一切都是假的，我也希望幻觉能久一点吧"
    "Sure enough, could this be an illusion...? Even if all of this is fake, I hope the illusion lasts a little longer."

# game/转换后的Ren'Py脚本文件.rpy:995
translate english flag2_973eb4f9:

    # "毕竟，快乐的时光也太少了，就让我长久地睡下去吧，睁眼或许又要看见糟糕的世界"
    "After all, there are so few happy moments. Let me sleep for a long time. If I open my eyes, I might see a terrible world again."

# game/转换后的Ren'Py脚本文件.rpy:996
translate english flag2_d69854aa:

    # "如果永远不会醒来，那么梦与现实又有什么区别呢"
    "If you never wake up, what's the difference between dreams and reality?"

# game/转换后的Ren'Py脚本文件.rpy:999
translate english flag2_99bd6382:

    # "理解眼前的一切或许要花不少精力，接下来的行程，大概就是希实香带着我走马观花地体验了一台又一台设施，我总是不知道如何回应她的话题，她却一直乐此不疲"
    "It might take a lot of effort to understand everything in front of me. The next part of the tour was probably Kimika taking me on a whirlwind tour of one facility after another. I never knew how to respond to her topics, but she was always enthusiastic."

# game/转换后的Ren'Py脚本文件.rpy:1001
translate english flag2_7113c3cc:

    # x "「这个『食物的旅行』其实更像是鬼屋之类的东西哦~」"
    x "This 'Food Journey' is actually more like a haunted house or something."

# game/转换后的Ren'Py脚本文件.rpy:1002
translate english flag2_9b78b311:

    # x "「从这里进去的话就可以看到食物被消化的过程了」"
    x "If you go in from here, you can see the process of food being digested."

# game/转换后的Ren'Py脚本文件.rpy:1003
translate english flag2_50dfa592:

    # z "「那从出口出来不就变成便便了嘛……」"
    z "Then it would turn into poop if it came out of the exit..."

# game/转换后的Ren'Py脚本文件.rpy:1004
translate english flag2_5e25441d:

    # x "「嗯嗯，出来的时候就可以看到便便卓司了噢」"
    x "Uh-huh, you'll be able to see Poop Takuji when you come out."

# game/转换后的Ren'Py脚本文件.rpy:1005
translate english flag2_de1bcf96:

    # z "「那还是……算了吧……」"
    z "Well... Forget it..."

# game/转换后的Ren'Py脚本文件.rpy:1007
translate english flag2_4844c7ee:

    # x "「间宫君真是无聊的家伙呢」"
    x "Mamiya-kun is such a boring guy!"

# game/转换后的Ren'Py脚本文件.rpy:1009
translate english flag2_2769bf89:

    # z "「前面这些彩色的管子又是干什么的呢」"
    z "What are these colorful pipes in front for?"

# game/转换后的Ren'Py脚本文件.rpy:1011
translate english flag2_8c3f4522:

    # x "「嗯……我看看……好像是运输小球的通道呢」"
    x "Hmm... Let me see... It seems to be a passage for transporting small balls."

# game/转换后的Ren'Py脚本文件.rpy:1012
translate english flag2_e00a93f6:

    # x "「小球通过压缩空气，机械结构，还有水力在这些透明管道里移动，用来模拟资源在城市里的传输」"
    x "Small balls move through these transparent pipes using compressed air, mechanical structures, and hydraulic power to simulate the transmission of resources in a city."

# game/转换后的Ren'Py脚本文件.rpy:1013
translate english flag2_3aa1d9a2:

    # z "「怪不得叫MOVING BALLS呢」"
    z "No wonder it's called MOVING BALLS."

# game/转换后的Ren'Py脚本文件.rpy:1014
translate english flag2_6c0983b9:

    # x "「小球在管道里受到了力的作用……如果对力做关于时间的积分，就可以求出力的冲量……」"
    x "The small ball is subjected to a force in the pipe... If you integrate the force with respect to time, you can find the impulse of the force..."

# game/转换后的Ren'Py脚本文件.rpy:1015
translate english flag2_adab1c2b:

    # x "「同样的道理，如果想在短时间内按住高速下落的物体，就必须要承受极大的作用力……」"
    x "Similarly, if you want to hold an object falling at high speed for a short period of time, you must withstand an enormous force..."

# game/转换后的Ren'Py脚本文件.rpy:1016
translate english flag2_88a324ab:

    # z "「这样啊」"
    z "I see."

# game/转换后的Ren'Py脚本文件.rpy:1019
translate english flag2_2fe9c00b:

    # x "「看吧！小球顺利到达终点了，卓司同学其实很擅长这种游戏嘛」"
    x "Look! The ball has successfully reached the finish line. Takuji is actually very good at this game."

# game/转换后的Ren'Py脚本文件.rpy:1020
translate english flag2_b703939c:

    # z "「只是照着顺序按下去而已……」"
    z "Just press them in order..."

# game/转换后的Ren'Py脚本文件.rpy:1022
translate english flag2_292f2012:

    # x "「没关系，管道游戏本来就很容易走错嘛」"
    x "It's okay. It's easy to make mistakes in the pipe game."

# game/转换后的Ren'Py脚本文件.rpy:1023
translate english flag2_adb9a6b9:

    # z "「小球最后还是没能到达终点啊……」"
    z "In the end, the little ball still couldn't reach the finish line..."

# game/转换后的Ren'Py脚本文件.rpy:1024
translate english flag2_7bf229fc:

    # x "「这些都是给小孩玩的装置噢，带你看点好玩的东西吧~」"
    x "These are all devices for children to play with. Let me show you something fun~"

# game/转换后的Ren'Py脚本文件.rpy:1026
translate english flag2_d32aafb3:

    # "她带着我来到了一只银色的金属球前，不知为什么，下意识觉得这只球上有不小的电压"
    "She led me to a silver metal ball. For some reason, I subconsciously felt that there was a considerable amount of voltage on this ball."

# game/转换后的Ren'Py脚本文件.rpy:1027
translate english flag2_c2c52837:

    # x "「把手放上去吧，间宫君~」"
    x "Put your hand on it, Mamiya-kun~"

# game/转换后的Ren'Py脚本文件.rpy:1028
translate english flag2_26b7087b:

    # z "「不要……这个东西肯定是带电的」"
    z "Don't... This thing must be electrified."

# game/转换后的Ren'Py脚本文件.rpy:1029
translate english flag2_8fa176bb:

    # "希实香：「放心吧，这只是一台范德格拉夫起电机，而且间宫君的脚没有接地呢，所以肯定不会触电」"
    "Kimika: \"Don't worry, it's just a Van de Graaff generator, and Mamiya-kun's feet aren't grounded, so he definitely won't get an electric shock.\""

# game/转换后的Ren'Py脚本文件.rpy:1030
translate english flag2_9103236c:

    # z "「如果漏电……怎么办……」"
    z "What if there's an electrical leak... what should we do..."

# game/转换后的Ren'Py脚本文件.rpy:1031
translate english flag2_0e69776a:

    # x "「那就是活该呗……谁叫你是萝莉控呢……」"
    x "That's what you deserve... Who asked you to be a lolicon..."

# game/转换后的Ren'Py脚本文件.rpy:1032
translate english flag2_e00ad283:

    # z "「那我不去了……告示牌上写着它有好几千伏的电压……」"
    z "Then I won't go... The sign says it has several thousand volts of electricity..."

# game/转换后的Ren'Py脚本文件.rpy:1033
translate english flag2_3842c7f6:

    # x "「心虚了对吧」"
    x "You're feeling guilty, aren't you?"

# game/转换后的Ren'Py脚本文件.rpy:1034
translate english flag2_143ccc16_1:

    # z "「才没有……」"
    z "Never!"

# game/转换后的Ren'Py脚本文件.rpy:1036
translate english flag2_e6399aba:

    # z "「我不是喜欢萝莉什么的……只是我喜欢的人，住在一个小小的身体里……」"
    z "I don't like lolitas or anything like that... It's just that the person I like happens to be in a small body..."

# game/转换后的Ren'Py脚本文件.rpy:1037
translate english flag2_3bd08c7f:

    # "希实香跳上了仪器，双手按在起电机上"
    "Kimika jumped onto the instrument and pressed her hands on the starter."

# game/转换后的Ren'Py脚本文件.rpy:1038
translate english flag2_503fc5df:

    # x "「你看，根本不会触电吧」"
    x "You see, there's no way you'll get an electric shock."

# game/转换后的Ren'Py脚本文件.rpy:1039
translate english flag2_c3698315:

    # x "「所以间宫君就是纯粹的心虚罢了」"
    x "So, Mamiya-kun is just feeling guilty."

# game/转换后的Ren'Py脚本文件.rpy:1040
translate english flag2_80f163a5:

    # "棕色的发丝在静电的作用下一根根竖起，就像一只炸毛的小猫"
    "The brown strands of hair stand up one by one under the influence of static electricity, like a kitten with bristled fur."

# game/转换后的Ren'Py脚本文件.rpy:1041
translate english flag2_f52c4d50:

    # x "「闭上眼睛给你一个小礼物吧」"
    x "Close your eyes, I have a little gift for you."

# game/转换后的Ren'Py脚本文件.rpy:1042
translate english flag2_2be539c0:

    # "希实香从仪器上跳下，立刻牵住了我的手"
    "Kimika jumped off the equipment and immediately took my hand."

# game/转换后的Ren'Py脚本文件.rpy:1044
translate english flag2_f4eca7e7:

    # z "「好痛……」"
    z "Ouch..."

# game/转换后的Ren'Py脚本文件.rpy:1045
translate english flag2_de4592f9:

    # "一股电流穿过手心，我忍不住叫出了声来"
    "A current of electricity ran through the palm of my hand, and I couldn't help but cry out."

# game/转换后的Ren'Py脚本文件.rpy:1046
translate english flag2_0b2ed8bc:

    # z "「最后还是逃不过被电吗……」"
    z "Still can't escape being electrocuted in the end..."

# game/转换后的Ren'Py脚本文件.rpy:1047
translate english flag2_4dd1d1a0:

    # x "「那是因为我的身体带上了电荷呢，碰到间宫君的时候自然就会有电流了呢」"
    x "That's because my body has an electric charge. When I touch Mamiya-kun, there will naturally be an electric current."

# game/转换后的Ren'Py脚本文件.rpy:1048
translate english flag2_30a83ccf:

    # "两只孤独的手紧扣在一起，奇怪的女孩拉着我继续向前"
    "Two lonely hands clasp together, and the strange girl pulls me forward."

# game/转换后的Ren'Py脚本文件.rpy:1050
translate english flag2_adb2b75d:

    # "幸福的生活，大概不过如此吧。七月的夜，空调吹来微风，永不熄灭的日光灯将场馆照得格外明亮"
    "This is probably what a happy life looks like. On a July night, a gentle breeze blows from the air conditioner, and the eternally lit fluorescent lights illuminate the venue with an extraordinary brightness."

# game/转换后的Ren'Py脚本文件.rpy:1051
translate english flag2_b8e0de62:

    # "今晚或许就是我最幸福的一天吧，不论真实与否，我能感受到的，只剩下心中的悸动"
    "Tonight might be the happiest day of my life. Whether it's real or not, all I can feel is the fluttering in my heart."

# game/转换后的Ren'Py脚本文件.rpy:1052
translate english flag2_5ce64451:

    # "脚步不再停留，我们在场馆里横穿，穿过一条条走廊与楼梯，越过3D打印机，经过孟德尔种下豌豆的小屋"
    "Our steps never stopped as we traversed the halls, corridors, and staircases, passing by 3D printers and the small hut where Mendel planted his peas."

# game/转换后的Ren'Py脚本文件.rpy:1054
translate english flag2_db00fb9f:

    # x "「我有点……累了……」"
    x "I'm a little... tired..."

# game/转换后的Ren'Py脚本文件.rpy:1055
translate english flag2_bc3e7fc2:

    # "女孩在一只木质转椅上坐下，正对着几块电脑屏幕"
    "A girl sits on a wooden swivel chair facing several computer screens."

# game/转换后的Ren'Py脚本文件.rpy:1057
translate english flag2_e17dfc5a:

    # x "「这几台电脑……记忆里好像是用来制作动画的……不过具体操作还是挺难的呢」"
    x "These computers... I think they were used to make animations in my memory... But the actual operation is still quite difficult."

# game/转换后的Ren'Py脚本文件.rpy:1058
translate english flag2_481eb13c:

    # z "「那我肯定不会用了……」"
    z "Then I definitely won't use it..."

# game/转换后的Ren'Py脚本文件.rpy:1059
translate english flag2_8729b186:

    # x "「那就坐在这里休息一会儿吧……」"
    x "Then sit here and rest for a while..."

# game/转换后的Ren'Py脚本文件.rpy:1060
translate english flag2_0848106a:

    # x "「小时候来这里……这些显示器还是又大又笨重的样子呢，现在居然变成了这么薄一块的液晶屏幕……」"
    x "When I came here as a child... these monitors were still big and bulky. Now they've become such thin LCD screens..."

# game/转换后的Ren'Py脚本文件.rpy:1061
translate english flag2_56036c70:

    # z "「说不定有一天电脑屏幕可以直接拿在手上，说不定还能放在口袋里……」"
    z "Maybe one day, we'll be able to hold computer screens in our hands, and maybe even put them in our pockets..."

# game/转换后的Ren'Py脚本文件.rpy:1062
translate english flag2_66d15661:

    # x "「又有谁知道明天会是什么样的呢……生活在科学世纪……每一天都是新的生活啊」"
    x "Who knows what tomorrow will be like... Living in the Scientific Century... Every day is a new life."

# game/转换后的Ren'Py脚本文件.rpy:1063
translate english flag2_dec0e475:

    # x "「古人来到科学世纪里，会不会把这些当做怪力乱神呢……我们看见明天的世界……心里又会想什么呢」"
    x "If people from ancient times came to the Scientific Century, would they consider these things to be gods and monsters...? When we see the world of tomorrow... what will we think?"

# game/转换后的Ren'Py脚本文件.rpy:1064
translate english flag2_8167f653:

    # z "「我可能只会说好厉害这样的话吧……」"
    z "I can probably only say something like 'that's amazing'..."

# game/转换后的Ren'Py脚本文件.rpy:1065
translate english flag2_a12ff4ae:

    # x "「不过当你开始理解科学之后……一切都会变得有趣很多呢……尤其是用学到的原理做出一些小玩意来的时候……真的很有成就感」"
    x "But once you start to understand science... everything becomes a lot more interesting... especially when you use the principles you've learned to make some gadgets... it really gives you a sense of accomplishment."

# game/转换后的Ren'Py脚本文件.rpy:1066
translate english flag2_893d4216:

    # z "「比如呢」"
    z "Like what?"

# game/转换后的Ren'Py脚本文件.rpy:1067
translate english flag2_cb38461e:

    # x "「你有用过电蚊拍吗」"
    x "Have you ever used an electric mosquito swatter?"

# game/转换后的Ren'Py脚本文件.rpy:1068
translate english flag2_be1feb83:

    # z "「电蚊拍……就是那个声音听上去很吓人，但是被电到只是有一点点麻的东西嘛」"
    z "An electric fly swatter... It's the thing that sounds scary, but only gives a slight tingle when you get shocked."

# game/转换后的Ren'Py脚本文件.rpy:1070
translate english flag2_e15e7bcb:

    # z "「不过说来也奇怪，据说电蚊拍上的电压有几千伏，应该足够把人电死好几百遍了吧……」"
    z "But it's strange. It's said that the voltage on an electric fly swatter is several thousand volts, which should be enough to electrocute a person hundreds of times over..."

# game/转换后的Ren'Py脚本文件.rpy:1071
translate english flag2_89bd2c9c:

    # x "「那是因为电流太小了哦，所以在人身上当然没有什么威力」"
    x "That's because the current is too weak, so of course it has no effect on people."

# game/转换后的Ren'Py脚本文件.rpy:1072
translate english flag2_a62b8fe6:

    # x "「不过……」"
    x "However,"

# game/转换后的Ren'Py脚本文件.rpy:1073
translate english flag2_db4ada33:

    # z "「怎么了」"
    z "What's the matter?"

# game/转换后的Ren'Py脚本文件.rpy:1074
translate english flag2_30ffc979:

    # x "「我有试过在坏掉的电蚊拍前面加一个大电容哦」"
    x "I tried adding a large capacitor in front of a broken electric mosquito swatter."

# game/转换后的Ren'Py脚本文件.rpy:1075
translate english flag2_4c3d6f9f:

    # x "「只要按下开关，电蚊拍就会不停给电容充电……充满之后电容再瞬间放电，就会有很大的电流了」"
    x "Just press the switch, and the electric mosquito swatcher will keep charging the capacitor... Once fully charged, the capacitor will discharge instantly, and there will be a large current."

# game/转换后的Ren'Py脚本文件.rpy:1076
translate english flag2_ab3158ec:

    # z "「威力应该很大的样子吧」"
    z "It should be very powerful, right?"

# game/转换后的Ren'Py脚本文件.rpy:1077
translate english flag2_0eac484d:

    # x "「理论上充满电的话就算是城山这种像狗熊一样壮的dqn也可以直接电晕呢……不过呢……我也没有试过……」"
    x "Theoretically, even a dqn as strong as a bear like Shiroyama could faint directly when fully charged... But... I haven't tried it either..."

# game/转换后的Ren'Py脚本文件.rpy:1079
translate english flag2_b0b6e917:

    # "听见城山的名字，我只感觉胸口被拳头狠狠击中。不是因为那些痛苦的回忆，而是纯粹来自内心的无力，只觉得对不起眼前的女孩"
    "Hearing Shiroyama's name, I felt as if a fist had struck my chest hard. It's not because of those painful memories, but purely from the powerlessness in my heart. I just feel sorry for the girl in front of me"

# game/转换后的Ren'Py脚本文件.rpy:1080
translate english flag2_2d98a933:

    # "现在不是科学世纪吗，人类不是已经拥抱了文明吗，为什么还要对同类行使恶行呢"
    "Isn't it the Scientific Century now? Hasn't humanity embraced civilization? Why do we still commit evil deeds against our kind"

# game/转换后的Ren'Py脚本文件.rpy:1081
translate english flag2_d177d3c6:

    # "间宫卓司，什么时候你才能勇敢一点？母亲希望你能成为救世主，不过科学世纪里也不需要这些怪力乱神，可是你连站出来保护那个爱着你的女孩都做不到，只敢这样懦弱的活着吗"
    "Takuji Mamiya, when will you be braver? Mother hopes you can be Savior, but the Scientific Century doesn't need these gods and monsters either. But you can't even stand up to protect the girl who loves you. Dare you just live so cowardice"

# game/转换后的Ren'Py脚本文件.rpy:1083
translate english flag2_62b343b4:

    # "希实香离开了椅子，向着「生物万象」展区走去。看着小小的背影，心里五味杂陈，不知道是否还应该跟上她的脚步"
    "Kimika got up from the chair and walked towards the \"Biological Wonders\" exhibition area. Looking at her tiny figure, I felt a complex mix of emotions in my heart, not knowing if I should still follow in her footsteps"

# game/转换后的Ren'Py脚本文件.rpy:1084
translate english flag2_47b12676:

    # x "「居然已经到了最后一个展馆……时间过得真快啊」"
    x "It's already the last exhibition hall... How time flies!"

# game/转换后的Ren'Py脚本文件.rpy:1085
translate english flag2_59763952:

    # "小小的身影独自站立在水族缸前，跃动的金鱼就像是深秋的红叶，看着孤独的背影，我唯一能做的，或许就是陪伴"
    "The tiny figure stood alone in front of the aquarium. The leaping goldfish were like the red leaves in late autumn. Looking at the lonely back, perhaps the only thing I could do was to keep company"

# game/转换后的Ren'Py脚本文件.rpy:1087
translate english flag2_d833d16d:

    # z "「希实香，现在几点了」"
    z "Kimika, what time is it now?"

# game/转换后的Ren'Py脚本文件.rpy:1088
translate english flag2_c5f17c0c:

    # x "「嗯……应该是晚上11点的样子」"
    x "Well... It should be around 11 p.m."

# game/转换后的Ren'Py脚本文件.rpy:1089
translate english flag2_24728fa4:

    # x "「因为科学馆没有空间养别的动物……所以这里就只能看鱼了哦」"
    x "Because the Science Museum doesn't have space to keep other animals... so you can only see fish here."

# game/转换后的Ren'Py脚本文件.rpy:1090
translate english flag2_fdfb6112:

    # z "「没关系，哪怕只是看金鱼也已经很高兴了」"
    z "It's okay. Even just watching the goldfish is already very enjoyable."

# game/转换后的Ren'Py脚本文件.rpy:1091
translate english flag2_1e74982b:

    # x "「这座老科技馆……是我小时候最喜欢来的地方……就是不知道间宫君今天感觉开不开心……」"
    x "This old science museum... was my favorite place to visit when I was a child... I just don't know if Mamiya-kun is happy today..."

# game/转换后的Ren'Py脚本文件.rpy:1092
translate english flag2_16168f59:

    # z "「能和希实香一起来玩的话……不管在哪里都很高兴了」"
    z "If I can play with Kimika... I'll be happy no matter where we are."

# game/转换后的Ren'Py脚本文件.rpy:1093
translate english flag2_6c482a21:

    # z "「小时候我也挺喜欢看各种各样的鱼啊，不过是在超市里，看着不同长相的海鲜，就时常感叹生命居然是如此的丰富多彩……」"
    z "When I was a child, I also liked to look at all kinds of fish, but it was in the supermarket. Looking at seafood of different appearances, I often marveled at how rich and colorful life actually is..."

# game/转换后的Ren'Py脚本文件.rpy:1094
translate english flag2_e7a1ad01:

    # x "「啊！我也是！」"
    x "Ah! Me too!"

# game/转换后的Ren'Py脚本文件.rpy:1095
translate english flag2_3416d257:

    # "整个场馆里回荡着她兴奋的尖叫"
    "Her excited scream echoed throughout the venue"

# game/转换后的Ren'Py脚本文件.rpy:1096
translate english flag2_a61f1e33:

    # x "「因为家里比较穷……所以去动物园的机会也是比较少的……」"
    x "Because our family is relatively poor... so we don't get many chances to go to the zoo..."

# game/转换后的Ren'Py脚本文件.rpy:1098
translate english flag2_9932bff9:

    # x "「这个时候超市里的水产区就变成了我的水族馆！」"
    x "At this time, the seafood section of the supermarket becomes my aquarium!"

# game/转换后的Ren'Py脚本文件.rpy:1099
translate english flag2_d2db7b39:

    # x "「在冰面上的大多是海鱼的尸体……有金色的，红色的银色的……很多时候还能看见冻住的鱿鱼」"
    x "Most of what's on the ice are the carcasses of saltwater fish... There are golden ones, red ones, and silver ones... Often, you can also see frozen squid."

# game/转换后的Ren'Py脚本文件.rpy:1101
translate english flag2_226048eb:

    # x "「比较浅的水箱里装的就是龙虾螃蟹和贝壳类了，它们身上都有各种各样的花纹……长相也是奇形怪状的」"
    x "The shallower tanks contain lobsters, crabs, and shellfish. They all have various patterns on them... and their appearances are also quite strange."

# game/转换后的Ren'Py脚本文件.rpy:1102
translate english flag2_e6b75a7f:

    # x "「有一次我在一只快死的龙虾旁边守了整整三个小时呢，在它刚死的时候再买下来就能便宜很多了」"
    x "Once, I waited for three whole hours next to a dying lobster. If I had bought it just after it died, it would have been much cheaper."

# game/转换后的Ren'Py脚本文件.rpy:1103
translate english flag2_f8a6bfbe:

    # "希实香滔滔不绝地讲述着小时候的故事，我也就在这里安静地听着"
    "Kimika talked endlessly about her childhood, and I just sat here listening quietly."

# game/转换后的Ren'Py脚本文件.rpy:1104
translate english flag2_d942c8c6:

    # x "「像这种大号的水箱，装的通常就是淡水鱼和乌龟，看上去就没有什么意思了」"
    x "Large tanks like this usually contain freshwater fish and turtles, which don't look very interesting."

# game/转换后的Ren'Py脚本文件.rpy:1105
translate english flag2_6de84bc4:

    # x "「不过我最喜欢的，还是那些放虾皮的地方」"
    x "But my favorite places are still those where they put shrimp shells."

# game/转换后的Ren'Py脚本文件.rpy:1106
translate english flag2_260ef6ad:

    # x "「虾皮嘛……就是那些晒干的小虾米，不过可能是因为比较劣质，里面就经常混进去一些干的小鱼或者小螃蟹」"
    x "Dried shrimp... they're those small, sun-dried shrimps. But maybe because they're of lower quality, they often have some small dried fish or crabs mixed in."

# game/转换后的Ren'Py脚本文件.rpy:1107
translate english flag2_029e0761:

    # x "「对我来说，这一堆堆虾皮就像是金银岛，在里面找到小螃蟹就和找到宝藏一样开心」"
    x "To me, these piles of shrimp shells are like Treasure Island. Finding little crabs in them is as joyful as discovering treasure."

# game/转换后的Ren'Py脚本文件.rpy:1108
translate english flag2_c547043b:

    # x "「有一次我在里面找到了一只大拇指那么长的鱿鱼，开心了好长时间」"
    x "Once, I found a squid as long as a thumb inside, and I was happy for a long time."

# game/转换后的Ren'Py脚本文件.rpy:1109
translate english flag2_2d400539:

    # x "「不过把这些动物的尸块当成水族馆来欣赏，现在想想还是有点可怕的」"
    x "But now when I think about it, it's still a bit terrifying to treat the carcasses of these animals as if they were from an aquarium."

# game/转换后的Ren'Py脚本文件.rpy:1110
translate english flag2_c910c78c:

    # "希实香还在继续兴奋地讲述着，只是不知道为什么科学馆的展区，变得越来越像超市……"
    "Kimika continued to talk excitedly, but she didn't know why the exhibition area of the Science Museum was becoming more and more like a supermarket..."

# game/转换后的Ren'Py脚本文件.rpy:1111
translate english flag2_f83ed2b0:

    # z "「为什么你站在一排冻鱼前面」"
    z "Why are you standing in front of a row of frozen fish?"

# game/转换后的Ren'Py脚本文件.rpy:1112
translate english flag2_6eb471a5:

    # x "「啊？有吗……」"
    x "Ah? Is there..."

# game/转换后的Ren'Py脚本文件.rpy:1113
translate english flag2_26b0ee13:

    # z "「这里看上去……明明之超市之类的地方吧」"
    z "This place looks like... a supermarket or something."

# game/转换后的Ren'Py脚本文件.rpy:1115
translate english flag2_eb4c3d69:

    # c "「是的这里就是超市哦」"
    c "Yes, this is the supermarket."

# game/转换后的Ren'Py脚本文件.rpy:1116
translate english flag2_88d56ec4:

    # c "「超市水族馆里可以看冰冻尸体带鱼，冰冻尸体罗非，冰冻尸体石斑鱼，冰冻尸体食人鱼」"
    c "In the supermarket aquarium, you can see frozen hairtail, frozen tilapia, frozen grouper, and frozen piranha."

# game/转换后的Ren'Py脚本文件.rpy:1117
translate english flag2_b84f3077:

    # c "「干燥毛虾尸体，干燥磷虾尸体，干燥鱿鱼尸体，干燥墨鱼尸体，干燥虾蛄尸体」"
    c "Dried shrimp carcasses, dried krill carcasses, dried squid carcasses, dried cuttlefish carcasses, dried mantis shrimp carcasses"

# game/转换后的Ren'Py脚本文件.rpy:1119
translate english flag2_7c8a3c44:

    # c "「干燥并被亚硝酸盐腌制的家畜尸体碎块，破碎鸟类尸体，腐烂dqn尸体」"
    c "Dried and nitrite-cured fragments of livestock carcasses, broken bird carcasses, and decomposed dqn carcasses."

# game/转换后的Ren'Py脚本文件.rpy:1120
translate english flag2_4e430558:

    # c "「再过一会儿说不定还能看见破碎的聪子尸体，惠的尸体碎块，还有破碎○○○尸体」"
    c "In a little while, we might still be able to see Satoshi's broken body, the fragments of Kei's body, and ○○○'s broken body."

# game/转换后的Ren'Py脚本文件.rpy:1122
translate english flag2_7df8e4a8:

    # "我努力想听清最后几个字，音无彩名却已消失不见"
    "I tried to make out the last few words, but Ayana Otonashi had already disappeared."

# game/转换后的Ren'Py脚本文件.rpy:1123
translate english flag2_285911f0:

    # "仔细想想，这次科技馆的旅程确实有些离奇"
    "Thinking about it carefully, this trip to the science museum was indeed a bit strange."

# game/转换后的Ren'Py脚本文件.rpy:1124
translate english flag2_9c5a3811:

    # "关于地下室的噩梦暂且放在一边，真正奇怪的是，为什么关于希实香的记忆……无论如何都回想不起来了……"
    "Putting aside the nightmares about the basement for now, what's really strange is why I can't recall any memories of Kimika... no matter what I do..."

# game/转换后的Ren'Py脚本文件.rpy:1125
translate english flag2_d491ce28:

    # "生命中萍水相逢的普通人……突然成为了深深爱着的人，在这之间的记忆却没有一丝一毫"
    "Ordinary people who met by chance in life... suddenly became deeply loved ones, and there is not a single memory in between."

# game/转换后的Ren'Py脚本文件.rpy:1126
translate english flag2_c0b07115:

    # "不过事已至此，这些已经不重要了，哪怕这一切都是幻想，至少此刻的幸福是如此真实，现在我只想陪她走完这段旅程"
    "But now that things have come to this point, none of that matters anymore. Even if it's all just a fantasy, at least the happiness I feel right now is so real. All I want now is to be with her for the rest of this journey."

# game/转换后的Ren'Py脚本文件.rpy:1127
translate english flag2_b0b3f03a:

    # x "「间宫君是不是昨天没有休息好……」"
    x "Did Mamiya-kun not get enough rest yesterday..."

# game/转换后的Ren'Py脚本文件.rpy:1128
translate english flag2_aa70db71:

    # z "「应该吧……或许是我出现幻觉了」"
    z "I guess so... Maybe I'm hallucinating."

# game/转换后的Ren'Py脚本文件.rpy:1129
translate english flag2_61e53d0d:

    # z "「不过这里有点诡异……我们还是快点离开吧……」"
    z "But it's a bit creepy here... Let's hurry and leave..."

# game/转换后的Ren'Py脚本文件.rpy:1133
translate english flag2_87cd72b2:

    # "走出科技馆，迎接我们的是一望无际的莲叶，蝉声沉落，蛙声升起，一池的红莲如红焰"
    "As we stepped out of the Science and Technology Museum, we were greeted by endless lotus leaves. The sound of cicadas faded, and the croaking of frogs rose. A pond of red lotus flowers looked like a sea of red flames."

# game/转换后的Ren'Py脚本文件.rpy:1135
translate english flag2_bc286a43:

    # "回头望去，这间科技馆的外观竟像是一座古代的楼阁"
    "Looking back, the exterior of this science museum looks like an ancient pavilion."

# game/转换后的Ren'Py脚本文件.rpy:1136
translate english flag2_43e6d303:

    # "时间或许快到半夜12点了，天空却仍是傍晚的模样，当然我已经见怪不怪了"
    "It might almost be midnight, but the sky still looks like it's evening. Of course, I'm used to it by now."

# game/转换后的Ren'Py脚本文件.rpy:1138
translate english flag2_0b916817:

    # x "「科技馆建在江边呢……沿着江一直向下就要到大海了吧」"
    x "The Science Museum is built by the river... If you follow the river downstream, you'll reach the sea."

# game/转换后的Ren'Py脚本文件.rpy:1139
translate english flag2_b2651fea:

    # "天色渐渐昏沉下来，我们在江畔漫无目的地游荡着"
    "As the sky gradually darkened, we wandered aimlessly along the riverbank."

# game/转换后的Ren'Py脚本文件.rpy:1140
translate english flag2_0164c289:

    # "夏夜里，阵阵江风带来水汽拂过二人之间的空隙，晴朗的夜空里夏日大三角格外醒目"
    "On a summer night, gusts of river breeze carry moisture through the space between the two. The Summer Triangle is particularly striking in the clear night sky."

# game/转换后的Ren'Py脚本文件.rpy:1141
translate english flag2_44c03cf6:

    # "荷花丛中，藏着一只深绿色的小船，看上去是公园常见的样式，希实香轻巧地一跃而上"
    "A small dark green boat is hidden among the lotus flowers. It looks like a common type found in parks. Kimika nimbly jumps aboard."

# game/转换后的Ren'Py脚本文件.rpy:1142
translate english flag2_3ad5177a:

    # x "「你也上来吧」"
    x "You come up too."

# game/转换后的Ren'Py脚本文件.rpy:1144
translate english flag2_51dad528:

    # "我当然没有理由拒绝，便跟着跳了上去，整条小船在冲击下剧烈摇晃起来"
    "Of course, I had no reason to refuse, so I jumped on as well. The whole boat shook violently under the impact."

# game/转换后的Ren'Py脚本文件.rpy:1145
translate english flag2_ecaafcff:

    # x "「小心点，不要掉下去了」"
    x "Be careful not to fall."

# game/转换后的Ren'Py脚本文件.rpy:1146
translate english flag2_04a1cea0:

    # z "「这只船真是出人意料的轻呢」"
    z "This boat is surprisingly light."

# game/转换后的Ren'Py脚本文件.rpy:1147
translate english flag2_8f57d9a5:

    # x "「当然了……毕竟是劣质玻璃纤维黏合出的船体……」"
    x "Of course... After all, it's a hull made of low-quality fiberglass..."

# game/转换后的Ren'Py脚本文件.rpy:1148
translate english flag2_1c3e0c08:

    # z "「那希实香的体重肯定也很轻了，跳上来居然一点动静都没有呢」"
    z "Kimika must be very light too. She jumped on and didn't make a sound."

# game/转换后的Ren'Py脚本文件.rpy:1149
translate english flag2_35bf259f:

    # x "「再怎么说我也是女生嘛……」"
    x "After all, I'm a girl..."

# game/转换后的Ren'Py脚本文件.rpy:1150
translate english flag2_e459d42b:

    # "不知是微风还是水流的作用，小绿船越过莲叶，缓缓漂向江心"
    "Whether it was the breeze or the current, the little green boat passed over the lotus leaves and slowly drifted toward the center of the river."

# game/转换后的Ren'Py脚本文件.rpy:1151
translate english flag2_f1eaf0b4:

    # "水面上的荷花清润圆正，每片莲叶都迎风挺立着"
    "The lotus flowers on the water's surface are fresh and round, and each lotus leaf stands upright in the wind."

# game/转换后的Ren'Py脚本文件.rpy:1152
translate english flag2_b4a31805:

    # "今晚的夜空，此刻也如此美丽，星辉斑斓，洒在洁白的校服上，竟如同阳光一般明亮"
    "The night sky tonight is also so beautiful at this moment, with colorful starlight shining on the pure white school uniform, as bright as sunlight."

# game/转换后的Ren'Py脚本文件.rpy:1153
translate english flag2_d707c336:

    # z "「今天的星星……好亮啊……」"
    z "The stars tonight... are so bright..."

# game/转换后的Ren'Py脚本文件.rpy:1154
translate english flag2_ca439caf:

    # x "「明明天空除了星星以外都是黑漆漆的……但是船上看起来就像白天一样呢」"
    x "The sky is pitch-black except for the stars... but it looks like daytime on the ship."

# game/转换后的Ren'Py脚本文件.rpy:1156
translate english flag2_2e2ac932:

    # x "「全身都是光芒……与此同时却能看银河……就像太空中的宇航员……」"
    x "The whole body is glowing... and at the same time, you can see the Milky Way... like an astronaut in space..."

# game/转换后的Ren'Py脚本文件.rpy:1157
translate english flag2_3707c9ca:

    # z "「那我们现在是不是也在太空里呢」"
    z "So, are we in space now too?"

# game/转换后的Ren'Py脚本文件.rpy:1158
translate english flag2_a956dc19:

    # x "「是在很接近天空的地方哦」"
    x "It's a place very close to the sky."

# game/转换后的Ren'Py脚本文件.rpy:1159
translate english flag2_305e39a2:

    # "江水送着小船向前，先前的荷叶已经完全消失不见"
    "The river carried the small boat forward, and the previous lotus leaves had completely vanished"

# game/转换后的Ren'Py脚本文件.rpy:1161
translate english flag2_a6271e66:

    # "此时的银河也越发璀璨，巨大的星盘几乎占领着整个夜空"
    "At this moment, the Milky Way is becoming increasingly brilliant, and the huge star chart almost occupies the entire night sky"

# game/转换后的Ren'Py脚本文件.rpy:1162
translate english flag2_03b4c238:

    # z "「你说天空的上面，到底有什么呢，会是母亲说的上帝之类的东西嘛……」"
    z "What on earth is there up in the sky? Could it be something like God that mother mentioned..."

# game/转换后的Ren'Py脚本文件.rpy:1163
translate english flag2_de7a5a67:

    # x "「比天空还要高的地方……大概是臭氧和真空吧……再往上就是太空与群星的交织了」"
    x "A place higher than the sky... probably the ozone layer and the vacuum... and beyond that is the intertwining of space and the stars."

# game/转换后的Ren'Py脚本文件.rpy:1164
translate english flag2_616434da:

    # x "「话说间宫君小时候有没有想过要当宇航员呢……每个小朋友都会有这样的梦想吧」"
    x "By the way, did Mamiya-kun ever think about becoming an astronaut when he was a child... Every child has that dream, right?"

# game/转换后的Ren'Py脚本文件.rpy:1165
translate english flag2_d6190db1:

    # x "「你是否也会时不时想起遥远的过去和那些未曾实现的梦呢……」"
    x "Do you also sometimes recall the distant past and those unfulfilled dreams..."

# game/转换后的Ren'Py脚本文件.rpy:1167
translate english flag2_77ba5ee5:

    # z "「想不起来了唔……只记得母亲想让我当什么救世主来着……」"
    z "I can't remember... I just remember that my mother wanted me to be some kind of Savior..."

# game/转换后的Ren'Py脚本文件.rpy:1168
translate english flag2_43a6abd7:

    # x "「那救世主大人一定能到更远的天空去吧」"
    x "Then, Lord Savior must be able to reach even further into the sky."

# game/转换后的Ren'Py脚本文件.rpy:1169
translate english flag2_7b33a179:

    # x "「实际上人类的航天员，即使算上登上月球的那些，也始终没有离开希尔球呢」"
    x "In fact, human astronauts, even those who have landed on the moon, have never left the Hill Sphere."

# game/转换后的Ren'Py脚本文件.rpy:1170
translate english flag2_4d967f3d:

    # z "「希尔球又是什么呢」"
    z "What is a Hill Ball?"

# game/转换后的Ren'Py脚本文件.rpy:1171
translate english flag2_9f85ef04:

    # x "「是地球引力的实际控制区……换句话说就是地球自己的天空哦」"
    x "It's the actual control zone of Earth's gravity... In other words, it's Earth's own sky."

# game/转换后的Ren'Py脚本文件.rpy:1172
translate english flag2_23547d0a:

    # x "「所以人类……某种意义上或许从没有离开过地球的天空……」"
    x "So, in a sense, humans may have never left the skies of Earth..."

# game/转换后的Ren'Py脚本文件.rpy:1173
translate english flag2_ac3c2031:

    # z "「原来是这样么……可是头顶的星空，看上去离我们又是如此的接近啊」"
    z "So that's how it is... But the starry sky above us seems so close."

# game/转换后的Ren'Py脚本文件.rpy:1174
translate english flag2_72052dc7:

    # z "「没开智的时候还以为人类已经可以离开太阳系了呢」"
    z "Before I became sentient, I thought humans could already leave the solar system."

# game/转换后的Ren'Py脚本文件.rpy:1175
translate english flag2_e7e83355:

    # x "「但是星星间的距离远比我们想象的要更远」"
    x "But the distance between the stars is much greater than we imagine."

# game/转换后的Ren'Py脚本文件.rpy:1176
translate english flag2_14cf6911:

    # x "「猎户座计划，或许是人类最快的飞船，但是即使一直加速...也只能1%%的光速」"
    x "The Orion program might be the fastest spaceship for humanity, but even if it keeps accelerating... it can only travel at 1% of the speed of light."

# game/转换后的Ren'Py脚本文件.rpy:1177
translate english flag2_73b50d12:

    # x "「但是这个速度，飞出太阳系的引力范围可是要158年哦，到达最近的恒星要花420年……」"
    x "But at this speed, it would take 158 years to escape the gravitational pull of the solar system, and 420 years to reach the nearest star..."

# game/转换后的Ren'Py脚本文件.rpy:1178
translate english flag2_1248551f:

    # x "「更何况宇宙还在不停膨胀……星星彼此之间也在不停变远……」"
    x "Not to mention that the universe is constantly expanding... and the stars are constantly moving away from each other..."

# game/转换后的Ren'Py脚本文件.rpy:1180
translate english flag2_adc07477:

    # z "「那银河什么的……还是看看就好了……」"
    z "Well, the Milky Way and such... it's better to just take a look..."

# game/转换后的Ren'Py脚本文件.rpy:1181
translate english flag2_358131a3:

    # z "「人在孩童时期总会喜欢幻想那些宏大的未来吧……不过现在看来，宇宙也好星辰也罢都已不再关心……我真正在意的，或许只有眼下的生活吧」"
    z "When people are children, they always like to daydream about those grand futures... But now it seems that neither the universe nor the stars care anymore... Perhaps what I truly care about is only my present life."

# game/转换后的Ren'Py脚本文件.rpy:1182
translate english flag2_c17f32c2:

    # z "「年龄越大，世界看上去反而就越小了……」"
    z "The older one gets, the smaller the world seems to be..."

# game/转换后的Ren'Py脚本文件.rpy:1183
translate english flag2_ee316c06:

    # z "「在我们还小的时候，天花板在眼里会比现在更高...即使只是去几公里的地方...也感觉像出远门」"
    z "When we were young, the ceiling seemed higher in our eyes than it is now... Even if it was just a few kilometers away... it felt like going on a long trip."

# game/转换后的Ren'Py脚本文件.rpy:1184
translate english flag2_822a098b:

    # z "「当然充满幻想的时代已经一去不复返...我们的世界里，只剩下眼前的几个人，和日复一日的琐事...」"
    z "Of course, the era full of fantasies has gone forever... In our world, there are only the few people before us and the daily trivialities left..."

# game/转换后的Ren'Py脚本文件.rpy:1185
translate english flag2_9d727233:

    # x "「银河虽然很远，但是斑斓的星光还是属于我们的呢……」"
    x "Although the Milky Way is far away, the brilliant stars still belong to us..."

# game/转换后的Ren'Py脚本文件.rpy:1186
translate english flag2_79899bdb:

    # x "「」"
    x ""

# game/转换后的Ren'Py脚本文件.rpy:1187
translate english flag2_38adc7b5:

    # "小船不知道漂出了多远，风中海水的气息越发浓郁"
    "The small boat had drifted far away, and the smell of the sea in the wind grew stronger and stronger"

# game/转换后的Ren'Py脚本文件.rpy:1188
translate english flag2_46bfb2f0:

    # z "「我们会漂到哪里去啊」"
    z "Where will we drift to?"

# game/转换后的Ren'Py脚本文件.rpy:1189
translate english flag2_1a54d112:

    # x "「或许是一个海港，不过这些也不重要」"
    x "Perhaps it's a seaport, but that doesn't matter."

# game/转换后的Ren'Py脚本文件.rpy:1190
translate english flag2_37ef29dc:

    # x "「船都已经到这里了，卓司同学就没有什么想说的嘛」"
    x "The boat has already arrived here. Doesn't Takuji-kun have anything to say?"

# game/转换后的Ren'Py脚本文件.rpy:1191
translate english flag2_56c601d1:

    # z "「呃……」"
    z "Uh."

# game/转换后的Ren'Py脚本文件.rpy:1192
translate english flag2_85fdbf00:

    # "突如其来的话让我一愣，千言万语凝聚在舌尖却说不出一个字来"
    "The sudden words left me stunned. A thousand words were condensed on the tip of my tongue, but not a single one could be uttered"

# game/转换后的Ren'Py脚本文件.rpy:1193
translate english flag2_cd2d6b1d:

    # "或许是想让我说出一些告白的话之类的吗，但这类事情我似乎经常会搞砸"
    "Perhaps they want me to say some confessions or something like that, but I seem to often mess up such things"

# game/转换后的Ren'Py脚本文件.rpy:1194
translate english flag2_7bcfbd4b:

    # "轻轻望向水面，我只看见那颓废道令我厌恶的面孔"
    "Gazing gently at the water's surface, I see only that decadent face that repulses me."

# game/转换后的Ren'Py脚本文件.rpy:1195
translate english flag2_14bf350e:

    # "母亲从小希望我当救世主，可是我连反抗那些dqn都做不到……希实香也经常被欺负吧，可是我连保护这个对我满怀期待的女孩都做不到"
    "My mother always wanted me to be a Savior when I was young, but I couldn't even stand up to those dqns... Kimika was often bullied too, but I couldn't even protect this girl who had such high hopes for me."

# game/转换后的Ren'Py脚本文件.rpy:1196
translate english flag2_46951ae5:

    # "欺负希实香的那个女生，好像正好是城山的女友吧，某种意义上来说我们也算是门当户对了？"
    "The girl who bullied Kimika seems to be Shiroyama's girlfriend. In a way, are we a good match?"

# game/转换后的Ren'Py脚本文件.rpy:1197
translate english flag2_4283614b:

    # x "「卓司真没劲……」"
    x "Takuji is really boring..."

# game/转换后的Ren'Py脚本文件.rpy:1198
translate english flag2_79beab32:

    # "她的声音，在我为这漫无边际的幻想而感到羞耻前打断了我。如果没有她的阻止，现在或许已经幻想到结婚以后的生活了"
    "Her voice interrupted me before I felt ashamed of this boundless fantasy. If she hadn't stopped me, I might have already been fantasizing about life after marriage."

# game/转换后的Ren'Py脚本文件.rpy:1199
translate english flag2_dc92b8b6:

    # z "「抱歉……」"
    z "Oops"

# game/转换后的Ren'Py脚本文件.rpy:1200
translate english flag2_36119108:

    # z "「最近没有人再欺负你吧」"
    z "No one's been bullying you lately, right?"

# game/转换后的Ren'Py脚本文件.rpy:1202
translate english flag2_32a06a1b:

    # x "「怎么了？」"
    x "What's the matter?"

# game/转换后的Ren'Py脚本文件.rpy:1203
translate english flag2_90bd78d4:

    # x "「想了这么久就只是要问我这个吗」"
    x "You've been thinking about it for so long, and all you want to ask me is this?"

# game/转换后的Ren'Py脚本文件.rpy:1204
translate english flag2_bfef80c8:

    # z "「因为想到什么就说什么了……印象里希实香也是像我一样经常被欺负的人吧」"
    z "Because I just say whatever comes to mind... I have the impression that Kimika is also someone who gets bullied often, like me."

# game/转换后的Ren'Py脚本文件.rpy:1205
translate english flag2_02f7bc24:

    # "看着她手臂上的淤青，我突然意识到自己问了个多么蠢的问题"
    "Looking at the bruises on her arm, I suddenly realized how stupid my question was."

# game/转换后的Ren'Py脚本文件.rpy:1207
translate english flag2_19b4c317:

    # x "「为什么……要在这个时候说这些……」"
    x "Why... are you saying this... at this time?"

# game/转换后的Ren'Py脚本文件.rpy:1208
translate english flag2_87cd88b6:

    # "一丝不易察觉的悲伤悄悄浸透了她的脸庞"
    "A barely perceptible sadness quietly crept over her face."

# game/转换后的Ren'Py脚本文件.rpy:1209
translate english flag2_584eccae:

    # x "「有的时候……真希望这些人……全部都死掉……」"
    x "Sometimes... I really wish these people... would all die..."

# game/转换后的Ren'Py脚本文件.rpy:1210
translate english flag2_318c3ded:

    # x "「惠和聪子……自然是最该死的……还有西村和城山也是一样……那些事不关己的同学……也一起去死吧……」"
    x "Megumi and Satoko... they're naturally the most deserving of death... and Nishimura and Shiroyama are the same... those classmates who don't care... they should all die together..."

# game/转换后的Ren'Py脚本文件.rpy:1211
translate english flag2_9c3aa316:

    # z "「对不起……」"
    z "Sorry"

# game/转换后的Ren'Py脚本文件.rpy:1212
translate english flag2_0eac1a65:

    # "意识到好像说错了什么，我赶忙向希实香道歉，然而她似乎并不生气，只是保持着略带怪异的微笑"
    "Realizing that I might have said something wrong, I quickly apologized to Kimika. However, she didn't seem angry and just kept a slightly strange smile on her face."

# game/转换后的Ren'Py脚本文件.rpy:1213
translate english flag2_105701ff:

    # x "「我也想过很多遍用炸药把他们炸上天呢……可是终究只是在意淫罢了」"
    x "I've also thought many times about blowing them up with explosives... but in the end, it's just a fantasy."

# game/转换后的Ren'Py脚本文件.rpy:1214
translate english flag2_a39a7047:

    # x "「不知道间宫君有没有听说过二甲酮呢」"
    x "I wonder if Mamiya-kun has heard of dimethone."

# game/转换后的Ren'Py脚本文件.rpy:1215
translate english flag2_2c581eac:

    # z "「这个倒是没有……」"
    z "That's not the case..."

# game/转换后的Ren'Py脚本文件.rpy:1216
translate english flag2_f183d456:

    # x "「就是一种女生经常会用的卸甲水啦」"
    x "It's just a kind of nail polish remover that girls often use."

# game/转换后的Ren'Py脚本文件.rpy:1217
translate english flag2_c09d938a:

    # x "「只要把卸甲水和漂白剂混合在一起，再加入酸性的洁厕灵……二甲酮就会和漂白剂发生亲核加成，形成一种会爆炸的过氧化物……」"
    x "Just mix nail polish remover with bleach and add acidic toilet cleaner... dimethyl ketone will undergo nucleophilic addition with bleach, forming an explosive peroxide..."

# game/转换后的Ren'Py脚本文件.rpy:1218
translate english flag2_996aff87:

    # x "「呯！如果有电弧或者火花的话，过氧键就会断裂，把化学能释放出来」"
    x "Bang! If there's an arc or a spark, the peroxide bond will break and release chemical energy."

# game/转换后的Ren'Py脚本文件.rpy:1219
translate english flag2_5e0f825e:

    # x "「只要500克，也就是一个矿泉水瓶那么大的装置，爆炸威力已经赶上小一点的炮弹了吧……如果在教室之类的地方引爆，冲击波还会被墙面来回反射……足够把房间里所有人的内脏震碎了」"
    x "Just 500 grams, which is about the size of a mineral water bottle, the explosive power is already comparable to that of a smaller shell... If it were detonated in a classroom or something like that, the shock wave would be reflected back and forth by the walls... It would be enough to shatter the internal organs of everyone in the room."

# game/转换后的Ren'Py脚本文件.rpy:1220
translate english flag2_9bf8d95b:

    # x "「但是如果现在这样做的话……卓司同学肯定也会被炸死吧……」"
    x "But if we do this now... Takuji will surely be blown up as well..."

# game/转换后的Ren'Py脚本文件.rpy:1221
translate english flag2_3ba095cf:

    # "说出这些话时，她的脸上没有一丝波澜，好像是犯人在交待作案的经过，所有的流程，都蓄谋已久，只等在某个时间实施，让我不禁感到后怕"
    "When she said these words, there was not a hint of emotion on her face, as if she were a criminal confessing to the details of a crime. Every step had been premeditated for a long time, waiting only for the right moment to be carried out. It made me feel a lingering sense of fear."

# game/转换后的Ren'Py脚本文件.rpy:1222
translate english flag2_ec59c836:

    # z "「会不会有点……太恐怖了呢……这么大的威力，很多无关的人也会受伤吧」"
    z "Isn't it a bit... too terrifying... With such great power, many irrelevant people might also get hurt, right?"

# game/转换后的Ren'Py脚本文件.rpy:1223
translate english flag2_03fe4049:

    # x "「不要这么紧张嘛，现实里我可是个连踩死一只虫子都会内疚很久的人哦，肯定是不会做出伤害卓司同学的事来呢」"
    x "Don't be so nervous. In reality, I'm the kind of person who feels guilty for a long time even after stepping on a bug. I definitely wouldn't do anything to hurt Takuji."

# game/转换后的Ren'Py脚本文件.rpy:1224
translate english flag2_77f49437:

    # x "「可是……有些事……没有办法原谅……」"
    x "But... there are some things... that cannot be forgiven..."

# game/转换后的Ren'Py脚本文件.rpy:1225
translate english flag2_21cdd7dd:

    # x "「卓司大人，我是你很重要的朋友吗」"
    x "Mr. Takuji, am I an important friend of yours?"

# game/转换后的Ren'Py脚本文件.rpy:1227
translate english flag2_31daf685:

    # z "「嗯……是的……是对我最最重要的人」"
    z "Well... yes... she's the most important person to me."

# game/转换后的Ren'Py脚本文件.rpy:1228
translate english flag2_8d0193bc:

    # z "「躲在家里，每天只能听见母亲的训斥……到了学校又不得不忍受霸凌和冷眼……」"
    z "At home, I only hear my mother's scolding every day... And at school, I have to endure bullying and cold stares..."

# game/转换后的Ren'Py脚本文件.rpy:1229
translate english flag2_263fa8b9:

    # z "「从来没有感受过他人的关爱，我的人生在这之前就像是终年生活在黑暗里的臭虫」"
    z "I've never felt the love of others. Before this, my life was like that of a bedbug living in darkness all year round."

# game/转换后的Ren'Py脚本文件.rpy:1230
translate english flag2_2feb1d5a:

    # z "「或许也只有你会愿意带我来这里吧，带我一起参观机器和电，在水面幻想未来、宇宙、还有天空」"
    z "Perhaps you're the only one who would be willing to bring me here, to show me the machines and electricity, to imagine the future, the universe, and the sky on the water."

# game/转换后的Ren'Py脚本文件.rpy:1231
translate english flag2_92a7e377:

    # z "「今天就是我生命最幸福的一天吧」"
    z "Today is the happiest day of my life."

# game/转换后的Ren'Py脚本文件.rpy:1232
translate english flag2_78754969:

    # z "「不管受了多少委屈……只要想到还有人关心着我……就感觉好上很多了呢」"
    z "No matter how much I've been wronged... just thinking that there are still people who care about me... makes me feel much better."

# game/转换后的Ren'Py脚本文件.rpy:1233
translate english flag2_7b0bfd5c:

    # x "「我也会是别人心里重要的人吗……」"
    x "Will I also be an important person in someone else's heart...?"

# game/转换后的Ren'Py脚本文件.rpy:1235
translate english flag2_b8d96808:

    # x "「如果有一天，你的朋友因为你而被欺负呢？或者有一天被迫加入霸凌她的行列中去……」"
    x "What if one day your friend is bullied because of you? Or one day you're forced to join in bullying her..."

# game/转换后的Ren'Py脚本文件.rpy:1236
translate english flag2_9deb7f0b:

    # z "「如果做出这样的事情……恐怕我会后悔一生吧……」"
    z "If I do something like that... I'm afraid I'll regret it for the rest of my life..."

# game/转换后的Ren'Py脚本文件.rpy:1237
translate english flag2_6500d80d:

    # x "「后悔……」"
    x "Regret"

# game/转换后的Ren'Py脚本文件.rpy:1238
translate english flag2_e4308dc0:

    # x "「早上你醒来，简讯里全部都是她被凌辱的照片……不久之后得知了她的死讯，你又会是什么样的感受……」"
    x "You wake up in the morning, and your phone is full of messages with photos of her being abused... Not long after, you learn of her death. How would you feel...?"

# game/转换后的Ren'Py脚本文件.rpy:1239
translate english flag2_8aa289f4:

    # z "「比死了还难受……」"
    z "It's worse than being dead..."

# game/转换后的Ren'Py脚本文件.rpy:1240
translate english flag2_f510b939:

    # z "「大概会有比你更疯的计划吧……」"
    z "There must be a crazier plan than yours..."

# game/转换后的Ren'Py脚本文件.rpy:1241
translate english flag2_098db1cf:

    # x "「……」"
    x "..."

# game/转换后的Ren'Py脚本文件.rpy:1242
translate english flag2_7e077dcf:

    # x "「嗯嗯……救世主大人的计划比我更完美哦」"
    x "Uh-huh... Savior's plan is even more perfect than mine."

# game/转换后的Ren'Py脚本文件.rpy:1243
translate english flag2_b007a67e:

    # "好奇怪的称呼，在沉默里，听见她在念着某个同学的名字，却无论如何都想不起来"
    "What a strange name. In the silence, I heard her reciting the name of a classmate, but I couldn't remember it no matter how hard I tried."

# game/转换后的Ren'Py脚本文件.rpy:1244
translate english flag2_2690fa2f:

    # x "「不说这些了……休息一下吧」"
    x "Let's not talk about this anymore... Take a break."

# game/转换后的Ren'Py脚本文件.rpy:1245
translate english flag2_8d5fbc64:

    # "回过神来时，我们已身处一望无际的水面上，或许是入海口，或许已经漂在了海上"
    "When we came to our senses, we were already on an endless expanse of water. Perhaps we were at an estuary, or maybe we were already drifting at sea."

# game/转换后的Ren'Py脚本文件.rpy:1246
translate english flag2_cb83bab1:

    # "或许是时间流逝的缘故，银河在此刻已经不再清晰，只剩深蓝的水面倒映着弯曲的月影"
    "Perhaps due to the passage of time, the Milky Way is no longer clearly visible at this moment, leaving only the deep blue water surface reflecting the curved shadow of the moon."

# game/转换后的Ren'Py脚本文件.rpy:1247
translate english flag2_33db6ba7:

    # z "「海面和天空……为什么都是一样的颜色呢」"
    z "Why are the sea surface and the sky both of the same color?"

# game/转换后的Ren'Py脚本文件.rpy:1248
translate english flag2_eb20e622:

    # x "「忘记了……不过在水下的生物眼里，水面也许就是它们的天空……」"
    x "I forgot... But in the eyes of underwater creatures, the water surface might be their sky..."

# game/转换后的Ren'Py脚本文件.rpy:1249
translate english flag2_7c2a5a89:

    # x "「间宫君还记得小学时候的第一节课是什么嘛」"
    x "Mamiya-kun, do you still remember what your first class was in primary school?"

# game/转换后的Ren'Py脚本文件.rpy:1250
translate english flag2_9c1e9482:

    # z "「第一节课……唔……好久远的事情啊……」"
    z "The first lesson... Hmm... That was a long time ago..."

# game/转换后的Ren'Py脚本文件.rpy:1251
translate english flag2_738400e1:

    # x "「是弯弯的月亮像小船哦，我们的小船，在海底动物的眼里，会不会被当成月亮呢」"
    x "The crescent moon looks like a little boat. Do you think our little boat would be mistaken for the moon in the eyes of the sea creatures?"

# game/转换后的Ren'Py脚本文件.rpy:1252
translate english flag2_2a510f9c:

    # z "「那我们就是绿色月亮上的人了……」"
    z "Then we're the people on the Green Moon..."

# game/转换后的Ren'Py脚本文件.rpy:1253
translate english flag2_091f3d1b:

    # "话语在此刻戛然而止，只有沉默回荡在空气中"
    "Words abruptly ceased at this moment, and only silence lingered in the air."

# game/转换后的Ren'Py脚本文件.rpy:1254
translate english flag2_fee73c70:

    # "和希实香的聊天，总是漫无目的，甚至可以说是毫无逻辑"
    "Conversations with Kimika are always aimless, and even illogical."

# game/转换后的Ren'Py脚本文件.rpy:1255
translate english flag2_022f207b:

    # "或许是因为我们都不擅长表达，说话时总像做梦一样，感觉什么都没有说，彼此却总是感觉莫名的喜悦"
    "Perhaps it's because neither of us is good at expressing ourselves. When we talk, it's always like a dream. It feels like we haven't said anything, yet we always feel an inexplicable joy with each other."

# game/转换后的Ren'Py脚本文件.rpy:1256
translate english flag2_c98cc1b4:

    # "逻辑的边界或许是语言，但爱的边界不是。即使什么也不做，即使只是看着彼此，只是沉默不语，也掩盖不了此刻的幸福"
    "The boundaries of logic may be language, but the boundaries of love are not. Even if we do nothing, even if we just look at each other and remain silent, we cannot hide the happiness of this moment."

# game/转换后的Ren'Py脚本文件.rpy:1257
translate english flag2_660678b1:

    # "沉默间，耳边突然传来微弱的说话声"
    "In the silence, a faint voice suddenly reached my ears."

# game/转换后的Ren'Py脚本文件.rpy:1259
translate english flag2_3f6767a0:

    # x "「船儿弯弯入海港，回头望望……沧海茫茫……」"
    x "The boat curves into the harbor, looking back... the sea is vast..."

# game/转换后的Ren'Py脚本文件.rpy:1260
translate english flag2_41f50b88:

    # x "「说的大概就是现在这样吧」"
    x "That's probably what it's like now."

# game/转换后的Ren'Py脚本文件.rpy:1261
translate english flag2_3ba3ccc8:

    # z "「好厉害……希实香可真是大文豪」"
    z "Wow... Kimika is truly a great writer."

# game/转换后的Ren'Py脚本文件.rpy:1262
translate english flag2_8fe70219:

    # x "「只是一首流行歌的歌词而已……」"
    x "It's just the lyrics of a pop song..."

# game/转换后的Ren'Py脚本文件.rpy:1263
translate english flag2_97a111c7:

    # z "「那也很厉害了，不像我背了那么多名句，写文章和聊天的时候一句也想不起来……」"
    z "That's pretty impressive. Unlike me, I memorized so many famous quotes, but I can't recall a single one when writing an article or chatting..."

# game/转换后的Ren'Py脚本文件.rpy:1264
translate english flag2_f6e3a6b5:

    # z "「不过我们这样真的能漂到某个海港里吗，如果被海风吹到远方该怎么回来呢」"
    z "But can we really drift to a harbor like this? What if the sea breeze blows us far away, how will we get back?"

# game/转换后的Ren'Py脚本文件.rpy:1265
translate english flag2_0788205c:

    # x "「等到天亮的时候……你自然可以回家……」"
    x "When dawn comes... you can naturally go home..."

# game/转换后的Ren'Py脚本文件.rpy:1266
translate english flag2_53eee30c:

    # z "「天亮的时候……」"
    z "When it's light out."

# game/转换后的Ren'Py脚本文件.rpy:1267
translate english flag2_84ea39bc:

    # z "「现在几点了，希实香」"
    z "What time is it, Kimika?"

# game/转换后的Ren'Py脚本文件.rpy:1268
translate english flag2_73479321:

    # x "「你大概已经四点了吧……太阳要出来了……」"
    x "It's probably already four o'clock... The sun is about to rise..."

# game/转换后的Ren'Py脚本文件.rpy:1269
translate english flag2_bb463994:

    # x "「太阳出来的时候……我就要离开了」"
    x "When the sun comes up... I'll be leaving."

# game/转换后的Ren'Py脚本文件.rpy:1270
translate english flag2_78b7e076:

    # "海平面上虽然看不见天阳，此时的天空，却已微亮，呈现出和电脑死机时一样的暗蓝色"
    "Although the sun was not visible above the sea level, the sky was already faintly lit, showing the same dark blue as when a computer crashes."

# game/转换后的Ren'Py脚本文件.rpy:1271
translate english flag2_12a7884e:

    # z "「不和我一起回去的话……你又要去哪里呢」"
    z "If you don't come back with me... where else would you go?"

# game/转换后的Ren'Py脚本文件.rpy:1272
translate english flag2_5b8e17dc:

    # x "「去和星星在一起的地方……按照救世主大人您的计划哦」"
    x "Go to the place where you are with the stars... Follow your plan, Savior."

# game/转换后的Ren'Py脚本文件.rpy:1273
translate english flag2_5a4dd969:

    # x "「去比希尔球更高的地方……比猎户座计划飞得更远的地方……」"
    x "To a place higher than Hill Ball... to a place farther than the Orion program..."

# game/转换后的Ren'Py脚本文件.rpy:1275
translate english flag2_6645edb9:

    # z "「有多远呢」"
    z "How far is it?"

# game/转换后的Ren'Py脚本文件.rpy:1276
translate english flag2_4ea4a1dd:

    # x "「是一个比本超星系团更高的地方吧」"
    x "Is it a place higher than this supercluster?"

# game/转换后的Ren'Py脚本文件.rpy:1277
translate english flag2_08d684f4:

    # "我已经习惯了她无厘头的回答，便索性顺着问题问了下去"
    "I was used to her nonsensical answers, so I just continued asking questions."

# game/转换后的Ren'Py脚本文件.rpy:1278
translate english flag2_e70e8c18:

    # z "「那以后……我们还会见面吗」"
    z "Then... will we still meet in the future?"

# game/转换后的Ren'Py脚本文件.rpy:1279
translate english flag2_23da382b:

    # x "「或许吧……或许是明天，也可能是后天……或者是在可观测宇宙的庞加莱重现时间里的某一天」"
    x "Perhaps... perhaps it's tomorrow, or maybe it's the day after tomorrow... or some day in the Poincare reenactment time of the observable universe."

# game/转换后的Ren'Py脚本文件.rpy:1280
translate english flag2_7048277e:

    # x "「太阳快出来了，我的时间要到新的一天了……还有什么想说的吗」"
    x "The sun is about to rise, and my time is coming to an end for the day... Is there anything else you'd like to say?"

# game/转换后的Ren'Py脚本文件.rpy:1281
translate english flag2_afd10170:

    # "不知道是不是太累导致的错觉，希实香的身影似乎变得透明了，眼眶也挂上了一丝不易察觉泪痕"
    "Perhaps it was an illusion caused by exhaustion, but Kimika's figure seemed to become transparent, and there was a faint trace of tears in the corners of her eyes."

# game/转换后的Ren'Py脚本文件.rpy:1282
translate english flag2_a08d5a09:

    # "刚刚的语气，像是在哀悼什么，让我心头闪过一丝不好的预感"
    "The tone just now seemed to be mourning something, which made a bad premonition flash through my mind"

# game/转换后的Ren'Py脚本文件.rpy:1284
translate english flag2_277f0d16:

    # "就像黑暗中的飞蛾扑向火光，本能让我紧紧抱住了她"
    "Just like a moth in the darkness lunging towards the firelight, instinct made me hold her tightly"

# game/转换后的Ren'Py脚本文件.rpy:1285
translate english flag2_a0bcff5e:

    # "把头埋在白色校服里，淡淡的熏衣草味扑面而来"
    "Burying his head in the white school uniform, a faint scent of lavender wafted towards him"

# game/转换后的Ren'Py脚本文件.rpy:1286
translate english flag2_3eed17ca:

    # x "「好闻吧，是我的洗衣液的味道哦」"
    x "It smells good, doesn't it? It's the scent of my laundry detergent."

# game/转换后的Ren'Py脚本文件.rpy:1287
translate english flag2_385eb97d:

    # z "「请不要……离开我……」"
    z "Please don't... leave me..."

# game/转换后的Ren'Py脚本文件.rpy:1288
translate english flag2_b981b8ef:

    # z "「我深深爱着的……最最重要的人……」"
    z "The most important person... whom I love deeply..."

# game/转换后的Ren'Py脚本文件.rpy:1289
translate english flag2_f3c8298d:

    # x "「但是救世主大人您的计划就是这样……而且……我也是有罪的人啊……如果放弃回归天空的计划……我是无论如何都不会原谅自己的……」"
    x "But, Lord Savior, this is your plan... And... I am also a sinner... If I abandon the plan to Return to the Sky... I will never forgive myself..."

# game/转换后的Ren'Py脚本文件.rpy:1290
translate english flag2_8974d91a:

    # x "「间宫君也是我最最在乎的男生哦，所以请一定要幸福地活下去……」"
    x "Mamiya-kun is also the boy I care about the most, so please be sure to live happily..."

# game/转换后的Ren'Py脚本文件.rpy:1291
translate english flag2_6637f20e:

    # "救世主是什么呢，在这科学世纪里，真的会有天父或者怪力乱神吗？"
    "What is Savior? In this Scientific Century, will there really be the Heavenly Father or gods and monsters?"

# game/转换后的Ren'Py脚本文件.rpy:1292
translate english flag2_40d0b1c9:

    # "天空也好，怪力乱神也罢……这些都去死吧，我只想抱住眼前的女孩，在这科学世纪里，牵着彼此的手，就这样过着平凡的生活"
    "Whether it's the sky or gods and monsters... Let all of these die. I just want to hold the girl in front of me, in this Scientific Century, hold each other's hands, and just live an ordinary life like this"

# game/转换后的Ren'Py脚本文件.rpy:1293
translate english flag2_1f45550e:

    # "dqn的拳头又怎么样呢……就算死掉，我也真心希望唯一在乎我的女孩能替我好好地活着……"
    "So what about dqn's fist... Even if I die, I sincerely hope that the only girl who cares about me can live well for me..."

# game/转换后的Ren'Py脚本文件.rpy:1295
translate english flag2_0b9ce5e8:

    # x "「太阳要出来了……」"
    x "The sun is about to rise..."

# game/转换后的Ren'Py脚本文件.rpy:1296
translate english flag2_bae3877a:

    # x "「偌大的海面只有我们两个人，什么也没有，就像荒岛上一样……」"
    x "There are only the two of us on this vast sea, with nothing else, just like on a deserted island..."

# game/转换后的Ren'Py脚本文件.rpy:1297
translate english flag2_ad44e889:

    # x "「再见了，我深深爱着的男孩」"
    x "Goodbye, the boy I love so deeply."

# game/转换后的Ren'Py脚本文件.rpy:1298
translate english flag2_4f53f0dc:

    # z "「再见的意思，就是还会见面吗」"
    z "Does 'goodbye' mean we'll see each other again?"

# game/转换后的Ren'Py脚本文件.rpy:1299
translate english flag2_25ec92b3:

    # "希实香只留下了一个微笑，嘴里好像在念叨着什么，或许是像战国的大名死前吟诵的故乡黄花之类的东西。"
    "Kimika only left behind a smile, as if she were muttering something, perhaps something like the yellow flowers of her hometown that a Warring States daimyo would recite before dying."

# game/转换后的Ren'Py脚本文件.rpy:1300
translate english flag2_c163e8e3:

    # "海的边缘已经略微能看见金色的晨光，留给我们的时间不多了"
    "The golden morning light is already faintly visible at the edge of the sea. We don't have much time left."

# game/转换后的Ren'Py脚本文件.rpy:1302
translate english flag2_f31a0af5:

    # x "「睡梦成真……转身浪影汹涌没红尘」"
    x "Dreams come true... Turn around, and the waves surge, sweeping away the mundane world."

# game/转换后的Ren'Py脚本文件.rpy:1303
translate english flag2_29271b83:

    # x "「残留水纹，空留遗恨」"
    x "Lingering ripples, lingering regrets."

# game/转换后的Ren'Py脚本文件.rpy:1304
translate english flag2_69fc6d90:

    # x "「愿只愿他生……昨日的身影能相随……」"
    x "I only wish he were alive... so that yesterday's shadow could be with me..."

# game/转换后的Ren'Py脚本文件.rpy:1305
translate english flag2_dab2fefc:

    # x "「永生永世不离分……」"
    x "Forever and ever, never to be separated..."

# game/转换后的Ren'Py脚本文件.rpy:1306
translate english flag2_e1463eff:

    # "女孩笼罩在金色的晨光里，身体渐渐变得透明"
    "The girl is enveloped in the golden morning light, and her body gradually becomes transparent."

# game/转换后的Ren'Py脚本文件.rpy:1308
translate english flag2_0f82f9b7:

    # "再见，就是再次见面的意思吧……再次见面又会是什么时候呢？或许是下午，或许是明天。"
    "\"Goodbye\" means we'll meet again... But when will that be? Maybe this afternoon, maybe tomorrow."

# game/转换后的Ren'Py脚本文件.rpy:1311
translate english flag2_ef4870f2:

    # c "「什么都没有发生哦，希实香同学只是自己跳下去了」"
    c "Nothing happened. Kimika just jumped down on her own."

# game/转换后的Ren'Py脚本文件.rpy:1312
translate english flag2_978d8b11:

    # z "「什么意思？」"
    z "What does that mean?"

# game/转换后的Ren'Py脚本文件.rpy:1314
translate english flag2_ef4870f2_1:

    # c "「什么都没有发生哦，希实香同学只是自己跳下去了」"
    c "Nothing happened. Kimika just jumped down on her own."

# game/转换后的Ren'Py脚本文件.rpy:1315
translate english flag2_152bbab4:

    # "无名业火从心中生起，再也无法遏制，只想把她从船上扔下去"
    "The nameless flame of karma flared up in my heart and could no longer be contained. I just wanted to throw her off the boat"

# game/转换后的Ren'Py脚本文件.rpy:1317
translate english flag2_daa1b9b2:

    # c "「如果打我的话，就来没有时间了」"
    c "If you hit me, there won't be any time left."

# game/转换后的Ren'Py脚本文件.rpy:1318
translate english flag2_b6c61c5d:

    # z "「你……」"
    z "you."

# game/转换后的Ren'Py脚本文件.rpy:1319
translate english flag2_cf37d274:

    # "天空与海面旋转了起来，身体的痛楚从未比此刻更明显"
    "The sky and the sea began to spin, and the pain in my body had never been more obvious than at this moment"

# game/转换后的Ren'Py脚本文件.rpy:1321
translate english flag2_a3409aae:

    # "眼前的一切扭曲成一个个圆形，视线就此模糊，只剩下蓝色"
    "Everything before my eyes distorted into circles, and my vision blurred, leaving only blue"

# game/转换后的Ren'Py脚本文件.rpy:1322
translate english flag2_e0562636:

    # "千万张面孔、名字、事件与记忆一齐涌入大脑，在神经的树突与轴突之间跳跃着"
    "Millions of faces, names, events and memories flood into the brain all at once, leaping between the dendrites and axons of the nerves"

# game/转换后的Ren'Py脚本文件.rpy:1323
translate english flag2_35dcb7cf:

    # z "「这里是……秘密基地」"
    z "This is... a secret base."

# game/转换后的Ren'Py脚本文件.rpy:1324
translate english flag2_9ac5613d:

    # "环顾四周，只有西村的尸体，与满地狼藉"
    "Looking around, there was only Nishimura's body and a mess all over the ground"

# game/转换后的Ren'Py脚本文件.rpy:1325
translate english flag2_d2c76f2a:

    # "霸凌与死亡，毒品与信徒，背叛与复仇，所有的记忆再度回归那被致幻剂侵蚀的大脑"
    "Bullying and death, drugs and believers, betrayal and revenge - all the memories once again return to that brain eroded by hallucinogens"

# game/转换后的Ren'Py脚本文件.rpy:1326
translate english flag2_29efcbeb:

    # "我呆滞地坐在原地，就像是一个刚刚得知自己犯下弥天大错的小孩"
    "I sat there stunned, like a child who had just learned that he had made a huge mistake."

# game/转换后的Ren'Py脚本文件.rpy:1328
translate english flag2_1622aabb:

    # c "「在你半睡半醒的那段时间里，是那个女孩轻轻坐在身旁，用语言和药品为你编织着幸福的梦」"
    c "During the time when you were half asleep and half awake, it was that girl who sat gently beside you, weaving a happy dream for you with words and medicine."

# game/转换后的Ren'Py脚本文件.rpy:1329
translate english flag2_641b3591:

    # c "「现在已经11点58了哦」"
    c "It's already 11:58 now."

# game/转换后的Ren'Py脚本文件.rpy:1330
translate english flag2_721d52e7:

    # c "「再过两分钟会发生什么……你也是知道的吧」"
    c "You know what will happen in two minutes..."

# game/转换后的Ren'Py脚本文件.rpy:1340
translate english flag3_caec2a63:

    # "来不及想更多，我不顾一切地向顶楼跑去"
    "Without time to think further, I ran desperately to the top floor."

# game/转换后的Ren'Py脚本文件.rpy:1341
translate english flag3_5a9c9b28:

    # "回归天空的计划，此刻看来是多么可笑"
    "The plan to Return to the Sky seems so ridiculous right now."

# game/转换后的Ren'Py脚本文件.rpy:1342
translate english flag3_1f229beb:

    # "在科学世纪里，又怎么会有怪力乱神的故事呢"
    "How can there be stories of gods and monsters in the Scientific Century?"

# game/转换后的Ren'Py脚本文件.rpy:1343
translate english flag3_316952aa:

    # "沉默的同学，视而不见的老师，以及dqn们都去死吧，死了也无所谓，我只希望能让希实香好好地活下去"
    "The silent classmates, the blind teachers, and the delinquents can all go to hell. It doesn't matter if they die. I just hope Kimika can live well."

# game/转换后的Ren'Py脚本文件.rpy:1344
translate english flag3_b3242699:

    # "重物坠落的声音在耳边响起，我知道必须加快脚步了"
    "The sound of something heavy falling rang in my ears, and I knew I had to pick up the pace."

# game/转换后的Ren'Py脚本文件.rpy:1346
translate english flag3_4e47cc70:

    # "此刻的楼顶，一片狼藉"
    "The rooftop is in disarray at the moment."

# game/转换后的Ren'Py脚本文件.rpy:1348
translate english flag3_4607bcdc:

    # x "「救世主大人……还是醒来了吗」"
    x "Savior... Have you still woken up?"

# game/转换后的Ren'Py脚本文件.rpy:1349
translate english flag3_314a6168:

    # x "「我明明……准备了两倍的剂量啊……应该再过9个小时才会醒来的吧」"
    x "I clearly... prepared twice the dose... It should be another nine hours before I wake up, right?"

# game/转换后的Ren'Py脚本文件.rpy:1350
translate english flag3_423ec25b:

    # x "「不过……就到此结束了吧……我己经不配再活下去了」"
    x "But... Let's call it a day... I don't deserve to live any longer."

# game/转换后的Ren'Py脚本文件.rpy:1351
translate english flag3_91af9dbe:

    # x "「最后的死就由我来承受……救世主大人还是留在这里活着赎罪吧……」"
    x "I'll bear the final death... Savior, please stay here and live to atone for your sins..."

# game/转换后的Ren'Py脚本文件.rpy:1352
translate english flag3_5d5c9fd2:

    # z "「我还有最后一个问题」"
    z "I have one last question"

# game/转换后的Ren'Py脚本文件.rpy:1353
translate english flag3_059641eb:

    # "深蓝的夜空下，我悄悄向她走近"
    "Under the deep blue night sky, I quietly approached her."

# game/转换后的Ren'Py脚本文件.rpy:1354
translate english flag3_bd270550:

    # "「为什么如果只是希望我活着的话，只要用药物把我放倒就好……为什么又要为我虚构一场美梦」"
    "If you just wanted me to live, why didn't you just knock me out with drugs? Why did you have to create a beautiful dream for me?"

# game/转换后的Ren'Py脚本文件.rpy:1355
translate english flag3_7c6c437b:

    # x "「因为间宫君……是个很可怜的男孩啊……」"
    x "Because Mamiya-kun... is a very pitiful boy..."

# game/转换后的Ren'Py脚本文件.rpy:1356
translate english flag3_2890aa63:

    # x "「从相爱再到分别的时间太过匆忙……但是我还是希望能留下些美好的回忆」"
    x "The time from falling in love to parting ways was too rushed... but I still hope to leave behind some fond memories."

# game/转换后的Ren'Py脚本文件.rpy:1357
translate english flag3_ab568c51:

    # x "「请不要忘记我……」"
    x "Please don't forget me..."

# game/转换后的Ren'Py脚本文件.rpy:1358
translate english flag3_bd088d88:

    # x "「假如真有怪力乱神，我希望来世能牵着你的手，在凌晨的花田里散步……」"
    x "If there really are gods and monsters, I hope that in the next life, I can hold your hand and stroll through the flower fields at dawn..."

# game/转换后的Ren'Py脚本文件.rpy:1359
translate english flag3_33b7b53c:

    # "小小的身躯缓缓向层顶的边缘靠近，仿佛下一刻就要落下"
    "The tiny body slowly approaches the edge of the top floor, as if it's about to fall at any moment."

# game/转换后的Ren'Py脚本文件.rpy:1360
translate english flag3_9aadd6f5:

    # "我紧紧拥抱了上去，用口袋里最后的致幻剂捂住了她的嘴"
    "I hugged her tightly and covered her mouth with the last of the hallucinogen in my pocket."

# game/转换后的Ren'Py脚本文件.rpy:1362
translate english flag3_6bf08bc1:

    # x "「唔……」"
    x "Wú"

# game/转换后的Ren'Py脚本文件.rpy:1363
translate english flag3_a29529d4:

    # z "「麦角酸二乙胺……没有致死案例的致幻剂……经过粘膜就能吸收……你教我的东西可是全都记住了……」"
    z "Diethylamide of lysergic acid... a hallucinogen with no reported fatalities... can be absorbed through mucous membranes... I've memorized everything you taught me..."

# game/转换后的Ren'Py脚本文件.rpy:1364
translate english flag3_121cede8:

    # x "「笨蛋……」"
    x "IDIOT"

# game/转换后的Ren'Py脚本文件.rpy:1366
translate english flag3_75b89eb3:

    # "希实香挣扎了几下，静静地靠在了我的怀里，双眼无神地看着前方"
    "Kimika struggled a few times, then quietly leaned against my arms, staring blankly ahead."

# game/转换后的Ren'Py脚本文件.rpy:1367
translate english flag3_6b74bd08:

    # "因为是从背后抱着她，此刻的心跳声格外明显，或许只有挽留的时候，两颗心才会紧紧靠在一起"
    "Because he was hugging her from behind, her heartbeat was particularly pronounced at this moment. Perhaps only when trying to hold someone back do two hearts beat so closely together."

# game/转换后的Ren'Py脚本文件.rpy:1368
translate english flag3_f6473dbd:

    # "远方的警笛声渐渐靠近，警察和救护车过不了多久就会赶来"
    "The sound of sirens in the distance is getting closer. The police and ambulance will arrive soon."

# game/转换后的Ren'Py脚本文件.rpy:1370
translate english flag3_9416b3eb:

    # "我把希实香轻轻放在了地上，晚风正轻轻拂过她纤细的发丝"
    "I gently laid Kimika down on the ground. The evening breeze was softly brushing through her fine hair."

# game/转换后的Ren'Py脚本文件.rpy:1371
translate english flag3_008559e8:

    # z "「体温好像有一点高了……」"
    z "Your body temperature seems a bit high..."

# game/转换后的Ren'Py脚本文件.rpy:1372
translate english flag3_2a211682:

    # "我接来一瓶水，轻轻地浇在的校服上，轻轻牵着她的手"
    "I took a bottle of water, gently poured it on her school uniform, and gently took her hand."

# game/转换后的Ren'Py脚本文件.rpy:1373
translate english flag3_6bf08bc1_1:

    # x "「唔……」"
    x "Wú"

# game/转换后的Ren'Py脚本文件.rpy:1374
translate english flag3_9fa1deef:

    # z "「好好睡一觉吧，好孩子」"
    z "Get a good night's sleep, good boy."

# game/转换后的Ren'Py脚本文件.rpy:1375
translate english flag3_16417f74:

    # z "「我们现在就在马尔代夫的海滩上呢，碧蓝的海面……白色的沙滩……」"
    z "We're on a beach in the Maldives right now. The sea is azure blue... The sand is white..."

# game/转换后的Ren'Py脚本文件.rpy:1377
translate english flag3_ef9b5e77:

    # x "「外面……是……什么声……音」"
    x "What... is... that... sound... outside?"

# game/转换后的Ren'Py脚本文件.rpy:1378
translate english flag3_d3903f53:

    # z "「嗯……是游轮的汽笛声吧……」"
    z "Hmm... It's the whistle of a cruise ship..."

# game/转换后的Ren'Py脚本文件.rpy:1379
translate english flag3_e7cfac03:

    # z "「能牵着你的手……就已经很高兴了」"
    z "Just being able to hold your hand... is already a great joy."

# game/转换后的Ren'Py脚本文件.rpy:1380
translate english flag3_382c723f:

    # z "「不过我一会儿要离开了……请不要怪我」"
    z "But I'm leaving in a bit... Please don't blame me."

# game/转换后的Ren'Py脚本文件.rpy:1381
translate english flag3_f73a5cc7:

    # z "「记得替我去看看泽衣村的向日葵，替我好好生活下去吧」"
    z "Remember to go to the sunflower of Sawae Village for me and live well for me."

# game/转换后的Ren'Py脚本文件.rpy:1382
translate english flag3_525c258b:

    # z "「希望每一天你都能有快乐的生活」"
    z "Hope you can have a happy life every day."

# game/转换后的Ren'Py脚本文件.rpy:1383
translate english flag3_11b4f8e6:

    # z "「……」"
    z "..."

# game/转换后的Ren'Py脚本文件.rpy:1384
translate english flag3_e16c29dc:

    # z "「我爱你……」"
    z "I love you..."

# game/转换后的Ren'Py脚本文件.rpy:1385
translate english flag3_40b6422b:

    # "耳边传来几声抽泣，那双无神的眼睛此刻已被泪水填满"
    "A few sobs reached my ears, and those lifeless eyes were now filled with tears."

# game/转换后的Ren'Py脚本文件.rpy:1387
translate english flag3_3e85dafb:

    # "那么现在……又该怎么办呢……"
    "So now... Then what should be done..."

# game/转换后的Ren'Py脚本文件.rpy:1388
translate english flag3_6ff79519:

    # "我望了望四周，只有被砸坏的栏杆，和从四面八方涌来的哀嚎声"
    "I looked around and saw only the smashed railing and the wailing coming from all directions"

# game/转换后的Ren'Py脚本文件.rpy:1389
translate english flag3_624ba6b6:

    # "似乎有什么东西滚到了脚边，低头望去，是一个装着白色粉末的塑料瓶"
    "It seemed that something had rolled to my feet. Looking down, it was a plastic bottle filled with white powder"

# game/转换后的Ren'Py脚本文件.rpy:1390
translate english flag3_493e434b:

    # z "「是你做的炸弹么……挺精致的……」"
    z "Did you make the bomb... It's quite exquisite..."

# game/转换后的Ren'Py脚本文件.rpy:1391
translate english flag3_e8667619:

    # "拿起插着电线的塑料瓶，放在眼前细细端详，忽然又感觉天地旋转了起来"
    "Picking up the plastic bottle with the wire plugged in, I held it in front of my eyes and examined it carefully. Suddenly, I felt the world spinning again"

# game/转换后的Ren'Py脚本文件.rpy:1396
translate english flag3_e7095d02:

    # z "「难道这里装的是精神药物……还是说麦角酸二乙胺从我的皮肤进入了血液？」"
    z "Could it be that this place is filled with psychotropic drugs... or has diethylamine ergottate entered my bloodstream through my skin?"

# game/转换后的Ren'Py脚本文件.rpy:1397
translate english flag3_5a0e2674:

    # "我再次回到了那间小小的科技馆……希实香依旧背对着我"
    "I returned to that small science and technology museum again... Kimika still had her back to me"

# game/转换后的Ren'Py脚本文件.rpy:1398
translate english flag3_2cbed178:

    # "事已至此，我只想在拥抱她一次……"
    "At this point, I just want to embrace her one more time..."

# game/转换后的Ren'Py脚本文件.rpy:1399
translate english flag3_5cd38327:

    # zs "「点火吧……」"
    zs "Light the fire..."

# game/转换后的Ren'Py脚本文件.rpy:1400
translate english flag3_d44a604c:

    # z "「什么……」"
    z "What?"

# game/转换后的Ren'Py脚本文件.rpy:1401
translate english flag3_33b08b67:

    # zs "「是科学馆的消防游戏……」"
    zs "It's the Science Museum's fire safety game..."

# game/转换后的Ren'Py脚本文件.rpy:1402
translate english flag3_e5a1cf7c:

    # z "「什么游戏……会有这样的内容……」"
    z "What kind of game... would have such content..."

# game/转换后的Ren'Py脚本文件.rpy:1403
translate english flag3_d8221c9f:

    # zs "「你就当是为我好吧……我嫉妒它的美」"
    zs "Just think of it as being for my sake... I'm jealous of its beauty."

# game/转换后的Ren'Py脚本文件.rpy:1404
translate english flag3_77f1a879:

    # "她的声音近乎是在祈求，让我不忍心再听下去"
    "Her voice was almost pleading, and I couldn't bear to listen any longer."

# game/转换后的Ren'Py脚本文件.rpy:1405
translate english flag3_6097e3c2:

    # "恍惚间，手里似乎有什么东西滑落，紧接着就是一声巨响，科技馆冒出了些许火星"
    "In a daze, something seemed to slip from his hand, followed by a loud bang, and a few sparks flew out of the Science Museum."

# game/转换后的Ren'Py脚本文件.rpy:1406
translate english flag3_055c28ee:

    # zs "「我嫉妒他们……不久之后，他们就会离开医院，继续抽烟，继续酗酒，继续像往常一样强奸像你一样的同学」"
    zs "I'm jealous of them... Soon, they'll leave the hospital, continue smoking, continue drinking, and continue raping classmates like you as usual."

# game/转换后的Ren'Py脚本文件.rpy:1407
translate english flag3_47a2a54a:

    # zs "「而我…要在精神病院和监狱里…继续痛苦地活下去」"
    zs "And I... will continue to live in pain... in mental hospitals and prisons."

# game/转换后的Ren'Py脚本文件.rpy:1408
translate english flag3_5b94e573:

    # zs "「嫉妒是我一生最大的罪过…从学钢琴开始，我就嫉妒别人的天赋…」"
    zs "Jealousy is the biggest sin of my life... Ever since I started learning the piano, I've been jealous of other people's talents..."

# game/转换后的Ren'Py脚本文件.rpy:1409
translate english flag3_d3aa8f6c:

    # z "「你……你不是希实香……」"
    z "You... You're not Kimika..."

# game/转换后的Ren'Py脚本文件.rpy:1410
translate english flag3_48b532f3:

    # zs "「从小的贵族教育…让我遇见了无数天才…而我的自命不凡……在天赋面前，被剥得只剩下了嫉妒与自卑」"
    zs "My upbringing as a young nobleman... allowed me to meet countless geniuses... and my self-importance... was stripped down to nothing but jealousy and inferiority in the face of talent."

# game/转换后的Ren'Py脚本文件.rpy:1411
translate english flag3_8f5e1c62:

    # zs "「我最大的自豪…就是不被人理解…孤独越来越肥硕……简直像一头猪」"
    zs "My greatest pride... is not being understood... Loneliness is getting fatter and fatter... It's like a pig."

# game/转换后的Ren'Py脚本文件.rpy:1412
translate english flag3_07aba475:

    # zs "「因此我开始嫉妒所有人…嫉妒那些有能力的人…嫉妒那些漂亮的人」"
    zs "So I started to be jealous of everyone... jealous of those who are capable... jealous of those who are beautiful."

# game/转换后的Ren'Py脚本文件.rpy:1413
translate english flag3_2ec6d588:

    # zs "「当遇到长相可爱的女生时…我便会忍不住幻想…她们在过去或未来的某一刻，在某个人的床上，尽情地交媾着」"
    zs "When I meet a pretty girl... I can't help but imagine... that at some point in the past or future, she'll be having sex with someone in bed."

# game/转换后的Ren'Py脚本文件.rpy:1414
translate english flag3_5c557e06:

    # zs "「她们只要打开双腿…就会自动得到金钱与爱…甚至还会为此而抱怨」"
    zs "They just have to open their legs... and they'll automatically get money and love... and they'll even complain about it."

# game/转换后的Ren'Py脚本文件.rpy:1415
translate english flag3_b4cb131d:

    # zs "「不是处女真恶心啊…不管是过去就不是了，还是未来不是…」"
    zs "It's really disgusting to not be a virgin... Whether it's in the past or in the future..."

# game/转换后的Ren'Py脚本文件.rpy:1416
translate english flag3_ff61b6e4:

    # zs "「而我呢…从出生到现在…从未有过任何真心的关怀……一直与我相伴的，只有孤独」"
    zs "As for me... from birth until now... I've never had any genuine care... The only thing that has always been with me is loneliness."

# game/转换后的Ren'Py脚本文件.rpy:1417
translate english flag3_49d30423:

    # zs "「肥硕的孤独…只会供养着我的嫉妒…于是嫉妒的火越来越旺……简直要把我烧死」"
    zs "My profound loneliness... only fuels my jealousy... and the flames of jealousy grow ever stronger... almost burning me alive."

# game/转换后的Ren'Py脚本文件.rpy:1419
translate english flag3_fc8d22a4:

    # "展厅里的烟越来越浓，我只好拉着它跑出去"
    "The smoke in the showroom was getting thicker, so I had to grab it and run out."

# game/转换后的Ren'Py脚本文件.rpy:1420
translate english flag3_b29e0e8c:

    # zs "「但是能烧死我的火焰…同样能烧死每一个人…这是多么美丽的事啊」"
    zs "But the flame that could burn me to death... could also burn everyone to death... How beautiful this is!"

# game/转换后的Ren'Py脚本文件.rpy:1421
translate english flag3_6ddc544e:

    # "来到展馆外，这座原本精致的神似寺庙的建筑，已经烧的只剩木质骨架"
    "Outside the exhibition hall, this once exquisite temple-like building has been burned down to its wooden frame."

# game/转换后的Ren'Py脚本文件.rpy:1423
translate english flag3_fcaa9b14:

    # z "「你是谁……」"
    z "Who are you..."

# game/转换后的Ren'Py脚本文件.rpy:1424
translate english flag3_d39871c3:

    # zs "「我是……谁？」"
    zs "Who am I...?"

# game/转换后的Ren'Py脚本文件.rpy:1425
translate english flag3_c3117432:

    # z "「伏行之混沌？」"
    z "the Crawling Chaos?"

# game/转换后的Ren'Py脚本文件.rpy:1426
translate english flag3_50885c77:

    # zs "「我是……」"
    zs "I am..."

# game/转换后的Ren'Py脚本文件.rpy:1427
translate english flag3_e09a8594:

    # zs "「我就是你……」"
    zs "I'm you..."

# game/转换后的Ren'Py脚本文件.rpy:1430
translate english flag3_cde6bc74:

    # zs "「间宫卓司」"
    zs "Takuji Mamiya"

# game/转换后的Ren'Py脚本文件.rpy:1431
translate english flag3_434091a7:

    # "它用力将我推向河里，随后消失在空气中"
    "It pushed me hard into the river and then vanished into thin air."

# game/转换后的Ren'Py脚本文件.rpy:1433
translate english flag3_f49a637b:

    # "我没有落入水中，有什么东西缠住了我，让我摔在了水泥地上"
    "I didn't fall into the water. Something caught me and made me fall onto the concrete floor."

# game/转换后的Ren'Py脚本文件.rpy:1434
translate english flag3_24b12f16:

    # x "「不要…不要跳下去…」"
    x "Don't... don't jump..."

# game/转换后的Ren'Py脚本文件.rpy:1435
translate english flag3_ee06b22f:

    # "希实香紧紧抓住了我的脚踝，尽管此时她模糊的意识只够说出几个简单的词"
    "Kimika gripped my ankle tightly, even though her clouded mind could only muster a few simple words at that moment."

# game/转换后的Ren'Py脚本文件.rpy:1436
translate english flag3_446085ee:

    # "显然，我刚刚把炸弹丢了下去，又想把自己也丢下去"
    "Obviously, I just dropped the bomb and wanted to drop myself down too."

# game/转换后的Ren'Py脚本文件.rpy:1437
translate english flag3_1965c019:

    # "炸弹似乎引燃了绿化带，此时正火光冲天"
    "The bomb seems to have ignited the greenbelt, and flames are now shooting into the sky."

# game/转换后的Ren'Py脚本文件.rpy:1438
translate english flag3_fee621d9:

    # "坐在天台的边缘，我看着火苗舔舐着校园，就像多年前那个在泽衣村盯着篝火的少年"
    "Sitting on the edge of the rooftop, I watched the flames lick at the campus, like the boy who stared at the bonfire in Sawae Village many years ago."

# game/转换后的Ren'Py脚本文件.rpy:1439
translate english flag3_ec938424:

    # "我要从这跳下去吗？以此来逃避不可知的未来"
    "Should I jump from here? To escape an uncertain future."

# game/转换后的Ren'Py脚本文件.rpy:1440
translate english flag3_918dba06:

    # "思考的片刻，希实香爬了过来，再次拽住了我的衣服，我的心里此刻有了答案"
    "After a moment of thought, Kimika crawled over and grabbed my clothes again. At that moment, I had the answer in my heart."

# game/转换后的Ren'Py脚本文件.rpy:1442
translate english flag3_441728bc:

    # "一摸口袋，里面还有小刀和半包lsd，我把他们扔了下去"
    "I felt my pockets and found a knife and half a bag of LSD inside. I threw them away."

# game/转换后的Ren'Py脚本文件.rpy:1443
translate english flag3_751c4097:

    # "我摸到了另一个口袋里的香烟，用从未经历，却无比熟悉的动作点燃了一根，温暖而辛辣的烟气在喉咙里散开"
    "I felt for the cigarettes in another pocket and lit one with a motion that was unfamiliar yet incredibly familiar. The warm, pungent smoke spread through my throat."

# game/转换后的Ren'Py脚本文件.rpy:1444
translate english flag3_a85cc773:

    # "像有些人忙完一件工作就想抽根烟一样，我想：活下去吧"
    "Just like some people want to smoke a cigarette after finishing a task, I think: Just keep living."

# game/转换后的Ren'Py脚本文件.rpy:1457
translate english flag4_35da9619:

    # "或许是运动能力很差的缘故，即使只是这一点路程，就已经让我岔气了"
    "Perhaps due to my poor athletic ability, even just this short distance has already made me out of breath"

# game/转换后的Ren'Py脚本文件.rpy:1458
translate english flag4_03f5bf97:

    # "然而此刻，我已顾不上喘气，因为眼下有更重要的事等着我"
    "But at this moment, I have no time to catch my breath, for there are more important things waiting for me right now"

# game/转换后的Ren'Py脚本文件.rpy:1459
translate english flag4_3d4156af:

    # "来到地面时，昔日的学校已经被哀嚎声充满"
    "When arriving at the ground, the former school was already filled with wails"

# game/转换后的Ren'Py脚本文件.rpy:1460
translate english flag4_81c4a8c9:

    # "在遍地头破血流的人群里，我的目光焦急地寻觅着，所幸没有看见那个小小的身影"
    "Amidst the crowd strewn with bleeding heads, my eyes anxiously searched, but fortunately, I didn't spot that tiny figure"

# game/转换后的Ren'Py脚本文件.rpy:1462
translate english flag4_ff68d99a:

    # "希实香的背影是什么样的呢？平时我大概也没有刻意去关注吧……毕竟我之前喜欢的女生……大概是高岛这种类型……"
    "What does Kimika's back look like? I probably haven't deliberately paid attention to it usually... After all, the girl I liked before... It's probably of the Takashima type..."

# game/转换后的Ren'Py脚本文件.rpy:1463
translate english flag4_d617f9ff:

    # "但是为什么……希实香的背影，让我这么熟悉呢……她真正进入我的生活里，算下来不过才寥寥几天"
    "But why... Kimika's back view is so familiar to me... It has only been a few days since she truly entered my life"

# game/转换后的Ren'Py脚本文件.rpy:1464
translate english flag4_e6afbf98:

    # "不过，可以确认的是，无意识的那段时间里，我大概一直躺在她的怀里吧……"
    "However, it can be confirmed that during that period of unconsciousness, I was probably lying in her arms the whole time..."

# game/转换后的Ren'Py脚本文件.rpy:1465
translate english flag4_7dc84e70:

    # "听上去还是挺幸福的……"
    "It sounds pretty happy..."

# game/转换后的Ren'Py脚本文件.rpy:1466
translate english flag4_4f47db7a:

    # "说不定就是在这个时候，在意识之外的时间里，悄悄地看了她无数眼……"
    "Perhaps it was at this moment, in a time outside of consciousness, that he quietly gazed at her countless times..."

# game/转换后的Ren'Py脚本文件.rpy:1467
translate english flag4_ea8bce19:

    # "为什么要在通往末日的旅途里，费尽心思地为我编织一个美好的梦呢……"
    "Why go to such lengths to weave a beautiful dream for me on the journey to the end of the world..."

# game/转换后的Ren'Py脚本文件.rpy:1468
translate english flag4_5b68bc94:

    # "问题的答案，只有当面问她才能知晓吧"
    "The answer to the question can only be found by asking her in person."

# game/转换后的Ren'Py脚本文件.rpy:1469
translate english flag4_ebfd68a1:

    # "现在，又多出了一个活着的理由"
    "Now, there's one more reason to live."

# game/转换后的Ren'Py脚本文件.rpy:1470
translate english flag4_4571b346:

    # "如果从楼梯跑上去的话……应该比走那个狭小的通道快不少吧……"
    "If I run up the stairs... it should be much faster than going through that narrow passage..."

# game/转换后的Ren'Py脚本文件.rpy:1472
translate english flag4_15691e70:

    # "我心里这么想着，便快步向楼梯口跑去，内心却有着隐隐的不安"
    "With these thoughts in mind, I hurried towards the staircase, but there was a faint sense of unease in my heart."

# game/转换后的Ren'Py脚本文件.rpy:1473
translate english flag4_659c9e20:

    # "不对！似乎有一股力量牵引着我，带着我回头跑去"
    "No! It seems like there's a force pulling me, making me run back."

# game/转换后的Ren'Py脚本文件.rpy:1474
translate english flag4_93ad34ce:

    # x "「再见了……我深深爱着的…最最重要的人……」"
    x "Goodbye... the most important person... whom I love deeply..."

# game/转换后的Ren'Py脚本文件.rpy:1475
translate english flag4_73d5878a:

    # z "「不要！」"
    z "I don't want that"

# game/转换后的Ren'Py脚本文件.rpy:1476
translate english flag4_abff7172:

    # "我几乎是喊了出来"
    "I almost shouted."

# game/转换后的Ren'Py脚本文件.rpy:1477
translate english flag4_405f9816:

    # "但显然……声音的力量阻止不了重力……那个小小的身影从天空飘落了下来，就像秋天里飘落的一片树叶"
    "But obviously... the power of sound cannot overcome gravity... that tiny figure fell from the sky, like a leaf falling in autumn."

# game/转换后的Ren'Py脚本文件.rpy:1479
translate english flag4_3ee62295:

    # "回忆再次命中了我，高岛从楼顶下坠的画面再次浮现在我眼前"
    "The memories hit me again, and the image of Takashima falling from the roof flashed before my eyes once more."

# game/转换后的Ren'Py脚本文件.rpy:1480
translate english flag4_62aeadc9:

    # "我该做什么呢，我又能做什么呢……希实香的魔力，已经让我不在是那个救世主了……如今我只是一个想牵着她的手，好好生活下去的普通人"
    "What should I do? What can I do...? Kimika's magic has made me no longer the Savior... Now I'm just an ordinary person who wants to hold her hand and live a good life."

# game/转换后的Ren'Py脚本文件.rpy:1482
translate english flag4_96edc6b5:

    # "空中的身影还在加速下落"
    "The figure in the air is still accelerating its descent."

# game/转换后的Ren'Py脚本文件.rpy:1483
translate english flag4_5c18d2ba:

    # "在科学世纪里，我再一次的祈求，希望短暂取回救世主的力量，当然我知道这一切都是徒劳"
    "In the Scientific Century, I prayed once again, hoping to briefly regain the power of the Savior. Of course, I knew it was all in vain."

# game/转换后的Ren'Py脚本文件.rpy:1484
translate english flag4_7bffdfc3:

    # "于是我冲向了她，出于本能地伸出了手"
    "So I rushed towards her and instinctively reached out my hand"

# game/转换后的Ren'Py脚本文件.rpy:1485
translate english flag4_9fa8b178:

    # "夜空里，校服的裙摆在气流里狂乱的飘舞，让下落的她显得更加恐慌和无助"
    "In the night sky, the skirt of her school uniform was fluttering wildly in the air current, making her look even more panicked and helpless as she fell"

# game/转换后的Ren'Py脚本文件.rpy:1486
translate english flag4_abde2163:

    # "我知道，我不会再让高岛同样的事情发生在眼前"
    "I know that I won't let the same thing happen to Takashima again"

# game/转换后的Ren'Py脚本文件.rpy:1487
translate english flag4_0c12290b:

    # "我要接住她"
    "I'm going to catch her"

# game/转换后的Ren'Py脚本文件.rpy:1489
translate english flag4_966b22e3:

    # "不管是否有救世主的力量，我都要……接住她……"
    "Whether or not Savior has the power, I will... Catch her..."

# game/转换后的Ren'Py脚本文件.rpy:1494
translate english flag4_a12cb31b:

    # "在漆黑的夜里，我拥抱了她"
    "In the pitch-dark night, I hugged her"

# game/转换后的Ren'Py脚本文件.rpy:1495
translate english flag4_ec1a7ff8:

    # "就像在科学馆里一样，就像在一次次幻想里一样，我拥抱着她……"
    "Just like in the Science Museum, just like in my countless daydreams, I embraced her..."

# game/转换后的Ren'Py脚本文件.rpy:1496
translate english flag4_f506c4d7:

    # "在现实里，第一次，把她紧紧抱在我的臂弯"
    "In reality, for the first time, I held her tightly in my arms."

# game/转换后的Ren'Py脚本文件.rpy:1497
translate english flag4_cd9ae391:

    # "想象中的疼痛并没有到来，我只感到身体格外沉重，视线沉入黑暗"
    "The pain I imagined didn't come. I only felt my body become exceptionally heavy, and my vision sank into darkness."

# game/转换后的Ren'Py脚本文件.rpy:1500
translate english flag4_c9b82876:

    # x "「笨蛋卓司……这个时候还闭着眼睛」"
    x "Idiot Takuji... still with his eyes closed at this moment."

# game/转换后的Ren'Py脚本文件.rpy:1501
translate english flag4_76576257:

    # z "「啊……额……」"
    z "Ah... Uh..."

# game/转换后的Ren'Py脚本文件.rpy:1502
translate english flag4_28b1af2b:

    # "我睁开了眼睛，希实香轻轻躺在我的怀里，我向四周望去，只看见地面在远离"
    "I opened my eyes. Kimika was lying gently in my arms. I looked around and saw only the ground moving away."

# game/转换后的Ren'Py脚本文件.rpy:1503
translate english flag4_dd750bd9:

    # z "「在到达地面的前一刻，居然飞向了天空吗……」"
    z "Just before hitting the ground, it actually flew into the sky..."

# game/转换后的Ren'Py脚本文件.rpy:1504
translate english flag4_71e7636e:

    # x "「嗯……看来救世主大人取回了力量呢……」"
    x "Well... It seems that Lord Savior has regained his power..."

# game/转换后的Ren'Py脚本文件.rpy:1505
translate english flag4_9c463132:

    # z "「可是为什么……感觉身体变重了很多」"
    z "But why... do I feel like my body has become much heavier?"

# game/转换后的Ren'Py脚本文件.rpy:1506
translate english flag4_172f01ea:

    # x "「看起来我们在向天空坠落呢」"
    x "It looks like we're falling from the sky."

# game/转换后的Ren'Py脚本文件.rpy:1507
translate english flag4_98175be2:

    # x "「大概是我们的加速度和地球引力叠加在了一起吧……」"
    x "It's probably because our acceleration and Earth's gravity are adding up..."

# game/转换后的Ren'Py脚本文件.rpy:1508
translate english flag4_0c68d200:

    # "2012年7月20日0点01分"
    "July 20, 2012, 00:01"

# game/转换后的Ren'Py脚本文件.rpy:1509
translate english flag4_f269b3e0:

    # "高度达到18km,速度2100km/s"
    "高度达到18km,速度2100km/s"

# game/转换后的Ren'Py脚本文件.rpy:1510
translate english flag4_13c0090f:

    # z "「天空变成了黑色……」"
    z "The sky turned black..."

# game/转换后的Ren'Py脚本文件.rpy:1511
translate english flag4_5a2a32c0:

    # x "「星星也能看见了呢……」"
    x "I can see the stars too..."

# game/转换后的Ren'Py脚本文件.rpy:1512
translate english flag4_5f11e73c:

    # "地球曲率越来越明显，大气层变成蓝色薄晕，脚下就是本州岛"
    "地球曲率越来越明显，大气层变成蓝色薄晕，脚下就是本州岛"

# game/转换后的Ren'Py脚本文件.rpy:1513
translate english flag4_3562f614:

    # "2012年7月20日0点02分23秒"
    "At 0:02:23 on July 20, 2012"

# game/转换后的Ren'Py脚本文件.rpy:1514
translate english flag4_2803061d:

    # "高度100km,速度1.43km/s"
    "Height: 100km, speed: 1.43km/s"

# game/转换后的Ren'Py脚本文件.rpy:1515
translate english flag4_afb160aa:

    # x "「要越过卡门线了」"
    x "We're about to cross the Kármán line."

# game/转换后的Ren'Py脚本文件.rpy:1516
translate english flag4_12993d5b:

    # z "「各个大洲的轮廓已经能看见了呢……」"
    z "The outlines of the various continents are already visible..."

# game/转换后的Ren'Py脚本文件.rpy:1517
translate english flag4_13229e9d:

    # x "「下面那条发蓝光的圆环就是大气层哦」"
    x "That blue ring down there is the atmosphere."

# game/转换后的Ren'Py脚本文件.rpy:1518
translate english flag4_1af6b621:

    # "2012年7月20日1点00分"
    "1:00 a.m. on July 20, 2012"

# game/转换后的Ren'Py脚本文件.rpy:1519
translate english flag4_cc695c48:

    # "高度63 547km，速度35.3km/s"
    "Altitude: 63,547 kilometers, speed: 35.3 kilometers per second"

# game/转换后的Ren'Py脚本文件.rpy:1520
translate english flag4_ae9297ce:

    # x "「地球在视线里已经能看出是一个完整的球了……」"
    x "The Earth can already be seen as a complete sphere from the line of sight..."

# game/转换后的Ren'Py脚本文件.rpy:1521
translate english flag4_372ad37a:

    # z "「那个小灰点是月球吧」"
    z "Is that little grey dot the moon?"

# game/转换后的Ren'Py脚本文件.rpy:1522
translate english flag4_2ef4d36f:

    # x "「太阳已经变成了一个闪光的圆盘唉」"
    x "The sun has turned into a shining disc."

# game/转换后的Ren'Py脚本文件.rpy:1524
translate english flag4_66c61777:

    # "2012年7月21日0点00分"
    "0:00 on July 21, 2012"

# game/转换后的Ren'Py脚本文件.rpy:1525
translate english flag4_29fab619:

    # "高度0.2447AU，速度847km/s"
    "Altitude: 0.2447AU, speed: 847km/s"

# game/转换后的Ren'Py脚本文件.rpy:1526
translate english flag4_ea2f3fce:

    # z "「地球马上就要看不见了……」"
    z "The Earth is about to disappear from sight..."

# game/转换后的Ren'Py脚本文件.rpy:1527
translate english flag4_9cbbc55f:

    # x "「再看一眼那个点吧……那就是我们……」"
    x "Take one more look at that point... That's us..."

# game/转换后的Ren'Py脚本文件.rpy:1528
translate english flag4_3627057a:

    # x "「历史上的所有人……都出生在那里……埋葬在那里……那就是我们……」"
    x "All the people in history... were born there... buried there... That's us..."

# game/转换后的Ren'Py脚本文件.rpy:1530
translate english flag4_866ffd20:

    # "2012年7月25日22点05分"
    "2012年7月25日22点05分"

# game/转换后的Ren'Py脚本文件.rpy:1531
translate english flag4_0cc1aba4:

    # "高度8.583AU，速度5018km/s"
    "高度8.583AU，速度5018km/s"

# game/转换后的Ren'Py脚本文件.rpy:1532
translate english flag4_3e6f3061:

    # z "「这颗是土星吗」"
    z "Is this Saturn?"

# game/转换后的Ren'Py脚本文件.rpy:1533
translate english flag4_29388bfb:

    # x "「嗯……土星环是不是很像唱片」"
    x "Well... don't Saturn's rings look like a record?"

# game/转换后的Ren'Py脚本文件.rpy:1534
translate english flag4_79299bb1:

    # z "「边上这个是什么呢」"
    z "What's this thing on the side?"

# game/转换后的Ren'Py脚本文件.rpy:1535
translate english flag4_19876b46:

    # x "「嗯……是惠更斯号」"
    x "Well... it's the Huygens."

# game/转换后的Ren'Py脚本文件.rpy:1536
translate english flag4_bce8fee3:

    # x "「再过几天就要超过旅行者2号了……」"
    x "In a few more days, it will surpass Voyager 2..."

# game/转换后的Ren'Py脚本文件.rpy:1538
translate english flag4_90d951b1:

    # "2012年1月20日"
    "January 20, 2012"

# game/转换后的Ren'Py脚本文件.rpy:1539
translate english flag4_52b5e9f1:

    # "高度？？？，速度？？？"
    "Height?? Speed??"

# game/转换后的Ren'Py脚本文件.rpy:1540
translate english flag4_7e802783:

    # z "「太阳好像变红了不少……」"
    z "The sun seems to have turned a lot redder..."

# game/转换后的Ren'Py脚本文件.rpy:1541
translate english flag4_076f9d78:

    # x "「是多普勒效应造成的红移噢，正前方的星光也因此变得更蓝了！」"
    x "It's a redshift caused by the Doppler effect. That's why the starlight directly ahead appears bluer!"

# game/转换后的Ren'Py脚本文件.rpy:1542
translate english flag4_aa48cbfc:

    # z "「我们到哪了呢」"
    z "Where are we?"

# game/转换后的Ren'Py脚本文件.rpy:1543
translate english flag4_928b8c92:

    # x "「嗯……还有半年飞出奥尔特云吧」"
    x "Well... let's aim to leave the Oort Cloud in another six months."

# game/转换后的Ren'Py脚本文件.rpy:1544
translate english flag4_826e451f:

    # z "「那就是说还没有飞出太阳系……」"
    z "That means it hasn't left the solar system yet..."

# game/转换后的Ren'Py脚本文件.rpy:1548
translate english flag4_2302e4a7:

    # "2016年……速度越发接近光速……多普勒效应越来越明显"
    "In 2016... The speed is getting closer and closer to the speed of light... The Doppler effect is becoming increasingly obvious"

# game/转换后的Ren'Py脚本文件.rpy:1549
translate english flag4_86ec9b15:

    # "正前方的可见光几乎全部移到了不可见的波长……后方的光也已经移到了红外波段……"
    "Almost all the visible light directly ahead has shifted to invisible wavelengths... The light behind has also shifted to the infrared band..."

# game/转换后的Ren'Py脚本文件.rpy:1550
translate english flag4_f7e36de0:

    # "203x年，相对论效应极其显著……"
    "In 203x, the relativistic effect was extremely significant..."

# game/转换后的Ren'Py脚本文件.rpy:1551
translate english flag4_2191e1d3:

    # "时间膨胀下，实际时间已超过4.2*10^28年"
    "Under time dilation, the actual time has exceeded 4.2*10^28 years"

# game/转换后的Ren'Py脚本文件.rpy:1552
translate english flag4_0f73e5f5:

    # "天空似乎也没有那么有趣，周围只剩一片漆黑的热寂，我只觉得喘不过气来"
    "The sky doesn't seem so interesting either. There's only a dark, heat-death silence all around, and I feel like I can't breathe."

# game/转换后的Ren'Py脚本文件.rpy:1553
translate english flag4_517e61f9:

    # "恍惚间，似乎听见希实香的哭声……"
    "In a daze, it seems like I heard Kimika crying..."

# game/转换后的Ren'Py脚本文件.rpy:1556
translate english flag4_33bb184b:

    # "躺在地上,慢慢地睁开眼睛，很幸运，我再次看到了希实香"
    "Lying on the ground, I slowly opened my eyes. Fortunately, I saw Kimika again."

# game/转换后的Ren'Py脚本文件.rpy:1557
translate english flag4_83453a91:

    # "她在哭吗？还是在责怪我呢，我已经听不清了，因为断掉的骨头已经扎进了我的内脏，很快连她的脸我也要看不清了……"
    "Is she crying? Or was she blaming me? I couldn't hear clearly anymore, because the broken bones had pierced my internal organs, and soon I wouldn't even be able to see her face clearly..."

# game/转换后的Ren'Py脚本文件.rpy:1558
translate english flag4_3a8f7de8:

    # "不过可以确定的是，她并没有受伤,只是趴在我的身上……哭泣着"
    "But what's certain is that she wasn't hurt. She was just lying on top of me... crying."

# game/转换后的Ren'Py脚本文件.rpy:1559
translate english flag4_121cede8:

    # x "「笨蛋……」"
    x "IDIOT"

# game/转换后的Ren'Py脚本文件.rpy:1560
translate english flag4_7c753524:

    # "全身的骨头断了很多，意识又一次模糊了下去"
    "Many bones in her body were broken, and her consciousness faded again."

# game/转换后的Ren'Py脚本文件.rpy:1561
translate english flag4_03d6500f:

    # "在科学世纪里，我没有飘向天空，也不是什么救世主……"
    "In the Scientific Century, I didn't float up to the sky, nor am I any kind of Savior..."

# game/转换后的Ren'Py脚本文件.rpy:1562
translate english flag4_a777ae46:

    # "飞向宇宙只是我又一次的意淫……我救不了世界，做什么也都成功不了……"
    "Flying into space is just another fantasy of mine... I can't save the world, and nothing I do will succeed..."

# game/转换后的Ren'Py脚本文件.rpy:1563
translate english flag4_f21d7582:

    # "但是我……接住了她"
    "But I... Caught her"

# game/转换后的Ren'Py脚本文件.rpy:1564
translate english flag4_3ce1f7c8:

    # "在现实里，第一次拥抱她，却是永别"
    "In reality, the first time I hugged her, it turned out to be a permanent farewell"

# game/转换后的Ren'Py脚本文件.rpy:1568
translate english flag4_eb2ec0d1:

    # "视线已经彻底消失，只剩嗅觉给我一丝熟悉的薰衣草香"
    "My vision has completely vanished, leaving only my sense of smell to give me a hint of the familiar scent of lavender"

# game/转换后的Ren'Py脚本文件.rpy:1569
translate english flag4_29a3220c:

    # "比起飞翔冷寂无边的黑暗，这样或许也不错？"
    "Perhaps this is not a bad idea compared to flying in the cold and boundless darkness?"

# game/转换后的Ren'Py脚本文件.rpy:1570
translate english flag4_9fa33f6d:

    # "我想，我是幸福的"
    "I think I am happy"

# game/转换后的Ren'Py脚本文件.rpy:1572
translate english flag4_d46dda23:

    # centered "{size=+60}{color=#C8A84E}遙かなる夢に～{/color}{/size}" with Dissolve(3.0)
    centered "{size=+60}{color=#C8A84E}Harukanaru Yume ni ~{/color}{/size}" with Dissolve(3.0)

# game/转换后的Ren'Py脚本文件.rpy:1573
translate english flag4_d195ec64:

    # centered "{size=+60}{color=#C8A84E}by Eikiga \n2026.11.23{/color}{/size}" with Dissolve(1.0)
    centered "{size=+60}{color=#C8A84E}by Eikiga \n2026.11.23{/color}{/size}" with Dissolve(1.0)

translate english strings:

    # game/转换后的Ren'Py脚本文件.rpy:579
    old "不去地下馆，去前面看看"
    new "Instead of going to the Underground Hall, go and have a look at the front"

    # game/转换后的Ren'Py脚本文件.rpy:581
    old "去地下馆看看"
    new "Go check out the Underground Hall."

    # game/转换后的Ren'Py脚本文件.rpy:1333
    old "从通道爬上去"
    new "Climb up from the passage."

    # game/转换后的Ren'Py脚本文件.rpy:1335
    old "先到地面上，走楼梯"
    new "Get to the ground floor first, then take the stairs."

