﻿# TODO: Translation updated at 2026-11-13 12:54

translate english strings:

    # game/screens.rpy:242
    old "回退"
    new "Back"

    # game/screens.rpy:243
    old "历史"
    new "History"

    # game/screens.rpy:244
    old "快进"
    new "Fast forward"

    # game/screens.rpy:245
    old "自动"
    new "\"Automatic"

    # game/screens.rpy:246
    old "保存"
    new "Save"

    # game/screens.rpy:247
    old "快存"
    new "Quick Save"

    # game/screens.rpy:248
    old "快读"
    new "Read up!"

    # game/screens.rpy:249
    old "设置"
    new "settings.ini"

    # game/screens.rpy:293
    old "开始游戏"
    new "Start Game"

    # game/screens.rpy:301
    old "读取游戏"
    new "Load Game"

    # game/screens.rpy:302
    old "画廊"
    new "Gallery"

    # game/screens.rpy:308
    old "结束回放"
    new "End Playback"

    # game/screens.rpy:312
    old "标题菜单"
    new "Header Menu %s"

    # game/screens.rpy:314
    old "关于"
    new "For"

    # game/screens.rpy:319
    old "帮助"
    new "&Help"

    # game/screens.rpy:324
    old "退出"
    new "Quit"

    # game/screens.rpy:495
    old "返回"
    new "&Back\\tF7"

    # game/screens.rpy:578
    old "版本 [config.version!t]\n"
    new "Version 0"

    # game/screens.rpy:584
    old "引擎：{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]\n\n[renpy.license!t]"
    new "Engine: {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]\n\n[renpy.license!t]"

    # game/screens.rpy:619
    old "第 {} 页"
    new "Page |0"

    # game/screens.rpy:619
    old "自动存档"
    new "AutoArchive"

    # game/screens.rpy:619
    old "快速存档"
    new "Quick Archive"

    # game/screens.rpy:660
    old "{#file_time}%Y-%m-%d %H:%M"
    new "{#file_time}%Y-%m-%d %H:%M"

    # game/screens.rpy:660
    old "空存档位"
    new "Empty Archive Slot"

    # game/screens.rpy:680
    old "<"
    new "<"

    # game/screens.rpy:684
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:687
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:693
    old ">"
    new ">"

    # game/screens.rpy:698
    old "上传同步"
    new "Upload and Sync"

    # game/screens.rpy:702
    old "下载同步"
    new "Download Sync"

    # game/screens.rpy:761
    old "显示"
    new "Display"

    # game/screens.rpy:762
    old "窗口"
    new "Window"

    # game/screens.rpy:763
    old "全屏"
    new "Full screen"

    # game/screens.rpy:768
    old "未读文本"
    new "Unread text"

    # game/screens.rpy:769
    old "选项后继续"
    new "Continue after the option"

    # game/screens.rpy:770
    old "忽略转场"
    new "Ignore transitions"

    # game/screens.rpy:783
    old "文字速度"
    new "Text speed"

    # game/screens.rpy:787
    old "自动前进时间"
    new "Automatic forward time"

    # game/screens.rpy:794
    old "音乐音量"
    new "MUSIC VOLUME"

    # game/screens.rpy:801
    old "音效音量"
    new "EFFECTS VOLUME"

    # game/screens.rpy:807
    old "测试"
    new "Test"

    # game/screens.rpy:811
    old "语音音量"
    new "Dialogue Volume"

    # game/screens.rpy:822
    old "全部静音"
    new "Mute all"

    # game/screens.rpy:940
    old "尚无对话历史记录。"
    new "No conversation history yet."

    # game/screens.rpy:1007
    old "键盘"
    new "keybord"

    # game/screens.rpy:1008
    old "鼠标"
    new "mouse"

    # game/screens.rpy:1011
    old "手柄"
    new "Handle"

    # game/screens.rpy:1024
    old "回车"
    new "Return"

    # game/screens.rpy:1025
    old "推进对话并激活界面。"
    new "Advance the conversation and activate the interface."

    # game/screens.rpy:1028
    old "空格"
    new "Spasi"

    # game/screens.rpy:1029
    old "在没有选择的情况下推进对话。"
    new "Proceed with the conversation without any options."

    # game/screens.rpy:1032
    old "方向键"
    new "Directional keys"

    # game/screens.rpy:1033
    old "导航界面。"
    new "Navigation interface"

    # game/screens.rpy:1036
    old "Esc"
    new "Esc"

    # game/screens.rpy:1037
    old "访问游戏菜单。"
    new "Access the game menu."

    # game/screens.rpy:1041
    old "按住时快进对话。"
    new "Hold to fast-forward the dialogue."

    # game/screens.rpy:1044
    old "Tab"
    new "Tab"

    # game/screens.rpy:1045
    old "切换对话快进。"
    new "Skip dialogue."

    # game/screens.rpy:1048
    old "上一页"
    new "Prev"

    # game/screens.rpy:1049
    old "回退至先前的对话。"
    new "Go back to the previous conversation."

    # game/screens.rpy:1052
    old "下一页"
    new "Next\\tF8"

    # game/screens.rpy:1053
    old "向前至后来的对话。"
    new "Go forward to later conversations."

    # game/screens.rpy:1057
    old "隐藏用户界面。"
    new "Hide the user interface."

    # game/screens.rpy:1061
    old "截图。"
    new "Screenshot."

    # game/screens.rpy:1065
    old "切换辅助{a=https://doc.renpy.cn/zh-CN/self_voicing.html}机器朗读{/a}。"
    new "Switch to assist {a=https://doc.renpy.cn/zh-CN/self_voicing.html} machine reading {/a}."

    # game/screens.rpy:1069
    old "打开无障碍菜单。"
    new "Open the accessibility menu."

    # game/screens.rpy:1075
    old "左键点击"
    new "Left-click"

    # game/screens.rpy:1079
    old "中键点击"
    new "Click the middle button"

    # game/screens.rpy:1083
    old "右键点击"
    new "RightClick"

    # game/screens.rpy:1087
    old "鼠标滚轮上"
    new "Mouse wheel up"

    # game/screens.rpy:1091
    old "鼠标滚轮下"
    new "Mouse wheel down"

    # game/screens.rpy:1098
    old "右扳机键\nA/底键"
    new "Right Trigger Button\nA/Bottom Button"

    # game/screens.rpy:1102
    old "左扳机键\n左肩键"
    new "Left trigger button\nLeft shoulder button"

    # game/screens.rpy:1106
    old "右肩键"
    new "Right Shoulder Button"

    # game/screens.rpy:1110
    old "十字键，摇杆"
    new "D-pad, joystick"

    # game/screens.rpy:1114
    old "开始，向导，B/右键"
    new "Start, Guide, B/Right Button"

    # game/screens.rpy:1118
    old "Y/顶键"
    new "Y/Top Key"

    # game/screens.rpy:1121
    old "校准"
    new "CALIBRATION"

    # game/screens.rpy:1185
    old "确定"
    new "Confirm"

    # game/screens.rpy:1186
    old "取消"
    new "CANCEL"

    # game/screens.rpy:1231
    old "正在快进"
    new "Fast forwarding"

    # game/screens.rpy:1541
    old "菜单"
    new "Меню"

