# 主菜单动态背景：给 movie/main_menu.webm 用的独立静音通道
# 这样主菜单视频只循环播放画面、不会出声，也不影响游戏里的音乐/音效/过场视频
init python:
    renpy.music.register_channel("menu_bg", mixer="music", loop=True, movie=True)
    renpy.music.set_volume(0.0, delay=0, channel="menu_bg")
