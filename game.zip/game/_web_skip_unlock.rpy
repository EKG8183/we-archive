# ===========================================================================
# 网页版专用补丁：取消快进限制
# 只存在于网页副本（tools/proj_webcomp），不会影响本地原工程。
# ===========================================================================

init -1 python:
    # 允许快进（默认就是 True，这里显式写出来，避免被其它脚本覆盖）
    config.allow_skipping = True

# 快进时不必停下来：未读过的文本也直接跳过
default preferences.skip_unseen = True
# 选项之后继续快进，不用重新按一次
default preferences.skip_after_choices = True