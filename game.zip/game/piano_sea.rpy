# ===========================================================================
#  《遙かなる夢に～》下落式钢琴小游戏
#  ---------------------------------------------------------------------------
#  构成：
#    game/piano_sea_core.py   纯逻辑（谱面 / 判定 / 记分），可脱离 Ren'Py 自测
#    game/audio/piano/*.wav   10 个白键音色 + miss 音效（由 piano_audio_gen.py 生成）
#    game/piano_sea.rpy       本文件：界面、输入、与剧情的衔接 label
#
#  玩法：10 条轨道对应一个八度加三度的白键 C5 D5 E5 F5 G5 A5 B5 C6 D6 E6，
#        音符从上往下落，落到白色判定线时按下 1 2 3 4 5 6 7 8 9 0，
#        也可以直接用鼠标点击轨道。
#
#  在剧情里调用：
#      call piano_sea_minigame from _call_piano_sea_minigame
#  调用后可用 piano_sea_rank ("S"/"A"/"B"/"C"/"D"，中途放弃为 None)
#  和 piano_sea_result（包含 score / combo / accuracy 等字段的字典）。
# ===========================================================================

init -2 python:
    import piano_sea_core as psea


# 小游戏结束后供剧情读取的结果变量（先给出默认值，避免任何情况下读到未定义变量）
default piano_sea_rank = None
default piano_sea_result = None
default piano_sea_choice = None


init python:

    # ---- 版面参数（基准分辨率 1920x1080）--------------------------------
    PSEA_LANE_W = 104
    PSEA_BOARD_W = PSEA_LANE_W * psea.LANES
    PSEA_BOARD_X = (config.screen_width - PSEA_BOARD_W) // 2
    PSEA_TOP_Y = 168
    PSEA_JUDGE_Y = 806
    PSEA_KEY_H = 130
    PSEA_NOTE_H = 30
    PSEA_SPEED = (PSEA_JUDGE_Y - PSEA_TOP_Y) / float(psea.LEAD_TIME)
    PSEA_BAR_Y = 92
    PSEA_NOTE_VOLUME = 0.8      # 琴键音的音量倍数（相对值，比默认略小）

    # ---- 音频通道：每条轨道一个，避免同时按下的音互相打断 ----------------
    for _i in range(psea.LANES):
        renpy.music.register_channel("psea_lane_%d" % _i, mixer="sound",
                                     loop=False, tight=True)
    renpy.music.register_channel("psea_miss", mixer="sound", loop=False, tight=True)

    def psea_press(game, lane):
        """按下一轨：先出声（像真的琴键），再做判定。"""
        if game.phase != "play":
            return
        renpy.sound.play(psea.LANE_SOUNDS[lane], channel="psea_lane_%d" % lane,
                         relative_volume=PSEA_NOTE_VOLUME)
        game.press(lane)

    def psea_now():
        """当前真实时间（秒）。time 只在函数内部导入，避免把模块对象放进 store。"""
        import time
        return time.monotonic()

    def psea_tick(game):
        """每个定时器周期推进一次；有音符漏掉时给一声闷响。

        屏幕 timer 的实际触发频率会随帧率变化，所以这里用真实时钟推进，
        帧率高低都不会改变曲子的速度。
        """
        if game.phase != "play":
            return
        if game.tick_wall(psea_now()):
            renpy.sound.play(psea.MISS_SOUND, channel="psea_miss")

    def psea_start(game):
        game.start()

    def psea_music_volume():
        """读取 music 通道当前的音量倍数，用于弹完曲子后原样还原。

        Ren'Py 没有公开的 get_volume()，只能从通道的音频上下文里读；
        万一接口变动就退回 1.0，保证不会因为读音量而报错。
        """
        try:
            return renpy.audio.audio.get_channel("music").get_context().secondary_volume
        except Exception:
            return 1.0

    def psea_stop_all():
        for i in range(psea.LANES):
            renpy.music.stop(channel="psea_lane_%d" % i)
        renpy.music.stop(channel="psea_miss")


screen piano_sea_board(game):

    zorder 200
    modal True

    $ now = game.time
    $ st = game.stats()
    $ prog = game.progress()
    $ lit = game.press_lanes()
    $ lyric = psea.lyric_at_time(now)

    # ---- 背景压暗，保留剧情背景 ----
    add Solid("#05070cdf")

    # ---- 顶栏：曲名 / 进度 / 计分 ----
    text "《遙かなる夢に～》　下落式钢琴" xalign 0.5 ypos 14 size 32 color "#efe4c6"

    text ("得分 %d　　连击 %d　　PERFECT %d　GOOD %d　MISS %d"
          % (st["score"], game.combo, st["perfect"], st["good"], st["miss"])):
        xalign 0.5
        ypos 54
        size 24
        color "#9fb3d1"

    add Solid("#18233a") xpos PSEA_BOARD_X ypos PSEA_BAR_Y xysize (PSEA_BOARD_W, 8)
    add Solid(gui.accent_color) xpos PSEA_BOARD_X ypos PSEA_BAR_Y xysize (int(PSEA_BOARD_W * prog), 8)

    # ---- 歌词（演奏时显示，日语 + 中文对照）----
    if game.phase == "play" and lyric is not None:
        add Solid("#0a0f1eb8") xpos PSEA_BOARD_X ypos 98 xysize (PSEA_BOARD_W, 68)
        text lyric[0]:
            xalign 0.5
            ypos 100
            size 30
            color "#efe4c6"
        text lyric[1]:
            xalign 0.5
            ypos 136
            size 22
            color "#9fb3d1"

    # ---- 轨道底板 ----
    for i in range(psea.LANES):
        add Solid("#101728") xpos (PSEA_BOARD_X + i * PSEA_LANE_W) ypos PSEA_TOP_Y xysize (PSEA_LANE_W - 4, PSEA_JUDGE_Y - PSEA_TOP_Y)
        add Solid("#0b1120") xpos (PSEA_BOARD_X + i * PSEA_LANE_W) ypos PSEA_JUDGE_Y xysize (PSEA_LANE_W - 4, PSEA_KEY_H)

    # ---- 下落中的音符（坐标由 piano_sea_core.falling() 算好）----
    for lane, ny, missed in game.falling(PSEA_SPEED, PSEA_JUDGE_Y, PSEA_TOP_Y - 90, PSEA_JUDGE_Y + 150):
        add Solid(psea.LANE_COLORS[lane]) xpos (PSEA_BOARD_X + lane * PSEA_LANE_W + 5) ypos ny xysize (PSEA_LANE_W - 14, PSEA_NOTE_H) alpha (0.30 if missed else 0.96)
        add Solid("#ffffff") xpos (PSEA_BOARD_X + lane * PSEA_LANE_W + 5) ypos ny xysize (PSEA_LANE_W - 14, 5) alpha (0.20 if missed else 0.85)

    # ---- 判定线 ----
    add Solid("#ffffffe8") xpos PSEA_BOARD_X ypos (PSEA_JUDGE_Y - 2) xysize (PSEA_BOARD_W, 4)

    # ---- 判定结果文字 ----
    if game.feedback and now - game.feedback_time < 0.55:
        text game.feedback:
            xpos int(PSEA_BOARD_X + (game.feedback_lane + 0.5) * PSEA_LANE_W)
            xanchor 0.5
            ypos (PSEA_JUDGE_Y + 30)
            size 40
            color psea.FEEDBACK_COLORS[game.feedback_kind]

    # ---- 下方的琴键 ----
    for i in range(psea.LANES):
        $ lane_x = PSEA_BOARD_X + i * PSEA_LANE_W
        $ is_lit = i in lit
        add Solid((psea.LANE_COLORS[i] if is_lit else "#243453")):
            xpos (lane_x + 3)
            ypos (PSEA_JUDGE_Y + 8)
            xysize (PSEA_LANE_W - 10, PSEA_KEY_H - 16)
        text psea.LANE_KEY_NAMES[i]:
            xpos (lane_x + (PSEA_LANE_W - 4) // 2)
            xanchor 0.5
            ypos (PSEA_JUDGE_Y + 34)
            size 40
            color ("#0b1020" if is_lit else "#dce6f7")
        text psea.LANE_PITCHES[i]:
            xpos (lane_x + (PSEA_LANE_W - 4) // 2)
            xanchor 0.5
            ypos (PSEA_JUDGE_Y + 88)
            size 20
            color ("#0b1020" if is_lit else "#7f92b3")

    # ---- 点击区域（放在最上层，覆盖整条轨道）----
    for i in range(psea.LANES):
        button:
            xpos (PSEA_BOARD_X + i * PSEA_LANE_W)
            ypos PSEA_TOP_Y
            xysize (PSEA_LANE_W - 4, PSEA_JUDGE_Y - PSEA_TOP_Y + PSEA_KEY_H)
            background Solid("#ffffff00")
            hover_background Solid("#ffffff14")
            action Function(psea_press, game, i)

    # ---- 定时器：只负责刷新频率，真正的计时由 psea_tick 里的真实时钟完成 ----
    if game.phase == "play":
        timer psea.TICK repeat True action Function(psea_tick, game)

    # ---- 键盘输入 ----
    if game.phase == "ready":
        key "K_SPACE" action Function(psea_start, game)
        key "K_RETURN" action Function(psea_start, game)
        key "K_ESCAPE" action Return("quit")
    elif game.phase == "play":
        key "1" action Function(psea_press, game, 0)
        key "2" action Function(psea_press, game, 1)
        key "3" action Function(psea_press, game, 2)
        key "4" action Function(psea_press, game, 3)
        key "5" action Function(psea_press, game, 4)
        key "6" action Function(psea_press, game, 5)
        key "7" action Function(psea_press, game, 6)
        key "8" action Function(psea_press, game, 7)
        key "9" action Function(psea_press, game, 8)
        key "0" action Function(psea_press, game, 9)
        key "K_ESCAPE" action Return("quit")
    else:
        key "K_SPACE" action Return("retry")
        key "K_RETURN" action Return("finished")
        key "K_ESCAPE" action Return("finished")

    # ---- 开场说明 ----
    if game.phase == "ready":
        add Solid("#05070cf5")
        vbox:
            xalign 0.5
            yalign 0.30
            spacing 20
            text "《遙かなる夢に～》" xalign 0.5 size 76 color "#efe4c6"
            text "下落式钢琴，机器人的返场曲" xalign 0.5 size 30 color "#8fa6c8"
            null height 24
            text "音符落到白色判定线时，按下对应的琴键" xalign 0.5 size 34 color "#dce6f7"
            text "键盘：1 2 3 4 5 6 7 8 9 0　　也可以用鼠标点击轨道" xalign 0.5 size 28 color "#9fb3d1"
            text "116 个音符　约 1 分钟　完整右手旋律" xalign 0.5 size 26 color "#9fb3d1"
            null height 24
            text "空格 / 回车 / 点击下面的按钮　开始　　　ESC 放弃" xalign 0.5 size 30 color gui.accent_color
            null height 18
            textbutton "开始演奏" action Function(psea_start, game) xalign 0.5

    # ---- 结算 ----
    if game.phase == "result":
        add Solid("#05070cf2")
        vbox:
            xalign 0.5
            yalign 0.26
            spacing 16
            text "演奏结束" xalign 0.5 size 58 color "#efe4c6"
            text ("评级 %s　%s" % (st["rank"], st["rank_title"])) xalign 0.5 size 52 color gui.accent_color
            null height 12
            text ("得分 %d" % st["score"]) xalign 0.5 size 36 color "#dce6f7"
            text ("PERFECT %d　GOOD %d　MISS %d" % (st["perfect"], st["good"], st["miss"])) xalign 0.5 size 30 color "#9fb3d1"
            text ("最大连击 %d　　准确率 %.1f%%" % (st["combo"], st["accuracy"] * 100.0)) xalign 0.5 size 30 color "#9fb3d1"
            null height 28
            textbutton "再弹一次（空格）" action Return("retry") xalign 0.5
            textbutton "回到剧情（回车 / ESC）" action Return("finished") xalign 0.5


# ---------------------------------------------------------------------------
#  小游戏入口
# ---------------------------------------------------------------------------

label piano_sea_minigame:

    $ piano_sea_attempt = 0
    $ piano_sea_quick_menu = quick_menu
    $ piano_sea_music_vol = psea_music_volume()

label piano_sea_attempt_loop:

    $ piano_sea_attempt += 1
    $ quick_menu = False
    $ renpy.music.set_volume(piano_sea_music_vol * 0.20, delay=1.0)
    $ piano_sea_game = psea.RhythmGame(*psea.build_chart())
    python:
        # 用 try/finally 包住屏幕：不管是正常弹完、按 ESC 跳过，还是中途被
        # 读档 / 回主菜单之类的操作打断，离开时都会把快速菜单和音乐音量还原。
        try:
            piano_sea_choice = renpy.call_screen("piano_sea_board", piano_sea_game)
        finally:
            psea_stop_all()
            quick_menu = piano_sea_quick_menu
            renpy.music.set_volume(piano_sea_music_vol, delay=1.0)

    if piano_sea_choice == "retry":
        jump piano_sea_attempt_loop

    if piano_sea_choice == "quit":
        $ piano_sea_result = None
        # 演奏中跳过（已经按过开始）→ 按 S 级处理，走 S 级对应的剧情；
        # 还没开始弹就退出 → 保留原来的“放弃”台词（rank 为 None）。
        $ piano_sea_rank = "S" if piano_sea_game.phase == "play" else None
    else:
        $ piano_sea_result = piano_sea_game.stats()
        $ piano_sea_rank = piano_sea_result["rank"]

    $ piano_sea_game = None

    return
